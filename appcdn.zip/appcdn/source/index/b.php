
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="gbk">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="分发平台,app应用分发,ios分发,安卓分发,二维码分发平�?app分发,网站封装app,应用分发平台">
<meta name="description" content="app分发平台提供APP分发、ios分发、安卓分发、应用托管、内测分发、兼容测试、UDID等服�?真正为开发者着想的APP分发托管平台�?>
<title>极速分发平�?</title>
<link href="/static/index/icons.css" rel="stylesheet">
<link href="/static/index/bootstrap.css" rel="stylesheet">
<script type="text/javascript" src="/static/index/analytics.js"></script>

</head>
<body>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="gbk">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="分发平台,app应用分发,ios分发,安卓分发,二维码分发平�?app分发,网站封装app,应用分发平台">
<meta name="description" content="app分发平台提供APP分发、ios分发、安卓分发、应用托管、内测分发、兼容测试、UDID等服�?真正为开发者着想的APP分发托管平台�?>
<title>极速分发平�?</title>
<link href="static/css/icons.css" rel="stylesheet">
<link href="static/css/bootstrap.css" rel="stylesheet">
<script type="text/javascript" src="static/js/analytics.js"></script>

</head>
<body>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="极速分发，极速app证书签名 ios棋牌游戏签名 ipa封装签名证书打包代ios签名">
<meta name="keywords" content="apk,android,ipa,ios,iphone,ipad,app分发,应用托管,企业签名">
<meta name="description" content="分发分发为各行业提供ios企业签名、app应用托管分发服务�?>
<title>分发 - App托管服务分发平台|安卓应用托管|iOS分发|ipa企业签名</title>
<link href="static/css/icons_1.css" rel="stylesheet">
<link href="static/css/bootstrap_1.css" rel="stylesheet">

<script type="text/javascript">
var startTime = new Date();
var reg_link = '/index.php/reg';
var letter_doodle = ["B","e","t","a","A","p","p","H","o","s","t","<br>","{","<br>","     ","r","e","t","u","r","n"," ",'"',"9","1","d","s",".","v","i","p",'"',"<br>","}"];
var end_letter_doodle = '<i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">9</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">1</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">d</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">s</i><i class="icon-comma trans"></i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">v</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">i</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">p</i>';
</script>
  
  <!-- Vendor styles -->
  <link rel="stylesheet" href="static/css/font-awesome.css">
  <link rel="stylesheet" href="static/css/metismenu.css">
  <link rel="stylesheet" href="static/css/animate.css">
  <link rel="stylesheet" href="static/css/bootstrap.min.css">

  <!-- App styles -->
  <link rel="stylesheet" href="static/css/pe-icon-7-stroke.css">
  <link rel="stylesheet" href="static/css/helper.css">
  <link rel="stylesheet" href="static/css/style.css">
  <link rel="stylesheet" href="static/css/custom.css">
  <link rel="stylesheet" href="static/css/sidebar.css">
  <link rel="stylesheet" href="static/css/menu.css">
<link rel="stylesheet" href="static/css/signature.css">
<style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style><style id="style-1-cropbar-clipper">/* Copyright 2014 Evernote Corporation. All rights reserved. */
.en-markup-crop-options {
    top: 18px !important;
    left: 50% !important;
    margin-left: -100px !important;
    width: 200px !important;
    border: 2px rgba(255,255,255,.38) solid !important;
    border-radius: 4px !important;
}

.en-markup-crop-options div div:first-of-type {
    margin-left: 0px !important;
}

</style>

<style type="text/css" id="MEIQIA-ICON-STYLE">.MEIQIA-ICON { background-size: 40px auto !important; background-repeat: no-repeat !important; background-image: url("static/images/icon-mq.png") !important; } @media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (min--moz-device-pixel-ratio: 2), only screen and (-o-min-device-pixel-ratio: 2/1), only screen and (min-device-pixel-ratio: 2) { .MEIQIA-ICON { background-image: url("static/images/icon-mq@2x.png") !important; } } .MEIQIA-ICON-CHAT1 { background-position: 0 0 !important; } .MEIQIA-ICON-CHAT2 { background-position: 0 -20px !important; } .MEIQIA-ICON-CHAT3 { background-position: 0 -40px !important; } .MEIQIA-ICON-CHAT4 { background-position: 0 -60px !important; } .MEIQIA-ICON-CHAT5 { background-position: 0 -80px !important; } .MEIQIA-ICON-CHAT6 { background-position: 0 -100px !important; } .MEIQIA-ICON-CHAT7 { background-position: 0 -120px !important; } .MEIQIA-ICON-CHAT8 { background-position: 0 -140px !important; } .MEIQIA-ICON-CHAT9 { background-position: 0 -160px !important; } .MEIQIA-ICON-CHAT10 { background-position: 0 -180px !important; } .MEIQIA-ICON-CHAT11 { background-position: 0 -200px !important; } .MEIQIA-ICON-CHAT12 { background-position: 0 -220px !important; } .MEIQIA-ICON-TICKET1 { background-position: -20px 0 !important; } .MEIQIA-ICON-TICKET2 { background-position: -20px -20px !important; } .MEIQIA-ICON-TICKET3 { background-position: -20px -40px !important; } .MEIQIA-ICON-TICKET4 { background-position: -20px -60px !important; } .MEIQIA-ICON-TICKET5 { background-position: -20px -80px !important; } .MEIQIA-ICON-TICKET6 { background-position: -20px -100px !important; } .MEIQIA-ICON-TICKET7 { background-position: -20px -120px !important; } .MEIQIA-ICON-TICKET8 { background-position: -20px -140px !important; } .MEIQIA-ICON-TICKET9 { background-position: -20px -160px !important; } .MEIQIA-ICON-TICKET10 { background-position: -20px -180px !important; } .MEIQIA-ICON-TICKET11 { background-position: -20px -200px !important; } .MEIQIA-ICON-TICKET12 { background-position: -20px -220px !important; } </style><style type="text/css" id="MEIQIA-PANEL-STYLE">#MEIQIA-PANEL-HOLDER { position: fixed; bottom: 0;  right: 60px;  z-index: -1; width: 320px; height: 480px; padding: 0; margin: 0; overflow: hidden; visibility: hidden; background-color: transparent; box-shadow: 0 0 20px 0 rgba(0, 0, 0, .15); border: 1px solid #eee\0; *border: 1px solid #eee; } #MEIQIA-IFRAME { position: absolute; top: 0; right: 0; bottom: 0; left: 0; display: none; width: 100% !important; height: 100% !important; border: 0; padding: 0; margin: 0; float: none; background: none; } </style><style type="text/css" id="MEIQIA-BTN-STYLE">#MEIQIA-BTN-HOLDER { display: none; position: fixed; bottom: 0;  right: 60px;  z-index: 2147483647; width: auto; height: auto; padding: 0; margin: 0; border: 0; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif; background-color: transparent; } #MEIQIA-BTN, #MEIQIA-BTN span, #MEIQIA-BTN div, #MEIQIA-BTN img { float: none; width: auto; height: auto; padding: 0; margin: 0; border: 0; background: none; } #MEIQIA-BTN { display: block; height: 40px; font-size: 16px; color: #fff; text-align: center; border-left: 1px solid rgba(0, 0, 0, .1); border-top: 1px solid rgba(0, 0, 0, .1); border-right: 1px solid rgba(0, 0, 0, .1); box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); cursor: pointer; text-decoration: none; background-color: #1abc9c; } #MEIQIA-BTN #MEIQIA-BTN-ICON { display: block; float: left; width: 20px; height: 20px; margin: 10px 10px 0; } #MEIQIA-BTN #MEIQIA-BTN-LINE { display: block; float: left; width: 1px; height: 100%; background-color: rgba(0, 0, 0, .08); background-color: #000\9; opacity: .1\9; filter: alpha(opacity=10)\9; vertical-align: middle; } #MEIQIA-BTN #MEIQIA-BTN-TEXT { display: block; float: left; height: 40px; margin: 0 10px; line-height: 40px; overflow-y: hidden; font-size: 16px; color: #fff; } #MEIQIA-BTN #MEIQIA-CIRCLE { position: absolute; top: -13px; left: -13px; display: none; width: 26px; height: 26px; text-align: center; line-height: 26px; font-size: 14px; color: #fff; border-radius: 15px; background-color: #ff3b30; } #MEIQIA-BTN #MEIQIA-BUBBLE { position: absolute; bottom: 64px; display: none; width: 260px; border: 1px solid #f7f7f7; border-radius: 4px; color: #000; text-align: left; box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); line-height: 1.428571429; background-color: #fff; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW1 { position: absolute; z-index: 2; font-size: 0; line-height: 0; border-width: 8px 7px 0px; border-color: #fff transparent; border-style: solid dashed dashed; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW2 { position: absolute; z-index: 1; font-size: 0; line-height: 0; border-width: 10px 8px 0px; border-color: #f7f7f7 transparent; border-style: solid dashed dashed; }  #MEIQIA-BTN #MEIQIA-BUBBLE { right: 0; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW1 { right: 12px; bottom: -8px; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW2 { right: 11px; bottom: -10px; }  #MEIQIA-BTN #MEIQIA-BUBBLE-CLOSE { position: absolute; display: none; top: 12px; right: 12px; width: 10px; height: 10px; background-position: -5px -245px; cursor: pointer; } #MEIQIA-BTN #MEIQIA-BUBBLE:hover #MEIQIA-BUBBLE-CLOSE { display: block; } #MEIQIA-BTN #MEIQIA-BUBBLE-INSIDE { margin: 12px 18px; } #MEIQIA-BTN #MEIQIA-BUBBLE-AVATAR { width: 26px; height: 26px; border-radius: 13px; margin-right: 6px; vertical-align: top; box-shadow: 0 0 8px 0 rgba(0, 0, 0, .15); } #MEIQIA-BTN #MEIQIA-BUBBLE-NAME { display: inline-block; margin-top: 3px; font-size: 16px; color: #000; } #MEIQIA-BTN #MEIQIA-BUBBLE-MSG { *height: 40px; max-height: 40px; margin-top: 5px; font-size: 14px; overflow: hidden; color: #000; } #MEIQIA-BTN #MEIQIA-BUBBLE-MSG img { width: 16px; height: 16px; } </style><style type="text/css" id="MEIQIA-INVITE-STYLE">#MEIQIA-INVITE, #MEIQIA-INVITE div, #MEIQIA-INVITE span { float: none; width: auto; height: auto; padding: 0; margin: 0; border: 0; background: none; } #MEIQIA-INVITE { position: fixed; z-index: 2147483647; display: none; width: 340px; height: 130px; margin-bottom: 64px; border: 1px solid #f7f7f7; border-radius: 4px; box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); text-align: left; cursor: pointer; color: #000; line-height: 1.428571429; background-color: #fff; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1, #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { position: absolute; font-size: 0; line-height: 0; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1 { z-index: 2; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { z-index: 1; }   #MEIQIA-INVITE { right: 60px; bottom: 0; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1 { right: 12px; bottom: -8px; border-top: 8px solid #fff; border-right: 7px solid transparent; border-left: 7px solid transparent; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { right: 11px; bottom: -10px; border-top: 9px solid #f7f7f7; border-right: 8px solid transparent; border-left: 8px solid transparent; }     #MEIQIA-INVITE #MEIQIA-INVITE-CLOSE { position: absolute; right: -20px; top: -20px; width: 40px; height: 40px; cursor: pointer;  background-position: 0 -260px;  } #MEIQIA-INVITE #MEIQIA-INVITE-CLOSE:hover {  background-position: 0 -300px;  } #MEIQIA-INVITE #MEIQIA-INVITE-INSIDE { width: 300px; height: 44px; margin: 46px 20px 0; text-align: left; font-size: 14px; line-height: 22px; overflow: hidden; color: #000; /*word-break: break-all;*/ } </style> 

  
</head>
<body class="landing-page hide-sidebar" data-gr-c-s-loaded="true" ryt12216="1">




<link rel="stylesheet" href="static/css/header_include_fashion.min.css">
<link rel="stylesheet" href="static/css/index-ad-places.css">
<link rel="stylesheet" href="static/css/index.css">
<link rel="stylesheet" href="static/css/idangerous.swiper2.7.6.css">
<link rel="stylesheet" href="static/css/animate.min.css">
<link rel="stylesheet" href="static/css/style_1.css">

<style>
#meiqia {
    -moz-box-shadow: 3px 3px 9px #c1c1c1;
    -webkit-box-shadow: 3px 3px 9px #c1c1c1;
    box-shadow: 3px 3px 9px #c1c1c1;
}

.img-shrink {
    max-width:120px;
}

.btn-detail-index-top {
    padding: 12px 50px;
    background-color: #29bb9c;
    border-color: #29bb9c;
    color: #fff;
}
.btn-detail-index-top:hover {
    background-color:#27c7a5;
    border-color: #27c7a5;
    color:#fff;
}
.btn-detail-index-top:active {
    background-color:#27c7a5;
    border-color: #27c7a5;
    color:#fff;
}
a.btn-detail-index-top:hover, a.btn-detail-index-top:active {
    color: #fff;
}
.font-18 {
    font-size: 18px !important;
}
.about-p1 {
    font-size:14px;
}
.membership {
    color:#29bb9c;
}
.faq-content {
    padding-bottom:30px;
}
.faq-section {
    background:#f6f6f6;
    padding-top:100px;
    padding-bottom:100px;
}
.faq-section .question {
    font-size:20px;
    color:#252525;
    margin-bottom:20px;
}
.faq-section .answer {
    font-size:14px;
    color:#8d9396;
}
.faq-item {
    padding:20px 50px;
}
.price-content-title {
    font-size: 26px;
    color: #000;
}
  .footery {
	margin-top:50px;
	text-align:center;
	border-top:1px solid #979797;
	padding-top:30px;
	padding-bottom:40px
}
.footery .footer-content {
	font-size:14px !important;
	max-width:980px;
	width:95%;
	display:inline-block;
	margin:0 auto
}
.footery .footer-content .list-inline {
	text-align:left;
	padding:0;
	margin:0;
	line-height:30px
}
.footery .footer-content .list-inline a {
	color:#505556;
	white-space:nowrap
}
.footery .footer-content table {
	width:100%
}
.footery .footer-content .locale {
	width:90px;
	vertical-align:top
}
.footery .footer-content .locale a {
	text-decoration:none;
	color:#505556
}
</style>

<div class="container">
    <div class="row mheader hide">
        <div class="col-md-6"></div>
        <div class="col-md-6 text-right mt-5 mb-10">
                    </div>
    </div>
</div>

<nav class="navbar navbar-default">
    <div class="container head-container">
        <div class="navbar-header">
            <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle navbar-toggle1 collapsed btn-mobile-more" type="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="/"><img src="/static/picture/logo.png" class="mt-10" style="width:212px;"></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          
             <ul class="nav navbar-nav navbar-nav1 navbar-right">

				<li><a href="/">首页</a></li>
               	<li><a href="/index.php/home">上传分发</a></li>
				<li><a href="/index.php/cishu">分发价格</a></li>
				<li><a href="/index.php/qianming">签名价格</a></li>
               	<li><a href="/index.php/webview">封装价格</a></li>
	<?php if($GLOBALS['userlogined']){ ?>
	<li><a href="<?php echo IN_PATH.'index.php/home'; ?>">应用管理</a></li>
	<li><a href="<?php echo IN_PATH.'index.php/logout'; ?>">退�?/a></li>
	<?php }else{ ?>
	<li><a href="<?php echo IN_PATH.'index.php/reg'; ?>">免费注册</a></li>
	<li><a href="<?php echo IN_PATH.'index.php/login'; ?>">立即登录</a></li>
	<?php } ?>
		</div>
	</div>
</div>
</nav>

<!--<header class="pt100 pb100 bg-store-light signature-header mb-0">
<div class="container">
         <div class="col-lg-6 col-md-6 col-xs-12 col-sm-8">
            <h1 class="mb-10 font-36 color-333">分发</h1>
           

    <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;">3分钟自助签名�?/h3>
    <h3 class="mb-10 font-20 color-333"  style="color: #29bb9c!important; margin-left: 5px;">12个月不掉签名�?/h3>
    <h3 class="mb-10 font-20 color-333"  style="color: #29bb9c!important; margin-left: 5px;">24小时贴心为您</h3>

     <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;"> &nbsp;</h3>
            <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;"> &nbsp;</h3>

            <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;"> &nbsp;</h3>
           

            <p class="font-16 color-333 line-28 mt-40 mb-60">我们为您提供长期、稳定、有效的 iOS 企业证书签名服务，免提交 APP Store 审核，无需越狱即可在手机、平板上下载安装。适用于所有内测的 iOS 应用，以最优的签名服务为您排除最难以解决的上线障碍�?/p>
            <div class="col-md-12 mt-10" style="padding-left:0px">
                                    <a href="/index.php/home" class="btn btn-detail-index-top font-18 border-radius-5">立即签名</a>
                                    <a href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes" class="btn btn-detail-aso-top font-18 border-radius-5" target="_blank" style="padding: 12px 31px;    border: 1px solid #29bb9c;">联系售前咨询</a>
            </div>
       </div>
    </div>
</header>-->
<body>
			</div>
		</div>    
	</div>
		</a>
	</div>
  
</div>
<div class="pagination"></div>
</div>

</body>



<div class="container-fluid faq-section">
    <div class="container">
        <div class="col-md-12 text-center faq-content">
            <span class="price-content-title">极速分发应用规�?/span>
        </div>
  </script>
<a name="01"></a>
<p class="item-title">1、介绍（Introduction�?/p>
<p>
极速分发（bichuse.com）是一个创新的开发者服务平台，为开发者提供测试应用快速发布，提高应用内测分发效率。同时我们为开发者提供iOS App、Android App 的开发、打包、封装、测试、分发上线等一系列效率工具，帮助开发者将精力集中在优化产品本身上。我们致力于打造一个服务于开发者的生态圈�?br>
这个文档会及时更新并完善，每一次的修改都是基于优化用户的体验、公平对待所有开发者出发。我们重视用户体验如同珍视生命一般，希望您也如我们一样。我们期望所有的开发者们要了解，极速分发开发中服务平台中发布内测应用的一些原�?</p>
<a name="01"></a>
<p class="item-title">2、条款（Terms and conditions�?/p>
<p class="font18">2.1 开发者应该遵守国家的法律法规，同时尊重其他开发者的劳动成果。以下的规则将可以帮�?您的应用极速分发尽快内测发�?/p>
<p class="font18">2.2 以下审核规范中提及的手机型号对应关系均为最新的系统版本或机�?/p>
<a name="03"></a>
<p class="item-title">3、应用功能（Functionality�?/p>
<p class="font18">3.1 应用无法正常运行或功能存在问�?/p>
<p>3.1.1应用存在功能问题</p>
<p>3.1.2应用无法正常安装或安装时提示解析失败</p>
<p>3.1.3应用无法正常卸载或卸载报�?/p>
<p>3.1.4应用在启动时崩溃</p>
<p>3.1.5应用在运行时崩溃</p>
<p>3.1.6应用中内容无法正常显示或无法获取</p>
<p>3.1.7应用内按钮点击无反应或点击报�?/p>
<p>3.1.8应用内Tap无法切换或切换报�?/p>
<p>3.1.9应用强制或诱导修改系统默认设�?/p>
<p>3.1.10应用功能需要依赖于第三方应用才能实�?/p>
<p>3.1.11应用描述中介绍的功能在应用内不具备或不一�?/p>
<p>3.1.12应用需要登录，但应用内不提供注册通道，请在完善资处填写测试账号�?/p>
<p>3.1.13注册账号功能不可用，审核时尝�?次都无法成功注册</p>
<p>3.1.14应用登录账号功能不可用，应用审核时尝�?次都无法成功登录</p>
<p>3.1.15应用界面模糊或拉�?/p>
<p class="font18">3.2应用描述和实际功能不�?/p>
<p>3.2.1应用介绍或更新日志中介绍的功能在应用内不具备或不一�?/p>
<p>3.2.2应用存在欺骗用户下载使用的行�?/p>
<p class="font18">3.3申请危险权限或权限和功能不符</p>
<p>3.3.1应用申请的权限和其实际功能不�?/p>
<p>3.3.2应用实际功能不需常驻通知栏却常驻通知�?/p>
<p>3.3.3应用无法关闭常驻通知提示</p>
<p>3.3.4通知栏显示图标与应用ICON不相�?/p>
<p>3.3.5应用实际功能不需开机启动却开机启�?/p>
<p>3.3.6应用在安装或者运行前提示用户重启设备</p>
<p>3.3.7应用在安装或者运行前强制重启设备</p>
<p class="font18">3.4应用功能存在使用限制</p>
<p>3.4.1应用功能仅供部分用户使用，比如限制用户的地域或仅供组织内部使用等，请在应用介绍内说明具体限制范围</p>
<p class="font18">3.5应用存在恶意行为</p>
<p>3.5.1应用存在恶意行为</p>
<p>3.5.2应用未经用户许可发送短信，建议使用返回验证码等方式</p>
<p>3.5.3应用存在病毒</p>
<p>3.5.4应用存在吸费行为</p>
<p>3.5.5应用消耗过多的网络流量</p>
<p>3.5.6应用未经用户许可拨打电话</p>
<p>3.5.7应用修改主叫号码，主要功能用于欺骗被叫用�?/p>
<p>3.5.8应用未运行，但是仍会启动GPS、蓝牙等系统功能</p>
<a name="04"></a>
<p class="item-title">4、应用展示和广告（App Properties &amp; AD�?/p>
<p class="font18">4.1应用闪屏界面（或启动引导界面）包含其他应用的图标、水印、文字等</p>
<p class="font18">4.2应用展示内容存在问题</p>
<p>4.2.1应用内容存在侵权行为</p>
<p>4.2.2应用名称+描述语不能超�?个汉字字符或16个英文字�?/p>
<p>4.2.3应用名称本身就已经超�?个汉字或16个英文字符，只能使用应用的原名称，不能添加描述语</p>
<p>4.2.4应用名称存在占位符文本、大量空格等非法字符（如�?�?�?amp; 等）</p>
<p>4.2.5应用名称与线上已存在的应用的名称相同，请您修改名称；若拥有相应名称的商标权，请联系客服提�?/p>
<p>4.2.6应用在商店中显示的名称和安装到设备中显示的名称差异较�?/p>
<p>4.2.7应用名称包含非法内容</p>
<p>4.2.8应用名称存在侵权行为</p>
<p>4.2.9应用名称仅以类别词命名，如以壁纸、标签、电话、桌面、安全助手、wifi等名称做为应用的名称�?/p>
<p>4.2.10应用介绍或更新说明包含非法内�?/p>
<p> 4.2.11应用介绍或更新说明中包含侵权内容</p>
<p>4.2.12应用介绍或更新日志中存在占位符文本、大量空格空行、非法字符（如：@�?�?�?amp; 等）</p>
<p>4.2.13更新说明和旧版本的更新日志相同，请填写本次更新说�?/p>
<p>4.2.14应用更新说明中包含其他应用市场名称或内容</p>
<p>4.2.15更新说明无效，请填写正确的更新说�?/p>
<p>4.2.16应用简介中使用了极限词或虚假承诺等违反新广告法的内容（如“最”“第一”“唯一”“NO.1”“必备”“免费送”�?00%�?“全球”“顶尖”“首”等）；</p>
<p>4.2.17应用简介使用了疑问、反问等句式（请用陈述语句进行描述）</p>
<p>4.2.18应用简介中包含违规内容（如侵权、色情、恐怖暴力、反动等</p>
<p>4.2.19应用简介存在占位符文本、大量空格等非法字符（如�?�?�?amp; 等）</p>
<p class="font18">4.3应用展示的图片资源存在问�?/p>
<p>4.3.1应用内容中的图片拉伸或模�?/p>
<p>4.3.2应用截图和应用实际的界面不符</p>
<p>4.3.3应用截图中存在重�?/p>
<p>4.3.4应用截图存在黑边</p>
<p>4.3.5应用截图存在压缩</p>
<p>4.3.6应用截图模糊不清，无法分辨截图内�?/p>
<p>4.3.7应用截图存在拉伸</p>
<p>4.3.8应用截图内容显示不完�?/p>
<p>4.3.9应用截图存在非法内容</p>
<p>4.3.10应用截图存在侵权行为</p>
<p class="font18">4.4广告相关</p>
<p>4.4.1应用未经用户许可或默认勾选创建桌面快捷方�?/p>
<p>4.4.2应用未经用户许可默认安装或默认勾选安装第三方应用</p>
<p>4.4.3应用未经用户许可修改系统默认设置</p>
<p>4.4.4应用存在诱导用户点击广告的行�?/p>
<p>4.4.5应用内存在诱导用户评价功能，不得出现任何诱导用户进行评分、给应用好评的功�?/p>
<p>4.4.6应用介绍中不得包含任何诱导用户进行评分、给应用好评的功能或文字描述</p>
<p>4.4.7应用存在通知栏广�?/p>
<p>4.4.8应用多次发现存在通知栏广告行为，将不再收�?/p>
<p>4.4.9应用存在强制积分墙，在启动时强制要求换取积分才能使用</p>
<p>4.4.10应用存在强制积分墙，在使用时强制要求换取积分</p>
<p>4.4.11应用具有诱导用户赚取积分兑换货币或奖品的功能</p>
<p>4.4.12暂不收录：赚取积分以兑换话费、现金等奖品的应�?/p>
<p>4.4.13应用存在抢占锁屏的行�?/p>
<p>4.4.14应用广告存在模仿系统通知或警告的行为</p>
<p>4.4.15应用的主要目的是展示广告或者市场营销</p>
<p>4.4.16应用使用过程中频繁弹出悬浮窗广告，中断用户操作，影响用户体验</p>
<p>4.4.17应用包含空广告栏�?/p>
<p>4.4.18应用中的广告不能干扰第三方的应用的广告展�?/p>
<p>4.4.19应用广告中包含不良或违法信息</p>
<p>4.4.20通过非正常渠道进行推广安�?/p>
<p class="font18">4.5用户使用体验</p>
<p>4.5.1应用打开立即会提示更新，请确认您所上传的是否为最新版�?/p>
<p>4.5.3应用功能、界面和应用商店中已收录应用非常类似</p>
<p>4.5.4应用功能、界面和应用商店中已收录应用完全雷同</p>
<p>4.5.5开发者应将当地官方语言的应用描述放在应用描述最�?/p>
<p>4.5.6应用部分功能或内容需要访问调用其他应用获�?/p>
<p>4.5.7应用内容不完整，部分功能待开�?/p>
<p>4.5.8应用的用户界面过于复�?/p>
<a name="05"></a>
<p class="item-title">5、应用内容（Contents of App�?/p>
<p class="font18">5.1应用存在暴力内容</p>
<p>5.1.1任何带有诽谤、人身攻击或者侮辱个人或者团体的应用</p>
<p>5.1.2应用存在人类或动物被杀、被虐待、被伤害等图片或内容</p>
<p>5.1.3应用过分描述暴力或虐待儿�?/p>
<p>5.1.4应用对武器进行过于逼真的表述（如不能涉及武器的制造工艺和参数等），并鼓励违法或滥用武�?/p>
<p class="font18">5.2应用存在色情内容</p>
<p>5.2.1应用包含色情内容或者过分展现性器官，但又不是旨在艺术审美或情�?/p>
<p>5.2.2应用中存在允许用户提交色情内容，如允许用户发布色情照片、文字等</p>
<p>5.2.3情趣用品商城类应用禁止存在社区、论坛等允许用户发布帖子、信息和评论帖子等功能和模块</p>
<p>5.2.4应用介绍、应用截图、描述语等含有色情内容，详情如下�?/p>
<p class="font18">5.3应用存在非法金钱交易或内�?/p>
<p>5.3.1应用具有现金或者流通货币赌博功�?/p>
<p class="font18">5.4政治问题</p>
<p>5.4.1应用不能包含对国家领导人诽谤、人身攻击或者侮辱性的内容</p>
<p>5.4.2应用包含反政府、反社会内容</p>
<p>5.4.3存在政治错误的应用，如VPN、翻墙、涉恐涉暴等</p>
<p class="font18">5.5用户使用感受</p>
<p>5.5.1极速分发暂不收录：品类单一的主题、壁纸、锁屏类应用</p>
<p>5.5.2极速分发暂不收录：短信收取服务费的应用</p>
<p>5.5.3极速分发暂不收录：主要功能需要获取Root权限后才可使用的应用</p>
<p>5.5.4应用设计的功能主要是令用户厌恶、恐�?/p>
<p>5.5.5应用具有易引起用户不适或者比较粗俗的内容，如对血腥和色情场面的过分展�?/p>
<p>5.5.6应用中所有的“敌人”角色，都不能针对任何一个现实的种族、文化、政府或公司，以及任何一个真实的个体</p>
<p>5.5.7应用中涉及的宗教内容都应该是翻译准确和使用恰当的，并且不存在误导行为。使用这些内容的目的应该是教育意义的而不是煽动性的</p>
<p>5.5.8存在针对某一宗教、文化或种族的诽谤、侮辱或攻击的内容，或有可能让这部分群体人们造成情感伤害的内�?/p>
<p class="font18">5.6应用内抽奖、彩票相关功能及内容</p>
<p>5.6.1应用中的竞赛和抽奖活动必须由该应用开发者来发起</p>
<p>5.6.2竞赛和抽奖活动必须在应用的用户协议中有清晰详细的描述，且这些竞赛或抽奖活动极速分发无关，不承担任何相关法律责�?/p>
<p>5.6.3彩票类软件都必须符合国家的相关法律条�?/p>
<p>5.6.4理财/彩票类软件请根据要求提交相关资质证明发送至 service@leffs.cn</p>
<p>5.6.5理财应用提交的应用一句话简介，应用描述，更新日志，截图等需符合理财APP内容审核要求</p>
<p class="font18">5.7开发者行为不�?/p>
<p>5.7.1开发者重复提交结构、功能、内容相似的应用，重复提交的应用将被驳回或下�?情节严重者将被封禁开发者账�?/p>
<p>5.7.2开发者对已经明确版权归属的应用私自进行破解、汉化、反编译或重新打包，应用将被驳回且开发者将被封禁开发者账�?/p>
<p>5.7.3开发者提交的应用存在问题或开发者自身原因，开发者主动申请驳回、删除或下架</p>
<a name="06"></a>
<p class="item-title">6、损坏设备（Damage to Device�?/p>
<p class="font18">6.1 用户运行该应用有可能损坏设备</p>
<p class="font18">6.2 应用会迅速消耗电量或者造成设备过热</p>
<p> 6.2.1 应用未启动，但不断使用GPS等功能导致用户电量迅速消�?/p>
<p>6.2.2 应用未启动，但会长时间占用CPU、内存等导致设备过热</p>
<a name="07"></a>
<p class="item-title">7、法律要求（Legal Requirements�?/p>
<p class="font18">7.1 违反国家法律法规</p>
<p class="font18">7.2 应用允许共享违法的文件或内容</p>
<p>7.2.1 应用怂恿或鼓励犯罪或暴力行为</p>
<p>7.2.2 应用鼓励酒驾或公布没有经过交通管理部门允许的酒驾检测点数据</p>
<p>7.2.3 应用过度宣传酒精或者危险物品（如毒药、爆炸物等），或者鼓励未成年人消费香烟和酒精饮料</p>
<p class="font18">7.3 应用存在侵犯版权行为</p>
<p>7.3.1 应用为破解、盗版或未获得版权所有者授权的应用</p>
<p>7.3.2 单本图书类应未提供版权证�?，书城类应用未提供免责声�?/p>
<p class="font18">7.4 应用存在欺诈行为</p>
<p>7.4.1 应用存在欺骗、伪造或者误导用户的行为</p>
<p class="font18">7.5 隐私保护</p>
<p>7.5.1 应用未提示用户或未经用户授权情况下搜集、传输或者使用用户的位置信息</p>
<p>7.5.2 应用未经用户许可且在用户不知情的情况下传输和使用用户的隐私数据，如通讯录、照片和短信记录�?/p>
<p>7.5.3 应用强制要求用户共享其个人信息，如邮件地址或生日等信息</p>
<p>7.5.4 应用搜集未成年人信息数据</p>
<p>7.5.5 开发者的应用会窃取用户密码或者其他用户个人数据的将被封禁极速分发账�?/p>
</div>
</div>
<div class="col-lg-1"></div>
</div>
</div>
  
  <div class="footery">
	<div class="footer-content">
		<ul class="list-inline list-unstyled navbar-footer">
			<li>Copyright &copy; 2018 分发 .All Rights Reserved.</li>
			<li><a href="/index.php/a"  target="_blank">应用规范</a></li>
			<li><a href="/index.php/a"  target="_blank">服务协议</a></li>
            <li><a href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes"  target="_blank">联系客服</a></li>
          	<li>声明：本平台仅供应用内测使用，请勿上传非法应用。如违规违法上传应用一切后果有上传者承担�?/li>
			<li></li>
		</ul>
	</div>
</div></div>


<!-- Vendor scripts 

<script async="" src="static/js/meiqia.js"></script>
<script async="" src="static/js/analytics.js"></script>
-->


<script src="static/js/jquery.min.js"></script>
<script src="static/js/jquery-ui.min.js"></script>
<script src="static/js/jquery.slimscroll.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/metismenu.min.js"></script>
<script src="static/js/icheck.min.js"></script>
<script src="static/js/index.js"></script> 
<script src="static/js/jquery-1.10.1.min.js"></script>
<script src="static/js/idangerous.swiper2.7.6.min.js"></script>
<script src="static/js/swiper.animate1.0.2.min.js"></script>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-74260511-1', 'auto');
    ga('send', 'pageview');

    $(document).ready(function () {
    $('.navbar ul.nav li.father ').hover(function() {
        $(this).find('i.fa-angle-down').removeClass('fa-angle-down').addClass('fa-angle-up');
        $(this).find('.son').stop(true, true).fadeIn();
    }, function() {
        $(this).find('i.fa-angle-up').removeClass('fa-angle-up').addClass('fa-angle-down');
        $(this).find('.son').stop(true, true).fadeOut();
    });
 });
 
 var mySwiper = new Swiper ('.swiper-container', {
	pagination: '.pagination',
	paginationClickable :true,
	autoplay : 10000,
	speed:1,

	//autoplayDisableOnInteraction : false,
	
	onInit: function(swiper){ //Swiper2.x的初始化是onFirstInit
		swiperAnimateCache(swiper); //隐藏动画元素 
		swiperAnimate(swiper); //初始化完成开始动�?	}, 
	onSlideChangeEnd: function(swiper){ 
	swiperAnimate(swiper); //每个slide切换结束时也运行当前slide动画
	} 
})
  
$('.arrow-left').on('click', function(e){
	e.preventDefault()
	mySwiper.swipePrev()
})
$('.arrow-right').on('click', function(e){
	e.preventDefault()
	mySwiper.swipeNext()
})    

</script>
 
<div class="bar hidden-xs" style="z-index:9999;">
    <a class="bar3" href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes">
         <span class="tel"></span>
    </a>
</div>

<script src="static/js/homer.js"></script>

<!-- Local script for menu handle -->
<!-- It can be also directive -->
<script>
    $(document).ready(function () {

    });
</script>
 
</body>  
  </html>
 </body>
</html></body>
</html>