﻿<!DOCTYPE HTML>
<html class="" >
<head>
<meta charset="utf-8">
<meta name="renderer" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0,minimal-ui">
<meta name="format-detection" content="telephone=no">
<title>卡卡分发-苹果ios企业签名|苹果app稳定签名|ipa签名|独立证书</title>
<meta name="description" content="卡卡分发提供快速稳定不掉的苹果ios企业签名服务,包含ipa企业签名,app企业签名,ios企业开发者账号,无需上架苹果商店独立企业证书,长期稳定不掉线,多年苹果app签名经验,解决您企业签名服务中所有问题,让你在ios证书签名中没有后顾之忧">
<meta name="keywords" content="苹果企业签名,ios企业证书签名,苹果app签名,ipa签名,ios企业账号,ios签名,卡卡分发">
<meta name="generator" content="" data-variable="https://xunlianfang.cn/|cn|cn|yvbmrsza|10001|10001|0" data-user_name="">
<link href="https://xunlianfang.cn/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="static/css/basic.css">
<link rel="stylesheet" type="text/css" href="static/css/index_cn.css">
<script language="JavaScript">
<!--
if (window.Event)
document.captureEvents(Event.MOUSEUP);
function nocontextmenu()
{
event.cancelBubble = true
event.returnValue = false;
return false;
}
function norightclick(e)
{
if (window.Event)
{
if (e.which == 2 || e.which == 3)
return false;
}
else
if (event.button == 2 || event.button == 3)
{
event.cancelBubble = true
event.returnValue = false;
return false;
}
}
document.oncontextmenu = nocontextmenu; // for IE5+
document.onmousedown = norightclick; // for all others
//-->
</script>
<style>
body{
    background-color:#ffffff !important;font-family: !important;}
h1,h2,h3,h4,h5,h6{font-family: !important;}
</style>
<!--[if lte IE 9]>
<script src="static/js/lteie9.js"></script>
<![endif]-->
</head>
<!--[if lte IE 8]>
<div class="text-xs-center m-b-0 bg-blue-grey-100 alert">
    <button type="button" class="close" aria-label="Close" data-dismiss="alert">
        <span aria-hidden="true">×</span>
    </button>
    你正在使用一个 <strong>过时</strong> 的浏览器。请 <a href=https://browsehappy.com/ target=_blank>升级您的浏览器</a>，以提高您的体验。</div>
<![endif]-->
<body>
            <body class="met-navfixed     ny-banner ">
    <header class='met-head navbar-fixed-top' m-id='5' m-type='head_nav' met-imgmask>
    <nav class="navbar navbar-default box-shadow-none head_nav_met_16_4_5     ">
        <div class="container">
            <div class="row">
                                        <h1 hidden>卡卡分发-苹果ios企业签名|苹果app稳定签名|ipa签名|独立证书</h1>
                                                                                                <!-- logo -->
                <div class="navbar-header pull-xs-left">
                    <a href="https://xunlianfang.cn/" class="met-logo vertical-align block pull-xs-left p-y-5" title="卡卡分发-苹果ios企业签名|苹果app稳定签名|ipa签名|独立证书">
                        <div class="vertical-align-middle">
                                                                <img src="static/picture/1555570161.png" alt="卡卡分发-苹果ios企业签名|苹果app稳定签名|ipa签名|独立证书" class="logo addhide">
                                <img src="static/picture/1555569822.png" alt="卡卡分发-苹果ios企业签名|苹果app稳定签名|ipa签名|独立证书" class="logo1 hidden">
                                                    </div>
                    </a>
                </div>
                <!-- logo -->
                <button type="button" class="navbar-toggler hamburger hamburger-close collapsed p-x-5 head_nav_met_16_4_5-toggler" data-target="#head_nav_met_16_4_5-collapse" data-toggle="collapse">
                    <span class="sr-only"></span>
                    <span class="hamburger-bar"></span>
                </button>
                <!-- 会员注册登录 -->
                    
                <!-- 会员注册登录 -->

                <!-- 导航 -->
                <div class="collapse navbar-collapse navbar-collapse-toolbar pull-md-right p-0" id="head_nav_met_16_4_5-collapse">
                    <ul class="nav navbar-nav navlist">
                        <li class='nav-item'>
                        </li>
				<li><a href="<?php echo IN_PATH; ?>">首页</a></li>
               	<li><a href="<?php echo IN_PATH.'index.php/home'; ?>">上传分发</a></li>
				<li><a href="<?php echo IN_PATH.'index.php/cishu'; ?>">分发价格</a></li>
				<li><a href="<?php echo IN_PATH.'index.php/qianming'; ?>">签名价格</a></li>
				<li><a href="<?php echo IN_PATH.'index.php/webview'; ?>">封装价格</a></li>  
				<?php if($GLOBALS['userlogined']){ ?>
				<li><a href="<?php echo IN_PATH.'index.php/home'; ?>">应用管理</a></li>
				<li class="signup"><a href="<?php echo IN_PATH.'index.php/logout'; ?>">退出</a></li>
				<?php }else{ ?>
				<li><a href="<?php echo IN_PATH.'index.php/login'; ?>">立即登录</a></li>
				<li class="signup"><a href="<?php echo IN_PATH.'index.php/reg'; ?>">免费注册</a></li>
				<?php } ?>
                    </li>
                                                                                                                                                    </ul>
                </div>
                <!-- 导航 -->
            </div>
        </div>
    </nav>
</header>

                                                        <section class="banner_met_36_5_1 page-bg"  m-id='10' m-type="banner">
                <div class="Modern-Slider">
                                            <!-- Item -->
                        <div class="item">
                            <div class="img-fill slick-slide">
                                <img class="cover-image"  src="static/picture/1545808037.jpg" alt="苹果 IOS 独立证书签名<br/>长期稳定不掉线" data-height='0|0|0'>
                                                                        <div class="banner-text p-1">
                                        <div class='container'>
                                            <div class='banner-text-con'>
                                                <div>
                                                    <h3 class="animation-slide-bottom font-weight-500" style="color:">极速分发，专注于企业应用安全内测<br/>内测应用</h3>
                                                    <p class="animation-slide-bottom" style='color:'>CDN加速下载 | 支持合并 |<br/> 二维码永久有效 | 自动充值</p>
                                                      <p   href="http://www.ozhong.net/index.php/home" target="_blank">【点击立即分发】</span></a> 
			                                          <br />
					                        	<a href="/index.php/home" class="button alt" target="_blank"></a>
                                       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                                                                                </div>
                        </div>
                        <!-- // Item -->
                                            <!-- Item -->
                        <div class="item">
                            <div class="img-fill slick-slide">
                                <img class="cover-image"  src="static/picture/1545378991.jpg" alt="苹果 ios 企业签名<br/>十分钟 搞定" data-height='0|0|0'>
                                                                        <div class="banner-text p-0">
                                        <div class='container'>
                                            <div class='banner-text-con'>
                                                <div>
                                                    <h3 class="animation-slide-bottom font-weight-500" style="color:">苹果 ios 企业签名<br/>十分钟 搞定</h3>
                                                    <p class="animation-slide-bottom" style='color:'>独立证书 超值稳定 |<br/> 苹果企业签名 | APP 分发 | WEB封装 | APP打包</p>
                                                    <p   href="http://www.ozhong.net/index.php/home" target="_blank">【点击立即签名】</span></a>
													<br />
													<a href="/index.php/qianming" class="button alt" target="_blank"></a>
                                       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                                                                                </div>
                        </div>
                        <!-- // Item -->
                                    </div>
                <div class="bottom-dots-list" role="tablist" style="display: block;">
                                            <div class="">
                        </div>
                                            <div class="">
                        </div>
                                    </div>
            </section>
            
        <div class="countup_met_16_1_49 met-index-countup met-index-body     bgpic" m-id='49'>
    <div class="container text-xs-center">
        <ul class="blocks-xs-2 blocks-md-2 blocks-lg-4 blocks-xxl-4">
                   
                <li>
                    <h5><span class="counter" id="countUp_num_0" data-numto="95271">0</span>+</h5>
                    <span></span>
                    <p>累计应用分发数</p>
                </li>
                        
                <li>
                    <h5><span class="counter" id="countUp_num_1" data-numto="15096">0</span></h5>
                    <span></span>
                    <p>安全运行时间</p>
                </li>
                        
                <li>
                    <h5><span class="counter" id="countUp_num_2" data-numto="365">0</span>+</h5>
                    <span></span>
                    <p>覆盖行业和类目</p>
                </li>
                        
                <li>
                    <h5><span class="counter" id="countUp_num_3" data-numto="27321">0</span>+</h5>
                    <span></span>
                    <p>为开发者打包签名APP</p>
                </li>
                    </ul>
        <div class="product_list_met_16_5_52 met-index-body indexbg     bgcolor" m-id='52'>
    <div class="container">
                                                   <h3 class="animation-slide-bottom font-weight-500" style="color:"><br/>签名套餐（7*24小时）</h3>
        <p class="desc invisible" data-plugin="appear" data-animate="fade" data-repeat="false"></p>
        <div class='blocks blocks-4 slider-product hide'>
                                    <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>共享版（掉包补）</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">150元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>包月 : 150</li>
                                
                                     <li>签名方式 : 网站自助签名</li>
                                
                                     <li>免费无限次更新</li>
                                
                                
                                     <li>备注 : 内测版推荐，稳定性一般</li>
                                                            </ul>
                            <div class="pricing-footer">
     <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td>  
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>共享版（掉包补）</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">400元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>包季 : 400</li>
                                
                                     <li>签名方式 : 网站自助签名</li>
                                
                                     <li>免费无限次更新</li>
                                
                                     <li>备注 : 内测版推荐，稳定性一般</li>
                                                            </ul>
                            <div class="pricing-footer">
     <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td>  
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>独享版（推荐）</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">300元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>包月 : 300元</li>
                                
                                     <li>签名方式 : 网站自助签名</li>
                                
                                     <li>app更新次数 : 免费无限更新；不限次数</li>
                                
                                     <li>备注 : 稳定不掉，适合长期使用客户</li>
                                                            </ul>
                            <div class="pricing-footer">
     <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td>  
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>独享版（推荐）</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">1000元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>包季 : 1000元</li>
                                
                                     <li>签名方式 : 网站自助签名</li>
                                
                                     <li>app更新次数 : 免费无限更新；不限次数</li>
                                
                                     <li>备注 : 稳定不掉，适合长期使用客户</li>
                                                            </ul>
                            <div class="pricing-footer">
     <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td>  
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                            </div>
    </div>
</div>

</div>

        <div class="countup_met_16_1_49 met-index-countup met-index-body     bgpic" m-id='49'>
    <div class="container text-xs-center">
        <ul class="blocks-xs-2 blocks-md-2 blocks-lg-4 blocks-xxl-4">
                                                                
                                                                <h3 class="animation-slide-bottom font-weight-500" style="color:">苹果企业签名步骤<br/></h3>
                                                    <p class="animation-slide-bottom" style='color:'>独立证书 超值稳定 |<br/> 苹果企业签名 | APP 分发 | WEB封装 | APP打包</p>                    
                <li>

                        <img src="http://cdn.misc.66fenfa.cn/66fenfa/img/icon2.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                    <p>第一步</p>
                                      <span></span>
                    <p>购买套餐，如需其他时长的服务请联系在线客服</p>	<p> 在线客服： <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:1787601777:51" alt="点击这里给我发消息" title="点击这里给我发消息"/></a></p>

                </li>
                        
                <li>
                        <img src="http://cdn.misc.66fenfa.cn/66fenfa/img/icon6.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                    <p>第二步</p>
                                      <span></span>
                    <p>客户的IPA包发给客服的QQ或者邮箱1787601777@qq.com，也可以提供网盘下载链接</p>
                </li>
                        
                <li>
                        <img src="http://cdn.misc.66fenfa.cn/66fenfa/img/icon1.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                  <p>第三步</p>
                                      <span></span>
                    <p>技术人员签好IPA包并测试</p>
                </li>
                        
                <li>
                        <img src="http://cdn.misc.66fenfa.cn/66fenfa/img/icon5.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                    <p>第四步</p>
                                      <span></span>
                    <p>客服通过邮箱或者QQ传输给客户</p>
                </li>
                    </ul>
    </div>
</div>
        

        <div class="product_list_met_16_5_52 met-index-body indexbg     bgcolor" m-id='52'>
    <div class="container">
                                                    <h3 class="animation-slide-bottom font-weight-500" style="color:"><br/>自助充值次数</h3>
        <p class="desc invisible" data-plugin="appear" data-animate="fade" data-repeat="false"></p>
        <div class='blocks blocks-4 slider-product hide'>
                                    <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>1000点数</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">10元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>下载页无广告</li>
                                
                                     <li>阿里云CDN加速</li>
                                
                                     <li>支持安卓和苹果合并</li>
                                
                                     <li>自动到账7*24在线充值</li>
                                
                                                            </ul>
                            <div class="pricing-footer">
                            <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td>  
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>5000点数</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">50元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>下载页无广告</li>
                                
                                     <li>阿里云CDN加速</li>
                                
                                     <li>支持安卓和苹果合并</li>
                                
                                     <li>自动到账7*24在线充值</li>
                                
                                                            </ul>
                            <div class="pricing-footer">
                            <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td> 
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>10000点数</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">100元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>下载页无广告</li>
                                
                                     <li>阿里云CDN加速</li>
                                
                                     <li>支持安卓和苹果合并</li>
                                
                                     <li>自动到账7*24在线充值</li>
                                
                                                            </ul>
                            <div class="pricing-footer">
                            <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td> 
                                                                  </a>
                            </div>
                        </div>
                    </div>
                </li>
                            <li>
                    <div class="pricing-list">
                        <div class="pricing-header">
                            <div class="pricing-title padding-15"><h4 class='margin-0 white font-size-20 font-weight-300'>20000点数</h4></div>
                                                                                                            <div class="pricing-price">
                                        <span class="pricing-currency">200元</span>
                                    </div>
                                                                                                                                                                                                                                                                                                                                                        <ul class="pricing-features">
                                        
                                     <li>下载页无广告</li>
                                
                                     <li>阿里云CDN加速</li>
                                
                                     <li>支持安卓和苹果合并</li>
                                
                                     <li>自动到账7*24在线充值</li>
                                
                                                            </ul>
                            <div class="pricing-footer">
                            <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=10  ">购买</a></td> 
                                </a>
                            </div>
                        </div>
                    </div>
                </li>
                            </div>
    </div>
</div>

</div>

        <div class="countup_met_16_1_49 met-index-countup met-index-body     bgpic" m-id='49'>
    <div class="container text-xs-center">
        <ul class="blocks-xs-2 blocks-md-2 blocks-lg-4 blocks-xxl-4">
                                                                <h3 class="animation-slide-bottom font-weight-500" style="color:">合作案例<br/></h3>
                                                    <p class="animation-slide-bottom" style='color:'>独立证书 超值稳定 |<br/> 苹果企业签名 | APP 分发 | WEB封装 | APP打包</p>                    
                <li>
                        <img src="https://www.35tui.cn/skin/images/cooperative-icon07.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                    <p></p>
                </li>
                        
                <li>
                        <img src="https://www.35tui.cn/skin/images/cooperative-icon03.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                    <p></p>
                </li>
                        
                <li>
                        <img src="https://www.35tui.cn/skin/images/cooperative-icon06.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                    <p></p>
                </li>
                </li>
                        
                <li>
                        <img src="https://www.35tui.cn/skin/images/cooperative-icon02.png" class="img-responsive center-block" style="max-width:160px">
                    <span></span>
                    <p></p>
                </li>
                </li>
                    </ul>
    </div>
</div>


                                            <!-- Item -->
           
                                        <div class='container'>
                                            <div class='banner-text-con'>
                                                <div>
                                                    <h3 class="animation-slide-bottom font-weight-500" style="color:">常见问题<br/></h3>
                                                   
                                       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
        <!--常见问题-->
        <div class="container">
            <div class="help help1">
   
                <div class="blue-line"></div>
                <dl>
                    <dt class="clearfix">
                        <span class="left">Q ：</span>
                        <span class="right">支持APK包和IPA包同一个二维码下载吗？</span>
                    </dt>
                    <dd class="clearfix">
                        <span class="left">A ：</span>
                        <span class="right">支持，上传好APK包和IPA包后，在【我的应用】中，选择要合并的APP，点击合并应用即可。</span>
                    </dd>
                </dl>
                <dl>
                    <dt class="clearfix">
                        <span class="left">Q ：</span>
                        <span class="right">超过每天下载次数，APP还能下载吗？</span>
                    </dt>
                    <dd class="clearfix">
                        <span class="left">A ：</span>
                        <span class="right">不能下载。请根据自己推广的需要，购买次数包，购买后，次数立即到账，即可下载。</span>
                    </dd>
                </dl>
                <dl>
                    <dt class="clearfix">
                        <span class="left">Q ：</span>
                        <span class="right">如何查看APP下载次数？</span>
                    </dt>
                    <dd class="clearfix">
                        <span class="left">A ：</span>
                        <span class="right">登录爱发布，点击右上角账号，选择【我的服务】，便能查看剩余下载次数</span>
                    </dd>
                </dl>
                <dl>
                    <dt class="clearfix">
                        <span class="left">Q ：</span>
                        <span class="right">APP上传有大小限制吗？</span>
                    </dt>
                    <dd class="clearfix">
                        <span class="left">A ：</span>
                        <span class="right">有，上传APP支持600M以内的APP。</span>
                    </dd>
                </dl>
            </div>
        </div>
        <!--/常见问题-->
    </div>
    </div>


				</h4>
			</li>
					</ul>
	</div>
</div>

                                               <footer class="link_met_11_1_44 text-xs-center" m-id='44' m-type="link">
            <div class="container p-y-15">
                <ul class="breadcrumb p-0 link-img m-0">
                    <li class='breadcrumb-item'>友情链接 :</li>
                                            <li class='breadcrumb-item     split'>
                            <a href="https://bichuse.com/" title="苹果企业签名"  target="_blank">
                                                                        <span>苹果企业签名</span>
                                                            </a>
                        </li>
                                            <li class='breadcrumb-item     split'>
                            <a href="https://i690.cn/" title="ios企业签名"  target="_blank">
                                                                        <span>ios企业签名</span>
                                                            </a>
                        </li>
                                    </ul>
            </div>
        </footer>
    

        <footer class='foot_info_met_16_1_2 met-foot border-top1' m-id='2' m-type='foot'>
	<div class="container text-xs-center">
		    		<p>Copyright © 2019 极速度分发      本站只做市场稳定签名，绝对超值，无需审核无需越狱，欢迎选择    
				    						    		<p> 客服： <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:1787601777:51" alt="点击这里给我发消息" title="点击这里给我发消息"/></a></p>
				    		    		    		<div class="powered_by_metinfo"></div>
		<ul class="met-langlist p-0">
		    		    	    </ul>
	</div>
</footer>
    
        <button type="button" class="btn btn-icon btn-primary btn-squared back_top_met_16_1_3 met-scroll-top     " hidden m-id='3' m-type='nocontent'>
	<i class="icon wb-chevron-up" aria-hidden="true"></i>
</button>

<input type="hidden" name="met_lazyloadbg" value="">
<script src="static/js/basic.js" data-js_url="https://xunlianfang.cn/templates/yvbmrsza/cache/index_cn.js?1557130549" id="met-page-js"></script>
<script src="static/js/lang_json_cn.js"></script>
</body>
</html>