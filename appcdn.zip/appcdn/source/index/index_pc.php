<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>极速分发 - 免费应用内测托管平台|APP应用分发|IOS分发|Android分发</title>
    <meta name="keywords" content="APP内测,APP内测平台,APP内测托管平台,内测分发,免费托管,app分发,免费安装,beta测试,ipa,apk,安卓,苹果应用,二维码下载,UDID,iOS内测,Android内测,beta test,app,极速分发">
    <meta name="description" content="极速分发 - 免费为您提供APP应用内测、应用托管、内测分发、兼容测试等服务,为客户提供APP内测托管平台和免费的应用下载分发渠道!">    

    <link rel="stylesheet" type="text/css" href="<?php echo IN_PATH; ?>index/css/component.css">
    <link rel="stylesheet" type="text/css" href="<?php echo IN_PATH; ?>index/css/new-layout.css">
    <link rel="stylesheet" type="text/css" href="<?php echo IN_PATH; ?>index/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo IN_PATH; ?>index/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo IN_PATH; ?>index/css/new-index.css">
<script type="text/javascript">



        var allowsize = ;



        var uploadedsize = ;



        var singlesize = ;



        var uptoken = '';



        var qndomain = '';



        var uptype = ;



        var tianshu = ;



        var flash_swf_url = "static/images/Moxie.swf";



        var silverlight_xap_url = "static/images/Moxie.xap";



        var gettoken = "/index/gettoken.html";



        var bdupload = "/index/uploadbd.html";



        var upload = "/index/upload.html";



    </script>
<script type="text/javascript" src="<?php echo IN_PATH; ?>index/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php echo IN_PATH; ?>index/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo IN_PATH; ?>index/js/jszip.min.js"></script>
    <script type="text/javascript" src="<?php echo IN_PATH; ?>index/js/base64.min.js"></script>
    <script type="text/javascript" src="<?php echo IN_PATH; ?>index/js/common.js"></script>



<meta http-equiv="Content-Type" content="text/html; charset=gb2312"></head>
<body>
<!-- 手机端未登录 start -->
<div class="hamburger">
<div class="hamburger-bg"></div>
    <div class="mobile-sidebar">
         <!-- 未登录样式 -->
        <div class="mobile-member">
               <a href="/index.php/home" class="bor1 i-login">登录</a>
               <a href="/index.php/reg" class="register-btn">注册</a>
         </div>
                    <!-- 登录后样式 end -->
            <ul>
                <li><a href="/index.php/login"><i class="fa fa-paper-plane-o"></i>上传APP</a></li>
                <li><a href="/index.php/home"><i class="fa fa-folder-o"></i>应用管理</a></li>
                <li><a href="/index.php/install"><i class="fa fa-money"></i>分发套餐</a></li>
                <li><a href="/index.php/webview"><i class="fa fa-share-alt"></i>APP封装</a></li>
                <li><a href="http://wpa.qq.com/msgrd?v=3&amp;uin=1787601777&amp;site=qq&amp;menu=yes"><i class="fa fa-file-text-o"></i>我的客服</a></li>
            </ul>

    </div>
</div>
<!-- 手机端未登录 end -->
<!-- 头部导航 -->
<div class="header container-fluid">
    <a href="/index.html"><img src="static/picture/logo_nav.png" alt="" class="logo"></a>
    <ul class="nav">
        <li class="active"><a href="/index.php/login">上传APP</a></li>
        <li><a href="/index.php/install">分发套餐</a></li>
      	<li><a href="/index.php/webview">封装APP</a></li>
        <li class="serve-trigger"><a href="javascript:;">服务<i class="fa fa-angle-down"></i></a>
             <div class="nav-down" style="display: none;">
             </div>
        </li>
    </ul>
    <a href="javascript:;" class="hamburger-btn"><img src="static/picture/index-hbtn_01.png" alt=""></a>
    <div class="member">

          <?php if($GLOBALS['userlogined']){ ?>
	<a href="<?php echo IN_PATH.'index.php/home'; ?>" style="margin-right:20px">应用管理</a>
	<a href="<?php echo IN_PATH.'index.php/logout'; ?>">退出</a>
	<?php }else{ ?>
	<a href="/index.php/login" class="on mr18 i-login">登录</a>
	<a href="<?php echo IN_PATH.'index.php/reg'; ?>"  class="register-btn">免费注册</a>
				<?php } ?>
        </div>

            <div class="clear"></div>
</div>

<style type="text/css">
     .header{padding: 36px 15px 0 15px;width: 100%;}
      @media(max-width:1200px){
     .header{width: 100%;}
       }
       @media (max-width:768px) {
         .serve{height: auto;}
    .serve .serve-content{padding:0 10px;}
    .serve .serve-content li{padding: 0 10px;}
       }
</style>
<!-- banner -->
<div class="banner container-fluid">
    <h1>互联网云分发平台</h1>
    <span>
        <a href="/index.php/home">iOS-APP</a>
        <a href="/index.php/home">Android-APP</a>
    </span>
    <p>国际CDN加速，每天免费高速下载，下载地址自定义，永久唯一</p>
    <div class="">
        <a href="/index.php/home" class="btn-uploading i-login">上传应用</a>
    </div>

</div>
<!-- 提供的服务 -->
<div class="serve">
      <h2>提供服务</h2>
      <ul class="row serve-content">
          <li class="col-sm-4 col-xs-12">
              <div class="plate">
                    <div class="plate-top">
                        <img src="static/picture/new-index-pic_03.png" alt="">
                        <h3>自定义下载页面</h3>
                    </div>
                    <div class="plate-bot">
                        <p>微信、QQ防屏蔽链接技术，一个推广链接可永久使用</p>
                    </div>
              </div>
          </li>
          <li class="col-sm-4 col-xs-12">
                <div class="plate">
                    <div class="plate-top">
                        <img src="static/picture/new-index-pic_06.png" alt="">
                        <h3>防屏蔽</h3>
                    </div>
                    <div class="plate-bot">
                            <p>微信、QQ防屏蔽链接技术，一个推广链接可永久使用</p>
                    </div>
                </div>
          </li>
          <li class="col-sm-4 col-xs-12">
                <div class="plate">
                    <div class="plate-top">
                        <img src="static/picture/new-index-pic_09.png" alt="">
                        <h3>每天免费</h3>
                    </div>
                    <div class="plate-bot">
                            <p>注册用户每日免费10次下载</p>
                    </div>
                </div>
          </li>
      </ul>
</div>
<!-- 专家测试 -->
<div class="test">
     <h2>专家测试</h2>
     <p class="test-intro">专业解决移动应用测试和应用上线问题，用专业的角度和细致的排查为App的测试上线保驾护航</p>
    <ul class="test-bot row hi-icon-wrap hi-icon-effect-8">
        <li class="col-md-4 col-xs-6">
            <div class="test-margin">
            <a href="javascript:;" class="hi-icon"><img src="static/picture/tubiao_03.png" alt=""></a>
            <div class="explain">
                <h4>兼容性测试</h4>
                <p>适配市场99%以上主流机型</p>
            </div>
            <div class="clear"></div>
        </div>
        </li>
        <li class="col-md-4 col-xs-6">
            <div class="test-margin">
            <a href="javascript:;" class="hi-icon"><img src="static/picture/tubiao_05.png" alt=""></a>
            <div class="explain">
                <h4>Bug探索测试</h4>
                <p>深度挖掘细分模块功能性测试</p>
            </div>
            <div class="clear"></div>
        </div>
        </li>
        <li class="col-md-4 col-xs-6">
            <div class="test-margin">
            <a href="javascript:;" class="hi-icon"><img src="static/picture/tubiao_07.png" alt=""></a>
            <div class="explain">
                <h4>安全性测试</h4>
                <p>市场最权威漏洞库进行对比</p>
            </div>
            <div class="clear"></div>
            </div>
        </li>
        <li class="col-md-4 col-xs-6">
            <div class="test-margin">
            <a href="javascript:;" class="hi-icon"><img src="static/picture/tubiao_12.png" alt=""></a>
            <div class="explain">
                <h4>IOS加速审核</h4>
                <p>最快2小时可通过App Store审核</p>
            </div>
            <div class="clear"></div>
        </div>
        </li>
        <li class="col-md-4 col-xs-6">
            <div class="test-margin">
            <a href="javascript:;" class="hi-icon"><img src="static/picture/tubiao_15.png" alt=""></a>
            <div class="explain">
                <h4>iOS上线预审</h4>
                <p>对App Store 拒绝上架说不</p>
            </div>
            <div class="clear"></div>
        </div>
        </li>
        <li class="col-md-4 col-xs-6">
            <div class="test-margin">
            <a href="javascript:;" class="hi-icon"><img src="static/picture/tubiao_17.png" alt=""></a>
            <div class="explain">
                <h4>App Store视频制作</h4>
                <p>给产品一个动人心魄的宣传</p>
            </div>
            <div class="clear"></div>
        </div>
        </li>
    </ul>
</div>
<!-- 合作伙伴 -->
<div class="partner">
    <h2>合作伙伴</h2>
    <ul class="row">
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_03.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_04.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_05.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_06.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_07.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_08.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_10.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_11.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_12.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_13.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_14.png" alt=""></li>
            <li class="col-md-2 col-sm-4 col-xs-6"><img src="static/picture/partner_15.png" alt=""></li>
        </ul>
      <link rel="stylesheet" href="static/css/qq.css">
    <div class="main-im">
      <div class="im_main" id="im_main" style="display: block;">

      </div>
    </div>
  </ul>    
</div>
<<div class="footer">
  <span>分发      <a target="_blank" href="/index.php/a"  target="_blank">服务协议</a></li>
 </span><br/>
  <span>分发 .All Rights Reserved.  声明：本平台仅供应用内测使用，请勿上传非法应用。如违规违法上传应用一切后果有上传者承担</span><br/>
  <span>Copyright &#169; 2012-2018 bichuse.com All Rights Reserved. <i class="m-icp">联系QQ：373230036</i> </span>
</body>
</html>


<script src="static/js/jquery-2.1.1.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/jquery-ui.min.js"></script>
<script src="static/js/new-buywindow.js"></script>
<script src="static/js/new-member.js"></script>
<script>
	$(function(){
		var aboutWidth = $(".about").width();
		$(".process-timeline").width(aboutWidth);
		var lastRightSpeed = 40; //控制拖动到最右边点是否对准时间刻度线上
		var processtimelineW = $(".process-timeline").width();
		var processrowLength = $(".process-body").find('.process-row').length;
		var processbodyNumber = processrowLength*150;
		$(".process-body").css({"width":processbodyNumber});
		if(processrowLength < 5) 
		{
			$("#draggable").draggable('disable');
			return;
		}
		$("#draggable").draggable({
			cursor: "move",
			axis: 'x',
			grid: [50, 20],
			stop: function(event, ui){
				var FleftNumber = parseInt($("#draggable").css("left"));
				if (FleftNumber > 0) {
					$("#draggable").animate({"left": 0}, 500);
					return;
				};
				var leftNumber = Math.abs(FleftNumber);
				leftNumber = leftNumber + processtimelineW;
				if (leftNumber > processbodyNumber) 
				{
					leftNumber = processbodyNumber;
					$("#draggable").animate({"left": -(leftNumber-processtimelineW + lastRightSpeed)}, 500);
				}
			}
		});


 
});
</script>
  <div class="mpa-sc account-switcher" data-z="100" style="display: block;"></div><div class="mpa-sc article-gatherer new mpa-rootsc" data-z="100" style="display: block;" id="mpa-rootsc-article-gatherer"></div><div class="mpa-sc image-gatherer new mpa-rootsc" data-z="100" style="display: block;" id="mpa-rootsc-image-gatherer"></div><div class="mpa-sc page-clipper new mpa-rootsc" data-z="100" style="display: block;" id="mpa-rootsc-page-clipper"></div><div class="mpa-sc mp-analysis-datas-gatherer new mpa-rootsc" data-z="100" style="display: block;" id="mpa-rootsc-mp-analysis-datas-gatherer"></div><div class="mpa-sc notifier new mpa-rootsc" data-z="110" style="display: block;" id="mpa-rootsc-notifier"></div>
  </body></html>