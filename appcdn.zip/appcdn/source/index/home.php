<?php
if(!defined('IN_ROOT'))
{
	exit('Access denied');
}
;
echo '';
if(!$GLOBALS['userlogined'])
{
	exit(header('location:'.IN_PATH.'index.php/login'));
}
;
echo '';
$ios = $GLOBALS['db']->num_rows($GLOBALS['db']->query("select count(*) from ".tname('app')." where in_form='iOS' and in_uid=".$GLOBALS['erduo_in_userid']));
$android = $GLOBALS['db']->num_rows($GLOBALS['db']->query("select count(*) from ".tname('app')." where in_form='Android' and in_uid=".$GLOBALS['erduo_in_userid']));
$home = explode('/',$_SERVER['PATH_INFO']);
$string = isset($home[2]) ?$home[2] : NULL;
if(empty($string))
{
	$query = $GLOBALS['db']->query("select * from ".tname('app')." where in_uid=".$GLOBALS['erduo_in_userid']." order by in_addtime desc");
}
elseif(is_numeric($string))
{
	$form = $string == 1 ?'iOS': 'Android';
	$query = $GLOBALS['db']->query("select * from ".tname('app')." where in_form='".$form."' and in_uid=".$GLOBALS['erduo_in_userid']." order by in_addtime desc");
}
else
{
	$key = SafeSql(trim(is_utf8($string)));
	$query = $GLOBALS['db']->query("select * from ".tname('app')." where in_name like '%".$key."%' and in_uid=".$GLOBALS['erduo_in_userid']." order by in_addtime desc");
}
;
echo '<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta http-equiv="x-ua-compatible" content="IE=edge">
<meta name="renderer" content="webkit">
<meta charset="';
echo IN_CHARSET;
;
echo '">
<title>我的应用 - ';
echo IN_NAME;
;
echo '</title>
<link href="';
echo IN_PATH;
;
echo 'static/index/icons.css" rel="stylesheet">
<link href="';
echo IN_PATH;
;
echo 'static/index/bootstrap.css" rel="stylesheet">
<link href="';
echo IN_PATH;
;
echo 'static/index/manage.css" rel="stylesheet">
<script type="text/javascript" src="';
echo IN_PATH;
;
echo 'static/pack/layer/jquery.js"></script>
<script type="text/javascript" src="';
echo IN_PATH;
;
echo 'static/pack/layer/confirm-lib.js"></script>
<script type="text/javascript" src="';
echo IN_PATH;
;
echo 'static/index/uploadify.js"></script>
<script type="text/javascript" src="';
echo IN_PATH;
;
echo 'static/index/profile.js"></script>
<script type="text/javascript" src="';
echo IN_PATH;
;
echo 'static/index/drop.js"></script>
<script type="text/javascript">
var in_path = \'';
echo IN_PATH;
;
echo '\';
var in_time = \'';
echo $GLOBALS['erduo_in_userid'].'-'.time();
;
echo '\';
var in_upw = \'';
echo $GLOBALS['erduo_in_userpassword'];
;
echo '\';
var in_uid = ';
echo $GLOBALS['erduo_in_userid'];
;
echo ';
var in_id = 0;
var in_size = ';
echo intval(ini_get('upload_max_filesize'));
;
echo ';
var remote = {\'open\':\'';
echo IN_REMOTE;
;
echo '\',\'dir\':\'';
echo IN_REMOTEPK;
;
echo '\',\'version\':\'';
echo version_compare(PHP_VERSION,'5.5.0');
;
echo '\'};
layer.use(\'confirm-ext.js\');
</script>
</head>
<body>
<div class="navbar-wrapper ng-scope">
	<div class="ng-scope">
		<div class="navbar-header-wrap">
			<div class="middle-wrapper">
				<sidebar class="avatar-dropdown">
				<img class="img-circle" src="';
echo getavatar($GLOBALS['erduo_in_userid']);
;
echo '">
				<div class="name"><span class="ng-binding">';
echo substr($GLOBALS['erduo_in_username'],0,strpos($GLOBALS['erduo_in_username'],'@'));
;
echo '</span></div>
				<div class="email"><span class="ng-binding">';
echo $GLOBALS['erduo_in_username'];
;
echo '</span></div>
				<div class="dropdown-menus">
					<ul>
						<li><a href="';
echo IN_PATH.'index.php/profile_info';
;
echo '" class="ng-binding">个人资料</a></li>
						<li><a href="';
echo IN_PATH.'index.php/profile_pwd';
;
echo '">修改密码</a></li>
						<li><a href="';
echo IN_PATH.'index.php/profile_verify';
;
echo '">实名认证</a></li>
						<li><a href="';
echo IN_PATH.'index.php/logout';
;
echo '" class="ng-binding">退出</a></li>
					</ul>
				</div>
				</sidebar>
				<nav>
				<h1 class="navbar-title logo"><span onclick="location.href=\'';
echo IN_PATH;
;
echo '\'">';
echo $_SERVER['HTTP_HOST'];
;
echo '</span></h1>
				<i class="icon-angle-right"></i>
				<div class="navbar-title primary-title"><a href="';
echo IN_PATH.'index.php';
;
echo '" class="ng-binding">首页</a></div>
<i class="icon-angle-right"></i>
				<div class="navbar-title primary-title"><a href="';
echo IN_PATH.'index.php/home';
;
echo '" class="ng-binding">我的应用</a></div>
				</nav>
				</nav>
			</div>
		</div>
		<div class="pop-up-mask apitoken" style="display:none"></div>
		<div class="pop-up-layer ng-scope" style="display:none">
			<div class="apitoken-win ng-scope">
				<h2 class="apitoken-title">已用：';
echo formatsize($GLOBALS['erduo_in_spaceuse']);
;
echo '</h2>
				<h2 class="apitoken-title">总量：';
echo $GLOBALS['erduo_in_spacetotal'] >0 ?$GLOBALS['erduo_in_spacetotal'] / 1048576 : 0;
;
echo ' MB ≈ ';
echo formatsize($GLOBALS['erduo_in_spacetotal']);
;
echo '</h2>
				<div class="apitoken-desc">每 <big style="color:#f87335">MB</big> 扩充需扣除 <big style="color:#f87335">';
echo IN_SPACEPOINTS;
;
echo '</big> 下载点数</div>
				<div class="apitoken-action"><a class="apitoken-build rounded ng-hide" style="cursor:pointer" onclick="add_space(0, 0)">扩充容量</a></div>
				<i class="icon-cross" onclick="$(\'.pop-up-mask\').hide(),$(\'.pop-up-layer\').hide()"></i>
			</div>
		</div>
	</div>
</div>
<div class="ng-scope" id="dialog-uploadify" style="display:none">
	<div class="upload-modal-mask ng-scope"></div>
	<div class="upload-modal-container ng-scope">
		<div class="flip-container flip">
			<div class="modal-backend plane-ready upload-modal">
				<div class="btn-close" onclick="location.reload()"><i class="icon-cross"></i></div>
				<div class="plane-wrapper">
					<img class="plane" src="';
echo IN_PATH;
;
echo 'static/index/plane.svg">
					<div class="rotate-container">
						<img class="propeller" src="';
echo IN_PATH;
;
echo 'static/index/propeller.svg">
					</div>
				</div>
				<div class="progress-container">
					<p class="speed ng-binding" id="speed-uploadify"></p>
					<p class="turbo-upload"></p>
					<div class="progress">
						<div class="growing" style="width:0%"></div>
					</div>
				</div>
				<div class="redirect-tips ng-binding" style="display:none">正在解析应用，请稍等...</div>
			</div>
		</div>
	</div>
</div>
<section class="ng-scope">
<div class="page-apps ng-scope">
	<div class="middle-wrapper">
		<div class="filter-group">
			<div class="filter-set">
				<span class="filter';
if($string == 1)
{
	echo ' active';
}
;
echo '" onclick="location.href=\'';
echo IN_PATH.'index.php/home/1';
;
echo '\'"><i class="icon-apple"></i></span>
				<i class="split"></i>
				<span class="filter';
if($string == 2)
{
	echo ' active';
}
;
echo '" onclick="location.href=\'';
echo IN_PATH.'index.php/home/2';
;
echo '\'"><i class="icon-android"></i></span>
			</div>
			<div class="search-form">
				<i class="icon-search" onclick="s_earch()"></i>
				<input type="text" id="k_eyword" onkeydown="if(event.keyCode==13){s_earch()}" placeholder="输入名称搜索">
			</div>
			<div class="surplus-wrap">
				<div class="surplus">
					<div class="surplus-card">
						<div class="name"><span>剩余下载点数</span></div>
						<div class="value"><span class="ng-binding">';
echo $GLOBALS['erduo_in_points'];
;
echo '</span></div>
					</div>
					<div class="surplus-card" style="color:#268df7;">
						<div class="name">购买点数包</div>
						<button type="button" onclick="location.href=\'';
echo IN_PATH.'index.php/cishu';
;
echo '\'" class="btn action"><i class="icon icon-cart"></i></button>
					</div>
					<div class="surplus-card" style="color:#268df7;">
						<div class="name">购买证书签名</div>
						<button type="button" onclick="location.href=\'';
echo IN_PATH.'index.php/qianming';
;
echo '\'" class="btn action"><i class="icon icon-cart"></i></button>
					</div>
				</div>
			</div>
		</div>
		<div class="row row-apps-top">
			<div class="col-xs-3">
				<a href="';
echo IN_PATH.'index.php/home/1';
;
echo '" class="banner-column">
					<div class="font-en">iOS应用</div>
					<div>';
echo $ios;
;
echo '</div>
				</a>
			</div>
			<div class="col-xs-3">
				<a href="';
echo IN_PATH.'index.php/home/2';
;
echo '" class="banner-column">
					<div class="font-en">Android应用</div>
					<div>';
echo $android;
;
echo '</div>
				</a>
			</div>
			<div class="col-xs-3">
				<a class="banner-column" style="cursor:pointer" onclick="$(\'.pop-up-mask\').show(),$(\'.pop-up-layer\').show()">
					<div class="font-en">已用容量</div>
					<div style="font-weight:bold">';
echo $GLOBALS['erduo_in_spaceuse'] >0 ?round($GLOBALS['erduo_in_spaceuse'] / $GLOBALS['erduo_in_spacetotal'] * 100,2) : 0;
;
echo '%</div>
				</a>
			</div>
			<div class="col-xs-3">
				<a href="';
echo IN_PATH.'index.php/profile_verify';
;
echo '" class="banner-column">
					<div class="font-en">实名认证</div>
					<div style="font-weight:bold">';
echo $GLOBALS['erduo_in_verify'] >0 ?$GLOBALS['erduo_in_verify'] >1 ?'审核中': '已认证': '未认证';
;
echo '</div>
				</a>
			</div>
		</div>
	</div>
    <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1787601777&amp;site=qq&amp;menu=yes">
  <div style="width:58%;height:30px; margin:0 auto; border:1px dashed #D7DF01;" ><div style=" float:left;margin-top:4px;" ><img src="/static/guide/music143.png" width="22" height="22"></div>
    <div>
	<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1787601777&amp;site=qq&amp;menu=yes">
  <marquee style="  color:#FE2E64; margin:0; width:92%;  padding:0;line-height:30px;" direction=center behavior=alternate loop=0 scrollamount=3 scrolldelay=10  hspace=10 vspace=0 onmouseover=this.stop() onmouseout=this.start()>极致分发2018.12.13更新为正式版，欢迎注册使用，阿里云DNS极致下载（之前测试版用户请重新注册永久使用）！</marquee>
    </a>
	</div>
  </div>
	<div class="middle-wrapper container-fluid">
		<div class="apps row">
			<upload-card class="components-upload-card col-xs-4 col-sm-4 col-md-4 app-animator">
			<div class="card text-center">
				<input type="file" id="upload_app" onchange="upload_app()" style="display:none">
				<div class="dashed-space" onclick="$(\'#upload_app\').click()">
					<table><tbody><tr><td>
						<i class="icon-upload-cloud2"></i>
						<div class="text drag-state"><span id="_drop1">拖拽到这里上传</span><span id="_drop2">快松手</span></div>
					</td></tr></tbody></table>
				</div>
			</div>
			<div class="upload-guied"';
if(!$ios &&!$android)
{
	echo ' style="display:block"';
}
;
echo '>
				<span class="ng-scope">在这里上传你的第一个应用</span>
				<img src="';
echo IN_PATH;
;
echo 'static/index/arrow.png">
			</div>
			</upload-card>
			';
while($row = $GLOBALS['db']->fetch_array($query))
{
	$class = $row['in_form'] == 'iOS'?'icon-apple': 'icon-android';
	echo '<div class="col-xs-4 col-sm-4 col-md-4 app-animator ng-scope"><div class="card app card-ios">';
	echo '<i class="type-icon '.$class.'"></i><div class="type-mark"></div>';
	echo '<a class="appicon" href="'.IN_PATH.'index.php/each_app/'.$row['in_id'].'"><img class="icon ng-isolate-scope" width="100" height="100" src="'.geticon($row['in_icon']).'" onerror="this.src=\''.IN_PATH.'static/app/'.$row['in_form'].'.png\'"></a>';
	if($row['in_kid'])
	{
		echo '<div class="combo-info ng-scope"><i class="icon-combo"></i><img class="icon ng-isolate-scope" width="45" height="45" src="'.geticon(getfield('app','in_icon','in_id',$row['in_kid'])).'" onerror="this.src=\''.IN_PATH.'static/app/'.getfield('app','in_form','in_id',$row['in_kid']).'.png\'"></div>';
	}
	echo '<br><p class="appname"><i class="icon-owner"></i><span class="ng-binding">'.$row['in_name'].'</span></p>';
	echo '<table><tbody>';
	if(IN_SIGN &&$row['in_form'] == 'iOS删除文字显示签名开通')
	{
		echo '<tr><td class="ng-binding">签名期限：</td><td><span class="ng-binding"><a href="'.IN_PATH.'index.php/price/'.$row['in_id'].'">'.($row['in_sign'] ?date('Y-m-d H:i:s',$row['in_sign']) : '未在本站开通').'</a></span></td></tr>';
	}
  	if(IN_SIGN &&$row['in_form'] == '')
	{
		echo '<tr><td class="ng-binding">签名期限：</td><td><span class="ng-binding"><a href="'.IN_PATH.'index.php/sign_app/'.$row['in_id'].'">'.($row['in_sign'] ?date('Y-m-d H:i:s',$row['in_sign']) : '未在本站开通签名').'</a></span></td></tr>';
	}
	else
	{
		echo '<tr><td class="ng-binding">应用大小：</td><td><span class="ng-binding">'.formatsize($row['in_size']).'</span></td></tr>';
	}
	echo '<tr><td class="ng-binding">应用平台：</td><td><span class="ng-binding">'.$row['in_form'].'</span></td></tr>';
	echo '<tr><td class="ng-binding">应用标识：</td><td><span class="ng-binding">'.$row['in_bid'].'</span></td></tr>';
	echo '<tr><td class="ng-binding">最新版本：</td><td><span class="ng-binding">'.$row['in_bsvs'].'（Build '.$row['in_bvs'].'）</span></td></tr>';
    echo '<tr><td class="ng-binding">下载次数：</td><td class="ng-binding">累计下载 ';
    echo $row['in_hits'];
	echo '</tbody></table>';
	echo '<div class="action"><a class="ng-binding" href="'.IN_PATH.'index.php/profile_app/'.$row['in_id'].'"><i class="icon-pen"></i> 管理</a><a href="'.getlink($row['in_id']).'" target="_blank" class="ng-binding"><i class="icon-eye"></i> 预览</a><button class="btn btn-remove ng-scope" onclick="del_app('.$row['in_id'].', 1)"><i class="icon icon-trash"></i></button></div>';
	echo '</div></div>';
}
;
echo '		</div>
	</div>
</div>
</section>
';
if(IN_VERIFY >0 &&$GLOBALS['erduo_in_verify'] <1)
{
	;
	echo '<div class="alert-bar">
	<div class="action close_bar" onclick="$(\'.alert-bar\').hide()"></div>
	<div class="inner"><p class="ng-binding">应上级要求，未实名认证用户无法上传应用<a href="';
	echo IN_PATH.'index.php/profile_verify';
	;
	echo '" class="btn btn-lemon" style="margin-left:20px">马上认证</a></p></div>
</div>';
}
;
echo '';
include 'source/index/bottom.php';
;
echo '</body>
</html>';
?>