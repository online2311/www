
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="gbk">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="分发平台,app应用分发,ios分发,安卓分发,二维码分发平�?app分发,网站封装app,应用分发平台">
<meta name="description" content="app分发平台提供APP分发、ios分发、安卓分发、应用托管、内测分发、兼容测试、UDID等服�?真正为开发者着想的APP分发托管平台�?>
<title>极速分发平�?</title>
<link href="/static/index/icons.css" rel="stylesheet">
<link href="/static/index/bootstrap.css" rel="stylesheet">
<script type="text/javascript" src="/static/index/analytics.js"></script>

</head>
<body>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="gbk">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="分发平台,app应用分发,ios分发,安卓分发,二维码分发平�?app分发,网站封装app,应用分发平台">
<meta name="description" content="app分发平台提供APP分发、ios分发、安卓分发、应用托管、内测分发、兼容测试、UDID等服�?真正为开发者着想的APP分发托管平台�?>
<title>极速分发平�?</title>
<link href="static/css/icons.css" rel="stylesheet">
<link href="static/css/bootstrap.css" rel="stylesheet">
<script type="text/javascript" src="static/js/analytics.js"></script>

</head>
<body>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="极速分发，极速app证书签名 ios棋牌游戏签名 ipa封装签名证书打包代ios签名">
<meta name="keywords" content="apk,android,ipa,ios,iphone,ipad,app分发,应用托管,企业签名">
<meta name="description" content="分发分发为各行业提供ios企业签名、app应用托管分发服务�?>
<title>分发 - App托管服务分发平台|安卓应用托管|iOS分发|ipa企业签名</title>
<link href="static/css/icons_1.css" rel="stylesheet">
<link href="static/css/bootstrap_1.css" rel="stylesheet">

<script type="text/javascript">
var startTime = new Date();
var reg_link = '/index.php/reg';
var letter_doodle = ["B","e","t","a","A","p","p","H","o","s","t","<br>","{","<br>","     ","r","e","t","u","r","n"," ",'"',"9","1","d","s",".","v","i","p",'"',"<br>","}"];
var end_letter_doodle = '<i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">9</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">1</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">d</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">s</i><i class="icon-comma trans"></i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">v</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">i</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">p</i>';
</script>
  
  <!-- Vendor styles -->
  <link rel="stylesheet" href="static/css/font-awesome.css">
  <link rel="stylesheet" href="static/css/metismenu.css">
  <link rel="stylesheet" href="static/css/animate.css">
  <link rel="stylesheet" href="static/css/bootstrap.min.css">

  <!-- App styles -->
  <link rel="stylesheet" href="static/css/pe-icon-7-stroke.css">
  <link rel="stylesheet" href="static/css/helper.css">
  <link rel="stylesheet" href="static/css/style.css">
  <link rel="stylesheet" href="static/css/custom.css">
  <link rel="stylesheet" href="static/css/sidebar.css">
  <link rel="stylesheet" href="static/css/menu.css">
<link rel="stylesheet" href="static/css/signature.css">
<style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style><style id="style-1-cropbar-clipper">/* Copyright 2014 Evernote Corporation. All rights reserved. */
.en-markup-crop-options {
    top: 18px !important;
    left: 50% !important;
    margin-left: -100px !important;
    width: 200px !important;
    border: 2px rgba(255,255,255,.38) solid !important;
    border-radius: 4px !important;
}

.en-markup-crop-options div div:first-of-type {
    margin-left: 0px !important;
}

</style>

<style type="text/css" id="MEIQIA-ICON-STYLE">.MEIQIA-ICON { background-size: 40px auto !important; background-repeat: no-repeat !important; background-image: url("static/images/icon-mq.png") !important; } @media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (min--moz-device-pixel-ratio: 2), only screen and (-o-min-device-pixel-ratio: 2/1), only screen and (min-device-pixel-ratio: 2) { .MEIQIA-ICON { background-image: url("static/images/icon-mq@2x.png") !important; } } .MEIQIA-ICON-CHAT1 { background-position: 0 0 !important; } .MEIQIA-ICON-CHAT2 { background-position: 0 -20px !important; } .MEIQIA-ICON-CHAT3 { background-position: 0 -40px !important; } .MEIQIA-ICON-CHAT4 { background-position: 0 -60px !important; } .MEIQIA-ICON-CHAT5 { background-position: 0 -80px !important; } .MEIQIA-ICON-CHAT6 { background-position: 0 -100px !important; } .MEIQIA-ICON-CHAT7 { background-position: 0 -120px !important; } .MEIQIA-ICON-CHAT8 { background-position: 0 -140px !important; } .MEIQIA-ICON-CHAT9 { background-position: 0 -160px !important; } .MEIQIA-ICON-CHAT10 { background-position: 0 -180px !important; } .MEIQIA-ICON-CHAT11 { background-position: 0 -200px !important; } .MEIQIA-ICON-CHAT12 { background-position: 0 -220px !important; } .MEIQIA-ICON-TICKET1 { background-position: -20px 0 !important; } .MEIQIA-ICON-TICKET2 { background-position: -20px -20px !important; } .MEIQIA-ICON-TICKET3 { background-position: -20px -40px !important; } .MEIQIA-ICON-TICKET4 { background-position: -20px -60px !important; } .MEIQIA-ICON-TICKET5 { background-position: -20px -80px !important; } .MEIQIA-ICON-TICKET6 { background-position: -20px -100px !important; } .MEIQIA-ICON-TICKET7 { background-position: -20px -120px !important; } .MEIQIA-ICON-TICKET8 { background-position: -20px -140px !important; } .MEIQIA-ICON-TICKET9 { background-position: -20px -160px !important; } .MEIQIA-ICON-TICKET10 { background-position: -20px -180px !important; } .MEIQIA-ICON-TICKET11 { background-position: -20px -200px !important; } .MEIQIA-ICON-TICKET12 { background-position: -20px -220px !important; } </style><style type="text/css" id="MEIQIA-PANEL-STYLE">#MEIQIA-PANEL-HOLDER { position: fixed; bottom: 0;  right: 60px;  z-index: -1; width: 320px; height: 480px; padding: 0; margin: 0; overflow: hidden; visibility: hidden; background-color: transparent; box-shadow: 0 0 20px 0 rgba(0, 0, 0, .15); border: 1px solid #eee\0; *border: 1px solid #eee; } #MEIQIA-IFRAME { position: absolute; top: 0; right: 0; bottom: 0; left: 0; display: none; width: 100% !important; height: 100% !important; border: 0; padding: 0; margin: 0; float: none; background: none; } </style><style type="text/css" id="MEIQIA-BTN-STYLE">#MEIQIA-BTN-HOLDER { display: none; position: fixed; bottom: 0;  right: 60px;  z-index: 2147483647; width: auto; height: auto; padding: 0; margin: 0; border: 0; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif; background-color: transparent; } #MEIQIA-BTN, #MEIQIA-BTN span, #MEIQIA-BTN div, #MEIQIA-BTN img { float: none; width: auto; height: auto; padding: 0; margin: 0; border: 0; background: none; } #MEIQIA-BTN { display: block; height: 40px; font-size: 16px; color: #fff; text-align: center; border-left: 1px solid rgba(0, 0, 0, .1); border-top: 1px solid rgba(0, 0, 0, .1); border-right: 1px solid rgba(0, 0, 0, .1); box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); cursor: pointer; text-decoration: none; background-color: #1abc9c; } #MEIQIA-BTN #MEIQIA-BTN-ICON { display: block; float: left; width: 20px; height: 20px; margin: 10px 10px 0; } #MEIQIA-BTN #MEIQIA-BTN-LINE { display: block; float: left; width: 1px; height: 100%; background-color: rgba(0, 0, 0, .08); background-color: #000\9; opacity: .1\9; filter: alpha(opacity=10)\9; vertical-align: middle; } #MEIQIA-BTN #MEIQIA-BTN-TEXT { display: block; float: left; height: 40px; margin: 0 10px; line-height: 40px; overflow-y: hidden; font-size: 16px; color: #fff; } #MEIQIA-BTN #MEIQIA-CIRCLE { position: absolute; top: -13px; left: -13px; display: none; width: 26px; height: 26px; text-align: center; line-height: 26px; font-size: 14px; color: #fff; border-radius: 15px; background-color: #ff3b30; } #MEIQIA-BTN #MEIQIA-BUBBLE { position: absolute; bottom: 64px; display: none; width: 260px; border: 1px solid #f7f7f7; border-radius: 4px; color: #000; text-align: left; box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); line-height: 1.428571429; background-color: #fff; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW1 { position: absolute; z-index: 2; font-size: 0; line-height: 0; border-width: 8px 7px 0px; border-color: #fff transparent; border-style: solid dashed dashed; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW2 { position: absolute; z-index: 1; font-size: 0; line-height: 0; border-width: 10px 8px 0px; border-color: #f7f7f7 transparent; border-style: solid dashed dashed; }  #MEIQIA-BTN #MEIQIA-BUBBLE { right: 0; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW1 { right: 12px; bottom: -8px; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW2 { right: 11px; bottom: -10px; }  #MEIQIA-BTN #MEIQIA-BUBBLE-CLOSE { position: absolute; display: none; top: 12px; right: 12px; width: 10px; height: 10px; background-position: -5px -245px; cursor: pointer; } #MEIQIA-BTN #MEIQIA-BUBBLE:hover #MEIQIA-BUBBLE-CLOSE { display: block; } #MEIQIA-BTN #MEIQIA-BUBBLE-INSIDE { margin: 12px 18px; } #MEIQIA-BTN #MEIQIA-BUBBLE-AVATAR { width: 26px; height: 26px; border-radius: 13px; margin-right: 6px; vertical-align: top; box-shadow: 0 0 8px 0 rgba(0, 0, 0, .15); } #MEIQIA-BTN #MEIQIA-BUBBLE-NAME { display: inline-block; margin-top: 3px; font-size: 16px; color: #000; } #MEIQIA-BTN #MEIQIA-BUBBLE-MSG { *height: 40px; max-height: 40px; margin-top: 5px; font-size: 14px; overflow: hidden; color: #000; } #MEIQIA-BTN #MEIQIA-BUBBLE-MSG img { width: 16px; height: 16px; } </style><style type="text/css" id="MEIQIA-INVITE-STYLE">#MEIQIA-INVITE, #MEIQIA-INVITE div, #MEIQIA-INVITE span { float: none; width: auto; height: auto; padding: 0; margin: 0; border: 0; background: none; } #MEIQIA-INVITE { position: fixed; z-index: 2147483647; display: none; width: 340px; height: 130px; margin-bottom: 64px; border: 1px solid #f7f7f7; border-radius: 4px; box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); text-align: left; cursor: pointer; color: #000; line-height: 1.428571429; background-color: #fff; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1, #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { position: absolute; font-size: 0; line-height: 0; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1 { z-index: 2; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { z-index: 1; }   #MEIQIA-INVITE { right: 60px; bottom: 0; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1 { right: 12px; bottom: -8px; border-top: 8px solid #fff; border-right: 7px solid transparent; border-left: 7px solid transparent; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { right: 11px; bottom: -10px; border-top: 9px solid #f7f7f7; border-right: 8px solid transparent; border-left: 8px solid transparent; }     #MEIQIA-INVITE #MEIQIA-INVITE-CLOSE { position: absolute; right: -20px; top: -20px; width: 40px; height: 40px; cursor: pointer;  background-position: 0 -260px;  } #MEIQIA-INVITE #MEIQIA-INVITE-CLOSE:hover {  background-position: 0 -300px;  } #MEIQIA-INVITE #MEIQIA-INVITE-INSIDE { width: 300px; height: 44px; margin: 46px 20px 0; text-align: left; font-size: 14px; line-height: 22px; overflow: hidden; color: #000; /*word-break: break-all;*/ } </style> 

  
</head>
<body class="landing-page hide-sidebar" data-gr-c-s-loaded="true" ryt12216="1">




<link rel="stylesheet" href="static/css/header_include_fashion.min.css">
<link rel="stylesheet" href="static/css/index-ad-places.css">
<link rel="stylesheet" href="static/css/index.css">
<link rel="stylesheet" href="static/css/idangerous.swiper2.7.6.css">
<link rel="stylesheet" href="static/css/animate.min.css">
<link rel="stylesheet" href="static/css/style_1.css">

<style>
#meiqia {
    -moz-box-shadow: 3px 3px 9px #c1c1c1;
    -webkit-box-shadow: 3px 3px 9px #c1c1c1;
    box-shadow: 3px 3px 9px #c1c1c1;
}

.img-shrink {
    max-width:120px;
}

.btn-detail-index-top {
    padding: 12px 50px;
    background-color: #29bb9c;
    border-color: #29bb9c;
    color: #fff;
}
.btn-detail-index-top:hover {
    background-color:#27c7a5;
    border-color: #27c7a5;
    color:#fff;
}
.btn-detail-index-top:active {
    background-color:#27c7a5;
    border-color: #27c7a5;
    color:#fff;
}
a.btn-detail-index-top:hover, a.btn-detail-index-top:active {
    color: #fff;
}
.font-18 {
    font-size: 18px !important;
}
.about-p1 {
    font-size:14px;
}
.membership {
    color:#29bb9c;
}
.faq-content {
    padding-bottom:30px;
}
.faq-section {
    background:#f6f6f6;
    padding-top:100px;
    padding-bottom:100px;
}
.faq-section .question {
    font-size:20px;
    color:#252525;
    margin-bottom:20px;
}
.faq-section .answer {
    font-size:14px;
    color:#8d9396;
}
.faq-item {
    padding:20px 50px;
}
.price-content-title {
    font-size: 26px;
    color: #000;
}
  .footery {
	margin-top:50px;
	text-align:center;
	border-top:1px solid #979797;
	padding-top:30px;
	padding-bottom:40px
}
.footery .footer-content {
	font-size:14px !important;
	max-width:980px;
	width:95%;
	display:inline-block;
	margin:0 auto
}
.footery .footer-content .list-inline {
	text-align:left;
	padding:0;
	margin:0;
	line-height:30px
}
.footery .footer-content .list-inline a {
	color:#505556;
	white-space:nowrap
}
.footery .footer-content table {
	width:100%
}
.footery .footer-content .locale {
	width:90px;
	vertical-align:top
}
.footery .footer-content .locale a {
	text-decoration:none;
	color:#505556
}
</style>

<div class="container">
    <div class="row mheader hide">
        <div class="col-md-6"></div>
        <div class="col-md-6 text-right mt-5 mb-10">
                    </div>
    </div>
</div>

<nav class="navbar navbar-default">
    <div class="container head-container">
        <div class="navbar-header">
            <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle navbar-toggle1 collapsed btn-mobile-more" type="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="/"><img src="/static/picture/logo.png" class="mt-10" style="width:212px;"></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          
             <ul class="nav navbar-nav navbar-nav1 navbar-right">

				<li><a href="/">首页</a></li>
               	<li><a href="/index.php/home">上传分发</a></li>
				<li><a href="/index.php/cishu">分发价格</a></li>
				<li><a href="/index.php/qianming">签名价格</a></li>
				<li><a href="/index.php/webview">封装价格</a></li>
	<?php if($GLOBALS['userlogined']){ ?>
	<li><a href="<?php echo IN_PATH.'index.php/home'; ?>">应用管理</a></li>
	<li><a href="<?php echo IN_PATH.'index.php/logout'; ?>">退�?/a></li>
	<?php }else{ ?>
	<li><a href="<?php echo IN_PATH.'index.php/reg'; ?>">免费注册</a></li>
	<li><a href="<?php echo IN_PATH.'index.php/login'; ?>">立即登录</a></li>
	<?php } ?>
		</div>
	</div>
</div>
</nav>

<!--<header class="pt100 pb100 bg-store-light signature-header mb-0">
<div class="container">
         <div class="col-lg-6 col-md-6 col-xs-12 col-sm-8">
            <h1 class="mb-10 font-36 color-333">分发</h1>
           

    <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;">3分钟自助签名�?/h3>
    <h3 class="mb-10 font-20 color-333"  style="color: #29bb9c!important; margin-left: 5px;">12个月不掉签名�?/h3>
    <h3 class="mb-10 font-20 color-333"  style="color: #29bb9c!important; margin-left: 5px;">24小时贴心为您</h3>

     <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;"> &nbsp;</h3>
            <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;"> &nbsp;</h3>

            <h3 class="mb-10 font-20 color-333" style="color: #29bb9c!important;    margin-left: 5px;"> &nbsp;</h3>
           

            <p class="font-16 color-333 line-28 mt-40 mb-60">我们为您提供长期、稳定、有效的 iOS 企业证书签名服务，免提交 APP Store 审核，无需越狱即可在手机、平板上下载安装。适用于所有内测的 iOS 应用，以最优的签名服务为您排除最难以解决的上线障碍�?/p>
            <div class="col-md-12 mt-10" style="padding-left:0px">
                                    <a href="/index.php/home" class="btn btn-detail-index-top font-18 border-radius-5">立即签名</a>
                                    <a href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes" class="btn btn-detail-aso-top font-18 border-radius-5" target="_blank" style="padding: 12px 31px;    border: 1px solid #29bb9c;">联系售前咨询</a>
            </div>
       </div>
    </div>
</header>-->
<body>
			</div>
		</div>    
	</div>
		</a>
	</div>
  
</div>
<div class="pagination"></div>
</div>

</body>



<div class="container-fluid faq-section">
    <div class="container">
        <div class="col-md-12 text-center faq-content">
            <span class="price-content-title">极速分发服务协�?/span>
        </div>
  </script>
<a name="01"></a>
<p>
<p>极速分发（除非特别说明，本服务协议所提及的极速分发、域名下的所有内容。使用极速分�? 也就意味着您同意本服务协议及极速分发对其不时所做的修订�?/p>
<h3>第一条：使用之前�?/h3>
<p>1. 通过使用极速分发所提供的信息，工具以及其他功能，借助任何极速分发的 API，或者经由极速分发接口的任何软件、其它网站，或者它�?API（以上统称“服务”），都表示您同意遵守本服务协议，无论您是一个非注册用户还是一个注册用户�?/p>
<p>2. 如果您想成为注册用户并使用极速分发提供的服务，您必须阅读并接受本服务协议。只要您注册成为极速分发的用户（无论是通过极速分发还是通过其他第三方媒介，下同）就视为您接受了本服务协议。如果您接受本服务协议，则表示您有能力受其约束，或者，如果您代表了一个公司或实体，您有权使该实体受其约束�?/p>
<h3>第二条：行为准则</h3>
<p>1. 一旦您接收了本服务协议项下的条款和条件，即表示您同意在使用服务时遵守以下规则。您理解并同意，如果您违反了以上规则，所出现的任何后果由您自行承担，极速分发对此不负有任何责任�?/p>
<ul>
<li> 1.1 不得利用极速分发提供的服务从事任何非法活动，不发布违反国家相关法律法规及政策规定的内容�?/li>
<li> 1.2 不得利用极速分发危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一�?/li>
<li> 1.3 不得利用极速分发损害国家荣誉和利益�?/li>
<li> 1.4 不得利用极速分发煽动民族仇恨、民族歧视，破坏民族团结�?/li>
<li> 1.5 不得利用极速分发破坏国家宗教政策，宣扬邪教和封建迷信；</li>
<li> 1.6 不得利用极速分发散布谣言，扰乱社会秩序，破坏社会稳定�?/li>
<li> 1.7 不得利用极速分发散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪；</li>
<li> 1.8 不得利用极速分发侮辱或者诽谤他人，侵害他人合法权益�?/li>
<li> 1.9 不得利用极速分发侵害他人知识产权、商业秘密等合法权益�?/li>
<li> 1.10 不得利用极速分发恶意虚构事实、隐瞒真相以误导、欺骗他人；</li>
<li> 1.11 不得利用极速分发发布、传送、传播垃圾信息；</li>
<li> 1.12 不得向极速分发上传任何恶意代码、含有恶意行为的软件�?/li>
<li> 1.13 不得滥用极速分发所提供的资源或者服务，该等滥用包括但不限于重复应用、谋取不当利益等行为�?/li>
<li> 1.14 不得转让或继受、售卖极速分发的账号和密码，以谋取不当利益；</li>
<li> 1.16 不得传播任何形式的游戏软件作品；</li>
<li> 1.18 不得规避服务的任何访问或可用性限制；</li>
<li> 1.19 不得从事对服务或他人有害的活动（例如，传播病毒、跟踪、发布仇恨言论或宣扬针对他人的暴力行为）�?/li>
<li> 1.20 不得利用极速分发或其服务侵犯他人的合法权利�?/li>
<li> 1.21 不得利用极速分发从事侵犯他人隐私或数据保护权利的活动；</li>
<li> 1.22 不得利用极速分发传播含有违反国家法律的金融、股票、理财、贷款、赌博等软件或App�?/li>
<li> 1.22 其他法律法规禁止的行为；</li>
<li> 1.23 不得帮助他人违反上述规则�?/li>
<h3>第三条：使用准则</h3>
<li> 1.本平台内测分发托管服务为第三方应用提供应用托管、反馈收集等服务。应用内容均来源于第三方产品，仅为用户提供下载支持，不涉及任何人工编辑和整理�?/li>
<li> 1.本平台不对任何来源于第三方的内容（包括但不限于安装包安全、信息描述、应用截图）承担责任，用户可根据描述场景谨慎选择下载试用�?/li>
<li> 1.任何公司、产品或者个人认为极速分发分发涉嫌侵犯您的版权或应用权，您应该及时向我们提供举报声明、书面权利通知，并提供身份证明、权属证明及侵权情况等投诉材料。我们将依法进行处理�?/li>
<li> 1.应用下载者与应用上传者如发生纠纷，请自行与上传者协商处理，协商无果请到相关部门进行投诉，或者拨�?10警方介入，本平台不承担责任；</li

      </div>
    </div>
  </ul>    
</div>
</div>
</div>
<div class="col-lg-1"></div>
</div>
</div>
  
  <div class="footery">
	<div class="footer-content">
		<ul class="list-inline list-unstyled navbar-footer">
			<li>Copyright &copy; 2018 分发 .All Rights Reserved.</li>
			<li><a href="/index.php/a"  target="_blank">应用规范</a></li>
			<li><a href="/index.php/a"  target="_blank">服务协议</a></li>
            <li><a href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes"  target="_blank">联系客服</a></li>
          	<li>声明：本平台仅供应用内测使用，请勿上传非法应用。如违规违法上传应用一切后果有上传者承担�?/li>
			<li></li>
		</ul>
	</div>
</div></div>


<!-- Vendor scripts 

<script async="" src="static/js/meiqia.js"></script>
<script async="" src="static/js/analytics.js"></script>
-->


<script src="static/js/jquery.min.js"></script>
<script src="static/js/jquery-ui.min.js"></script>
<script src="static/js/jquery.slimscroll.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/metismenu.min.js"></script>
<script src="static/js/icheck.min.js"></script>
<script src="static/js/index.js"></script> 
<script src="static/js/jquery-1.10.1.min.js"></script>
<script src="static/js/idangerous.swiper2.7.6.min.js"></script>
<script src="static/js/swiper.animate1.0.2.min.js"></script>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-74260511-1', 'auto');
    ga('send', 'pageview');

    $(document).ready(function () {
    $('.navbar ul.nav li.father ').hover(function() {
        $(this).find('i.fa-angle-down').removeClass('fa-angle-down').addClass('fa-angle-up');
        $(this).find('.son').stop(true, true).fadeIn();
    }, function() {
        $(this).find('i.fa-angle-up').removeClass('fa-angle-up').addClass('fa-angle-down');
        $(this).find('.son').stop(true, true).fadeOut();
    });
 });
 
 var mySwiper = new Swiper ('.swiper-container', {
	pagination: '.pagination',
	paginationClickable :true,
	autoplay : 10000,
	speed:1,

	//autoplayDisableOnInteraction : false,
	
	onInit: function(swiper){ //Swiper2.x的初始化是onFirstInit
		swiperAnimateCache(swiper); //隐藏动画元素 
		swiperAnimate(swiper); //初始化完成开始动�?	}, 
	onSlideChangeEnd: function(swiper){ 
	swiperAnimate(swiper); //每个slide切换结束时也运行当前slide动画
	} 
})
  
$('.arrow-left').on('click', function(e){
	e.preventDefault()
	mySwiper.swipePrev()
})
$('.arrow-right').on('click', function(e){
	e.preventDefault()
	mySwiper.swipeNext()
})    

</script>
 
<div class="bar hidden-xs" style="z-index:9999;">
    <a class="bar3" href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes">
         <span class="tel"></span>
    </a>
</div>

<script src="static/js/homer.js"></script>

<!-- Local script for menu handle -->
<!-- It can be also directive -->
<script>
    $(document).ready(function () {

    });
</script>
 
</body>  
  </html>
 </body>
</html></body>
</html>