
<!doctype html>
<html lang="zh">
<head>
<title>极致分发 - 领先的内测应用发布、管理平台,为开发者提供iOS/Android应用开发、封装打包APP、内测发布等一系列效率工具服务</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="renderer" content="webkit">
<meta name="keywords" content="极致分发,bichuse.com,app极致分发,免费托管,内测发布平台,iOS企业签名,苹果签名,安卓苹果应用开发,免费上传内测极致分发安装,CDN加速,iOS,Android,iPad,iPhone,App下载,免费安装,adhoc,InHouse,beta测试,ipa,apk,安卓,苹果应用,二维码下载,UDID,iOS内测,Android内测,beta test,app store,testflight">
<meta property="og:url" content="https://www.bichuse.com">
<meta property="og:title" content="极致">
<meta name="description" content="极致极致分发 - 免费为您提供APP应用内测、应用托管、内测极致分发、兼容测试等服务,为客户提供APP内测托管平台和免费的应用下载极致分发渠道!">
<link rel="stylesheet" href="/index/css/bootstrap.min.css" />
<link rel="stylesheet" href="/index/css/swiper.min.css" />
<link rel="stylesheet" href="/index/css/font_780494_5w8tahtga5x.css" />
<link rel="stylesheet" href="/index/css/base.css" />
<link rel="stylesheet" href="/index/css/main.css" />
<link rel="stylesheet" href="/index/css/h5.css" />
<link rel="shortcut icon" href="/index/img/favicon.ico" type="image/x-icon" />
<script src="/index/js/jquery.min.js"></script>
<script src="/index/js/bootstrap.min.js"></script>
<script src="/index/js/swiper.min.js"></script>
<script src="/index/js/jquery.dotdotdot.js"></script>
<script src="/index/js/js.js"></script>
<script>
        isHideFooter = false;
    </script>
<body>
<header>
<div class="container">
<div class="header clearfix">
<a class="header-left block fl" href="/">
<img src="/index/img/logo-top.png" class="img-responsive hidden-xs">
<img src="/index/img/phone-logo.png" class="img-responsive visible-xs">
</a>
<ul class="ms-nav fl clearfix">
<li class=" active">
<a href="/">首页</a>
</li>
<li class="">
<?php if(IN_SIGN){ ?><a href="<?php echo IN_PATH.'index.php/home'; ?>">上传</a><?php } ?>
</li>
<li class="">
<a href="<?php echo IN_PATH.'index.php/cishu'; ?>">价格套餐</a>
</li>
<li class="">
<a href="<?php echo IN_PATH.'index.php/price'; ?>">签名套餐</a>
</li>
<li class="">
<a href="<?php echo IN_PATH.'chushou'; ?>">购买源码</a>
</li>
</ul>
<ul class="login clearfix fr">
    <div class="member">
    <?php if($GLOBALS['userlogined']){ ?>
	<a href="<?php echo IN_PATH.'index.php/home'; ?>" style="margin-right:20px">应用管理</a>
	<a href="<?php echo IN_PATH.'index.php/logout'; ?>">退出</a>
	<?php }else{ ?>
	<a href="<?php echo IN_PATH.'index.php/login'; ?>" class="bor1 i-login" style="margin-right:20px">立即登录</a>&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="<?php echo IN_PATH.'index.php/reg'; ?>"  class="register-btn">免费注册</a>
				<?php } ?>
        </div>
</ul>
</div>
</div>
</header>
<script>
    isHideFooter = true;
</script><script>isHideFooter = false;</script>

<div class="price-banner"></div>


<div class="container">
<div class="price-tab">
<ul class="clearfix">
<li>极致分发包月套餐</li>
</ul>
</div>
<div class="price-con">
<div class="tab-2" style="display: block;">
<div class="buy-number">
<div class="price-common">
<h1>包月无限下载<span>（未到账联系客服）</span></h1>
<p class="p1">根据自身需求，选择相应套餐，采用oss极致下载，灵活实惠</p>
<div class="row clearfix">
<div class="col-sm-4">
<div class="c-top">

</div>
</div>
</div>
<div class="table-responsive">
<table class="table table-bordered">
<tr>
<tr>

<td><span class="free"><h1><span>（以下是包月套餐）</span></h1></span></td>


<tr>
<th><span class="badge-basis">包月套餐<span class="badge">推荐</span></span></th>
<th>价格（下载次数不限）</th>
<th>DNS加速</th>
<th>点击购买</th>
</tr>
</tr>
<tr>
<td>包月<span class="badge-basis"><span class="badge">活动价</span></span></td>
<td><span class="free">150</span></td>
<td><span class="iconfont icon-duihao"></td>
<td><span class="font20"><a href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=150" class="btn-buy ms-btn-primary ms-btn">购买</a></td>
<tr>
<td><span class="free">包季</span></td>
<td><span class="free">380</span></td>
<td><span class="iconfont icon-duihao"></td>
<td><span class="font20"><a href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=380" class="btn-buy ms-btn-primary ms-btn">购买</a></td>
 <tr>
<td><span class="free">包年</span></td>
<td><span class="free">1000</span></td>
<td><span class="iconfont icon-duihao"></td>
<td><span class="font20"><a href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=1000" class="btn-buy ms-btn-primary ms-btn">购买</a></td>
</tr>
</table>
</div>
</div>

<div class="price-common">
</tr>
</table>
</div>
</div>
</div>
</div>
</div>
</div>


<footer>
<div class="container">
<div class="footer">
<div class="clearfix">
<div class="fl left clearfix">
<dl class="fl">
<dt>产品服务</dt>
<dd class="line"></dd>
<dd><a href="/index.php/price" target="_blank">签名套餐</a></dd>
<dd><a href="/index.php/webview" target="_blank">封装APP</a></dd>
<dd><a href="/extract" target="_blank">提取IPA</a></dd>
<dd><a href="/index.php/cishu" target="_blank">分发套餐</a></dd>
</dl>
<dl class="fl">
<dt>关于我们</dt>
<dd class="line"></dd>
<dd><a href="/about" target="_blank">公司简介</a></dd>
<dd><a href="/about/agreement" target="_blank">服务协议</a></dd>
<dd><a href="/about/review-rules" target="_blank">应用审核规范</a></dd>
<dd><a href="/about/privacy" target="_blank">隐私政策</a></dd>
</dl>
<dl class="fl">
<dt>联系我们</dt>
<dd class="line"></dd>
<dd>
<a href="javascript:;" target="_blank" class="chatQQ">QQ：1787601777</a>
</dd>

<dd><a href="mailto:1787601777@qq.com">邮箱：1787601777@qq.com</a></dd>


<dd>地址：安徽省合肥市庐江区动漫产业园<br><span class="ml35">9幢9楼</span></dd>
</dl>
</div>
<a class="fl" href="https://v.yunaq.com/"><img src="/static/img/label_lg_90030.png?201812040001" style="width: 100px; margin-top: 111px;"></a>
<a class="fl" id="_pingansec_bottomimagelarge_shiming" href="http://si.trustutn.org"><img src="/static/img/bottom_large_img.png?201812040001" style="width: 100px; margin-top: 111px; margin-left: 40px;" /></a>
<div class="right fr clearfix">
<a href="/">
<img src="/index/img/logo-top.png" class="img-responsive hidden-xs">
<img src="/index/img/logo-top.png" class="img-responsive visible-xs">
</a>
<div class="clearfix"></div>
<div class="wechat clearfix fr hidden-xs">
<img src="/static/weixin.png" alt="" class="fr">
</div>
<div class="clearfix"></div>
<p class="hidden-xs">微信扫描二维码</p>
<div style="text-align: left; color: #fff; line-height: 28px;" class="visible-xs">
<a href="/about" target="_blank" class="color-white">公司简介</a>

<div>地址：福州市鼓楼区碧玉花园连接体4-5座连接体206-1室</span></div>
</div>
</div>
</div>
<div class="record">
<div class="inline-block">
<span class="fl">极致网络科技有限公司 ICP备   -2</span>
<a target="_blank" href="mailto:1787601777@qq.com" style="text-decoration:none; height:20px; line-height:20px; float: left; margin-left: 10px;">
<img src="/static/jh.png" style="float:left;" />
<p style="float:left; height:20px; line-height:20px; margin: 0px 0px 0px 5px; color:#fff;">联系我们</p>
</a>
</div>
</p>
</div>
</div>
</div>
</footer>


<ul class="fixed-right right-float-window">
<li>
<a href="javascript:;" target="_blank">
<span class="iconfont icon-qq chatQQ"></span>
</a>
</li>
<li>
<a href="javascript:;">
<span class="iconfont icon-weixin1"></span>
<div class="wechat">
<img src="///static/img/weixin.png?201812040001" alt="">
</div>
</a>
</li>
<li class="go-top">
<a href="javascript:;"><span class="iconfont icon-go-top"></span></a>
</li>
</ul>


<div class="modal fade ms-modal" id="myModalPay" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">购买</h4>
</div>
<div class="modal-body">
<div class="font18 color-333">是否完成了购买？</div>
<p class="mt15">请在新打开的页面中完成购买，购买完成后，请根据购买结果点击下面的按钮 </p>
</div>
<div class="modal-footer">
<input type="hidden" name="order_sn" value="">
<button type="button" class="ms-btn ms-btn-primary complete-pay">支付成功</button>
<button type="button" class="ms-btn ms-btn-default fail-pay" data-dismiss="modal">支付遇到问题</button>
</div>
</div>
</div>
</div>
<div class="modal fade ms-modal" id="paySuccessModal" tabindex="-1" role="dialog">
<div class="modal-dialog modal-sm" role="document">
<div class="modal-content">
<div class="modal-body">
<div class="text-center">
<div><span class="icon icon-modal-success1"></span></div>
<p class="color-333 bold font16 mt5">购买成功</p>
<p class="color-333 mt5"></p>
<div class="mt15">
<a type="button" class="ms-btn ms-btn-default w90" href="#">确定（3）</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="modal fade ms-modal auto-hide-modal" id="submitLoading" tabindex="-1" role="dialog">
<div class="modal-dialog modal-sm" role="document">
<div class="modal-content">
<div class="modal-body">
<div class="text-center">
<div class="auto-hide">
<span class="icon icon-modal-success3"></span>
<div class="mt5">已提交，请稍后...</div>
</p>
</div>
</div>
</footer>


<ul class="fixed-right right-float-window">
<li>
<a href="javascript:;" target="_blank">
<span class="iconfont icon-qq chatQQ"></span>
</a>
</li>
<li>
<a href="javascript:;">
<span class="iconfont icon-weixin1"></span>
<div class="wechat">
<img src="/index/img/weixin.png" alt="">
</div>
</a>
</li>
<li class="go-top">
<a href="javascript:;"><span class="iconfont icon-go-top"></span></a>
</li>
</ul>

<script data-cfasync="false" src="/index/js/email-decode.min.js"></script><script src="/index/js/clipboard.js"></script>
<script>
    if (isHideFooter) {
        $('.right-float-window').hide();
    }
    var windowWidth = $(window).width();
    if (isHideFooter && windowWidth <= 750) {
        $('header,.toolkit-common-wrap,footer,.right-float-window').hide();
    }
    $(function () {
        $("body").on('click','.fail-pay',function () {
            $(".toPay").removeClass('disabled');
        });
        $("body").on('click', '.complete-pay', function () {
            $(".toPay").removeClass('disabled');
            order_sn = $('#myModalPay').find('input[name="order_sn"]').val();
            if (!order_sn) {
                $('#myModalPay').modal('hide');
                return;
            }

            $.post('/order/check-pay', {order_sn: order_sn}, function (result) {
                if (result.code != 200) {
                    $('#myModalPay').modal('hide');
                } else {
                    if (result.data.service_type == 3) {
                        window.location.href = '/user/services';
                    } else if (result.data.service_type == 2) {
                        window.location.href = '/sign/upload?step=4&sign_id=' + result.data.goods_id;
                    } else if (result.data.service_type == 1) {
                        window.location.href = '/pack?step=5&id=' + result.data.goods_id;
                    }

                }
            })

        });

        $("body").on('click', '.chatQQ', function () {
            console.info(windowWidth);
            if (windowWidth <= 750) {
                /*1234567对应的就是需要聊天的客服*/
                window.location.href = "mqqwpa://im/chat?chat_type=wpa&uin=1787601777&version=1&src_type=web&web_src=oicqzone.com";
            } else {
                window.location.href = "http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes";

            }
        });

        var num = 3;
        var linkTime = null;
        clearInterval(linkTime);
        function linkfun() {
            if ($("#paySuccessModal").is(":visible")) {
                $("#paySuccessModal a").text('确定（' + num + ')');
                num--;
                if (num <= 0) {
                    var href = $("#paySuccessModal a").attr('href');
                    window.location.href = href;
                }
            }
        }

        linkTime = setInterval(linkfun, 1000);
    });


    var _hmt = _hmt || [];
    (function () {
        var hm = document.createElement("script");
        hm.src = "https://hm.baidu.com/hm.js?932e6e061f7d4ac477e82f20fd3778c6";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();
    var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");
    document.write(unescape("%3Cspan style='display:none' id='cnzz_stat_icon_1275094025'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s19.cnzz.com/z_stat.php%3Fid%3D1275094025' type='text/javascript'%3E%3C/script%3E"));
</script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-128185075-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-128185075-1');
</script>

<script>
    window.ga = window.ga || function () {
            (ga.q = ga.q || []).push(arguments)
        };
    ga.l = +new Date;
    ga('create', 'UA-128185075-1', 'auto');
    ga('send', 'pageview');
</script>
<script async src='https://www.google-analytics.com/analytics.js'></script>








</body>
</html>