<?php
echo '<div class="footer">
	<div class="footer-content">
		<ul class="list-inline list-unstyled navbar-footer">
    <p>
        <center><a href="/">极致网络分发</a><span> | </span><a href="/index.php/home">发布应用</a><span>|  </span><a href="https://bichuse.com/index.php/qianming" target="_blank">APP签名（独立）</a><span>|  </span><a href="https://bichuse.com/index.php/webview" target="_blank">苹果封装</a><span>
    </span></center></p>
    <p>
       <center>  声明：本平台仅供应用内测使用，请勿上传非法应用。如违规违法上传应用造成一切后果由上传者承担 
      <li>Copyright &copy; ';
echo date('Y');
;
echo ' ';
echo $_SERVER['HTTP_HOST'];
;
echo ' .All Rights Reserved.</li></li>
	
      <li><a href="mailto:1787601777@qq.com"><a href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=EarDev&menu=yes" target="_blank" class="lightlink2 smallfont">联系我们</a></a></li>
			<li><a href="http://www.miibeian.gov.cn/" target="_blank"></a></li></center>
    </p>
			</ul>
		</div>
	</div>
</div>';
?>