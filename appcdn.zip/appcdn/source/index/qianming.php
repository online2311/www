
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="gbk">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="分发平台,app应用分发,ios分发,安卓分发,二维码分发平台,app分发,网站封装app,应用分发平台">
<meta name="description" content="app分发平台提供APP分发、ios分发、安卓分发、应用托管、内测分发、兼容测试、UDID等服务,真正为开发者着想的APP分发托管平台。">
<title>极速分发平台-</title>
<link href="/static/index/icons.css" rel="stylesheet">
<link href="/static/index/bootstrap.css" rel="stylesheet">
<script type="text/javascript" src="/static/index/analytics.js"></script>

</head>
<body>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="gbk">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="分发平台,app应用分发,ios分发,安卓分发,二维码分发平台,app分发,网站封装app,应用分发平台">
<meta name="description" content="app分发平台提供APP分发、ios分发、安卓分发、应用托管、内测分发、兼容测试、UDID等服务,真正为开发者着想的APP分发托管平台。">
<title>极速分发平台-</title>
<link href="static/css/icons.css" rel="stylesheet">
<link href="static/css/bootstrap.css" rel="stylesheet">
<script type="text/javascript" src="static/js/analytics.js"></script>

</head>
<body>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="author" content="极速分发，极速app证书签名 ios棋牌游戏签名 ipa封装签名证书打包代ios签名">
<meta name="keywords" content="apk,android,ipa,ios,iphone,ipad,app分发,应用托管,企业签名">
<meta name="description" content="分发分发为各行业提供ios企业签名、app应用托管分发服务！">
<title>分发 - App托管服务分发平台|安卓应用托管|iOS分发|ipa企业签名</title>
<link href="static/css/icons_1.css" rel="stylesheet">
<link href="static/css/bootstrap_1.css" rel="stylesheet">

<script type="text/javascript">
var startTime = new Date();
var reg_link = '/index.php/reg';
var letter_doodle = ["B","e","t","a","A","p","p","H","o","s","t","<br>","{","<br>","     ","r","e","t","u","r","n"," ",'"',"9","1","d","s",".","v","i","p",'"',"<br>","}"];
var end_letter_doodle = '<i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">9</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">1</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">d</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">s</i><i class="icon-comma trans"></i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">v</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">i</i><i class="icon-" style="font-style:normal;font-size:100px;font-weight:bold">p</i>';
</script>
  
  <!-- Vendor styles -->
  <link rel="stylesheet" href="static/css/font-awesome.css">
  <link rel="stylesheet" href="static/css/metismenu.css">
  <link rel="stylesheet" href="static/css/animate.css">
  <link rel="stylesheet" href="static/css/bootstrap.min.css">

  <!-- App styles -->
  <link rel="stylesheet" href="static/css/pe-icon-7-stroke.css">
  <link rel="stylesheet" href="static/css/helper.css">
  <link rel="stylesheet" href="static/css/style.css">
  <link rel="stylesheet" href="static/css/custom.css">
  <link rel="stylesheet" href="static/css/sidebar.css">
  <link rel="stylesheet" href="static/css/menu.css">
<link rel="stylesheet" href="static/css/signature.css">
<style type="text/css">.jqstooltip { position: absolute;left: 0px;top: 0px;visibility: hidden;background: rgb(0, 0, 0) transparent;background-color: rgba(0,0,0,0.6);filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000);-ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#99000000, endColorstr=#99000000)";color: white;font: 10px arial, san serif;text-align: left;white-space: nowrap;padding: 5px;border: 1px solid white;z-index: 10000;}.jqsfield { color: white;font: 10px arial, san serif;text-align: left;}</style><style id="style-1-cropbar-clipper">/* Copyright 2014 Evernote Corporation. All rights reserved. */
.en-markup-crop-options {
    top: 18px !important;
    left: 50% !important;
    margin-left: -100px !important;
    width: 200px !important;
    border: 2px rgba(255,255,255,.38) solid !important;
    border-radius: 4px !important;
}

.en-markup-crop-options div div:first-of-type {
    margin-left: 0px !important;
}

</style>

<style type="text/css" id="MEIQIA-ICON-STYLE">.MEIQIA-ICON { background-size: 40px auto !important; background-repeat: no-repeat !important; background-image: url("static/images/icon-mq.png") !important; } @media only screen and (-webkit-min-device-pixel-ratio: 2), only screen and (min--moz-device-pixel-ratio: 2), only screen and (-o-min-device-pixel-ratio: 2/1), only screen and (min-device-pixel-ratio: 2) { .MEIQIA-ICON { background-image: url("static/images/icon-mq@2x.png") !important; } } .MEIQIA-ICON-CHAT1 { background-position: 0 0 !important; } .MEIQIA-ICON-CHAT2 { background-position: 0 -20px !important; } .MEIQIA-ICON-CHAT3 { background-position: 0 -40px !important; } .MEIQIA-ICON-CHAT4 { background-position: 0 -60px !important; } .MEIQIA-ICON-CHAT5 { background-position: 0 -80px !important; } .MEIQIA-ICON-CHAT6 { background-position: 0 -100px !important; } .MEIQIA-ICON-CHAT7 { background-position: 0 -120px !important; } .MEIQIA-ICON-CHAT8 { background-position: 0 -140px !important; } .MEIQIA-ICON-CHAT9 { background-position: 0 -160px !important; } .MEIQIA-ICON-CHAT10 { background-position: 0 -180px !important; } .MEIQIA-ICON-CHAT11 { background-position: 0 -200px !important; } .MEIQIA-ICON-CHAT12 { background-position: 0 -220px !important; } .MEIQIA-ICON-TICKET1 { background-position: -20px 0 !important; } .MEIQIA-ICON-TICKET2 { background-position: -20px -20px !important; } .MEIQIA-ICON-TICKET3 { background-position: -20px -40px !important; } .MEIQIA-ICON-TICKET4 { background-position: -20px -60px !important; } .MEIQIA-ICON-TICKET5 { background-position: -20px -80px !important; } .MEIQIA-ICON-TICKET6 { background-position: -20px -100px !important; } .MEIQIA-ICON-TICKET7 { background-position: -20px -120px !important; } .MEIQIA-ICON-TICKET8 { background-position: -20px -140px !important; } .MEIQIA-ICON-TICKET9 { background-position: -20px -160px !important; } .MEIQIA-ICON-TICKET10 { background-position: -20px -180px !important; } .MEIQIA-ICON-TICKET11 { background-position: -20px -200px !important; } .MEIQIA-ICON-TICKET12 { background-position: -20px -220px !important; } </style><style type="text/css" id="MEIQIA-PANEL-STYLE">#MEIQIA-PANEL-HOLDER { position: fixed; bottom: 0;  right: 60px;  z-index: -1; width: 320px; height: 480px; padding: 0; margin: 0; overflow: hidden; visibility: hidden; background-color: transparent; box-shadow: 0 0 20px 0 rgba(0, 0, 0, .15); border: 1px solid #eee\0; *border: 1px solid #eee; } #MEIQIA-IFRAME { position: absolute; top: 0; right: 0; bottom: 0; left: 0; display: none; width: 100% !important; height: 100% !important; border: 0; padding: 0; margin: 0; float: none; background: none; } </style><style type="text/css" id="MEIQIA-BTN-STYLE">#MEIQIA-BTN-HOLDER { display: none; position: fixed; bottom: 0;  right: 60px;  z-index: 2147483647; width: auto; height: auto; padding: 0; margin: 0; border: 0; font-family: 'Helvetica Neue', Helvetica, Arial, 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif; background-color: transparent; } #MEIQIA-BTN, #MEIQIA-BTN span, #MEIQIA-BTN div, #MEIQIA-BTN img { float: none; width: auto; height: auto; padding: 0; margin: 0; border: 0; background: none; } #MEIQIA-BTN { display: block; height: 40px; font-size: 16px; color: #fff; text-align: center; border-left: 1px solid rgba(0, 0, 0, .1); border-top: 1px solid rgba(0, 0, 0, .1); border-right: 1px solid rgba(0, 0, 0, .1); box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); cursor: pointer; text-decoration: none; background-color: #1abc9c; } #MEIQIA-BTN #MEIQIA-BTN-ICON { display: block; float: left; width: 20px; height: 20px; margin: 10px 10px 0; } #MEIQIA-BTN #MEIQIA-BTN-LINE { display: block; float: left; width: 1px; height: 100%; background-color: rgba(0, 0, 0, .08); background-color: #000\9; opacity: .1\9; filter: alpha(opacity=10)\9; vertical-align: middle; } #MEIQIA-BTN #MEIQIA-BTN-TEXT { display: block; float: left; height: 40px; margin: 0 10px; line-height: 40px; overflow-y: hidden; font-size: 16px; color: #fff; } #MEIQIA-BTN #MEIQIA-CIRCLE { position: absolute; top: -13px; left: -13px; display: none; width: 26px; height: 26px; text-align: center; line-height: 26px; font-size: 14px; color: #fff; border-radius: 15px; background-color: #ff3b30; } #MEIQIA-BTN #MEIQIA-BUBBLE { position: absolute; bottom: 64px; display: none; width: 260px; border: 1px solid #f7f7f7; border-radius: 4px; color: #000; text-align: left; box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); line-height: 1.428571429; background-color: #fff; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW1 { position: absolute; z-index: 2; font-size: 0; line-height: 0; border-width: 8px 7px 0px; border-color: #fff transparent; border-style: solid dashed dashed; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW2 { position: absolute; z-index: 1; font-size: 0; line-height: 0; border-width: 10px 8px 0px; border-color: #f7f7f7 transparent; border-style: solid dashed dashed; }  #MEIQIA-BTN #MEIQIA-BUBBLE { right: 0; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW1 { right: 12px; bottom: -8px; } #MEIQIA-BTN #MEIQIA-BUBBLE-ARROW2 { right: 11px; bottom: -10px; }  #MEIQIA-BTN #MEIQIA-BUBBLE-CLOSE { position: absolute; display: none; top: 12px; right: 12px; width: 10px; height: 10px; background-position: -5px -245px; cursor: pointer; } #MEIQIA-BTN #MEIQIA-BUBBLE:hover #MEIQIA-BUBBLE-CLOSE { display: block; } #MEIQIA-BTN #MEIQIA-BUBBLE-INSIDE { margin: 12px 18px; } #MEIQIA-BTN #MEIQIA-BUBBLE-AVATAR { width: 26px; height: 26px; border-radius: 13px; margin-right: 6px; vertical-align: top; box-shadow: 0 0 8px 0 rgba(0, 0, 0, .15); } #MEIQIA-BTN #MEIQIA-BUBBLE-NAME { display: inline-block; margin-top: 3px; font-size: 16px; color: #000; } #MEIQIA-BTN #MEIQIA-BUBBLE-MSG { *height: 40px; max-height: 40px; margin-top: 5px; font-size: 14px; overflow: hidden; color: #000; } #MEIQIA-BTN #MEIQIA-BUBBLE-MSG img { width: 16px; height: 16px; } </style><style type="text/css" id="MEIQIA-INVITE-STYLE">#MEIQIA-INVITE, #MEIQIA-INVITE div, #MEIQIA-INVITE span { float: none; width: auto; height: auto; padding: 0; margin: 0; border: 0; background: none; } #MEIQIA-INVITE { position: fixed; z-index: 2147483647; display: none; width: 340px; height: 130px; margin-bottom: 64px; border: 1px solid #f7f7f7; border-radius: 4px; box-shadow: 0 0 14px 0 rgba(0, 0, 0, .16); text-align: left; cursor: pointer; color: #000; line-height: 1.428571429; background-color: #fff; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1, #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { position: absolute; font-size: 0; line-height: 0; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1 { z-index: 2; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { z-index: 1; }   #MEIQIA-INVITE { right: 60px; bottom: 0; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW1 { right: 12px; bottom: -8px; border-top: 8px solid #fff; border-right: 7px solid transparent; border-left: 7px solid transparent; } #MEIQIA-INVITE #MEIQIA-INVITE-ARROW2 { right: 11px; bottom: -10px; border-top: 9px solid #f7f7f7; border-right: 8px solid transparent; border-left: 8px solid transparent; }     #MEIQIA-INVITE #MEIQIA-INVITE-CLOSE { position: absolute; right: -20px; top: -20px; width: 40px; height: 40px; cursor: pointer;  background-position: 0 -260px;  } #MEIQIA-INVITE #MEIQIA-INVITE-CLOSE:hover {  background-position: 0 -300px;  } #MEIQIA-INVITE #MEIQIA-INVITE-INSIDE { width: 300px; height: 44px; margin: 46px 20px 0; text-align: left; font-size: 14px; line-height: 22px; overflow: hidden; color: #000; /*word-break: break-all;*/ } </style> 

  
</head>
<body class="landing-page hide-sidebar" data-gr-c-s-loaded="true" ryt12216="1">




<link rel="stylesheet" href="static/css/header_include_fashion.min.css">
<link rel="stylesheet" href="static/css/index-ad-places.css">
<link rel="stylesheet" href="static/css/index.css">
<link rel="stylesheet" href="static/css/idangerous.swiper2.7.6.css">
<link rel="stylesheet" href="static/css/animate.min.css">
<link rel="stylesheet" href="static/css/style_1.css">

<style>
#meiqia {
    -moz-box-shadow: 3px 3px 9px #c1c1c1;
    -webkit-box-shadow: 3px 3px 9px #c1c1c1;
    box-shadow: 3px 3px 9px #c1c1c1;
}

.img-shrink {
    max-width:120px;
}

.btn-detail-index-top {
    padding: 12px 50px;
    background-color: #29bb9c;
    border-color: #29bb9c;
    color: #fff;
}
.btn-detail-index-top:hover {
    background-color:#27c7a5;
    border-color: #27c7a5;
    color:#fff;
}
.btn-detail-index-top:active {
    background-color:#27c7a5;
    border-color: #27c7a5;
    color:#fff;
}
a.btn-detail-index-top:hover, a.btn-detail-index-top:active {
    color: #fff;
}
.font-18 {
    font-size: 18px !important;
}
.about-p1 {
    font-size:14px;
}
.membership {
    color:#29bb9c;
}
.faq-content {
    padding-bottom:30px;
}
.faq-section {
    background:#f6f6f6;
    padding-top:100px;
    padding-bottom:100px;
}
.faq-section .question {
    font-size:20px;
    color:#252525;
    margin-bottom:20px;
}
.faq-section .answer {
    font-size:14px;
    color:#8d9396;
}
.faq-item {
    padding:20px 50px;
}
.price-content-title {
    font-size: 26px;
    color: #000;
}
  .footery {
	margin-top:50px;
	text-align:center;
	border-top:1px solid #979797;
	padding-top:30px;
	padding-bottom:40px
}
.footery .footer-content {
	font-size:14px !important;
	max-width:980px;
	width:95%;
	display:inline-block;
	margin:0 auto
}
.footery .footer-content .list-inline {
	text-align:left;
	padding:0;
	margin:0;
	line-height:30px
}
.footery .footer-content .list-inline a {
	color:#505556;
	white-space:nowrap
}
.footery .footer-content table {
	width:100%
}
.footery .footer-content .locale {
	width:90px;
	vertical-align:top
}
.footery .footer-content .locale a {
	text-decoration:none;
	color:#505556
}
</style>

<div class="container">
    <div class="row mheader hide">
        <div class="col-md-6"></div>
        <div class="col-md-6 text-right mt-5 mb-10">
                    </div>
    </div>
</div>

<nav class="navbar navbar-default">
    <div class="container head-container">
        <div class="navbar-header">
            <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle navbar-toggle1 collapsed btn-mobile-more" type="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="/"><img src="/static/picture/logo2.png" class="mt-10" style="width:212px;"></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          
             <ul class="nav navbar-nav navbar-nav1 navbar-right">

				<li><a href="/">首页</a></li>
               	<li><a href="/index.php/home">上传分发</a></li>
				<li><a href="/index.php/cishu">分发价格</a></li>
				<li><a href="/index.php/qianming">签名价格</a></li>
				<li><a href="/index.php/webview">封装价格</a></li>
	<?php if($GLOBALS['userlogined']){ ?>
	<li><a href="<?php echo IN_PATH.'index.php/home'; ?>">应用管理</a></li>
	<li><a href="<?php echo IN_PATH.'index.php/logout'; ?>">退出</a></li>
	<?php }else{ ?>
	<li><a href="<?php echo IN_PATH.'index.php/reg'; ?>">免费注册</a></li>
	<li><a href="<?php echo IN_PATH.'index.php/login'; ?>">立即登录</a></li>
	<?php } ?>
        </div>
    </div>
</nav>


<body>
			</div>
		</div>    
	</div>
		</a>
	</div>
  
</div>
<div class="pagination"></div>
</div>

</body>



<div class="container-fluid faq-section">
    <div class="container">
        <div class="col-md-12 text-center faq-content">
            <span class="price-content-title">极速签名套餐</span>
        </div>

	</div>
  	</div>
  <div style="width:58%;height:30px; margin:0 auto; border:1px dashed #D7DF01;" ><div style=" float:left;margin-top:4px;" ><img src="/static/picture/gonggao.png" width="22" height="22"></div>
    <div>
	<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=1787601777&amp;site=qq&amp;menu=yes">
  <marquee style="  color:#FE2E64; margin:0; width:92%;  padding:0;line-height:30px;" direction=center behavior=alternate loop=0 scrollamount=3 scrolldelay=10  hspace=10 vspace=0 onmouseover=this.stop() onmouseout=this.start()>独立证书，稳定签名，自助付款后极速5分钟签名！</marquee>
    </a>
	</div>
  </div>
  <div class="package-cards-wrap"style="padding-left:15%">
  	<table class="table table-bordered table-hover" style="width:80%; border:1px solid #0094ff;text-align:center;">
 
    <tr>
     <th>类型</th>
     <th>安装限制</th>
     <th>补签政策</th>
     <th>证书类型</th>
     <th>价格</th>
     <th>购买</th>
    </tr>
            <tr>
   
     <td>共享签名稳定（包月）</td>
     <td><font color="green">无限制安装次数</font></td>
     <td><font color="red">服务期内免费补签</font></td>
     <!-- <td ><button class="btn" onclick="location.href='codepay/index.php?username=">购买</button></td> -->
     <td>国内共享</td>
     <td>130元</td>
     <!--  <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=130  ">购买码支付</a></td>-->
     <td><a class="btn btn-success" href="http://app.zidongfaka.cn">购买</a></td>  
    </tr>
          <tr>
   

     <td>共享签名稳定（包季）</td>
     <td><font color="green">无限制安装次数</font></td>
     <td><font color="red">服务期内免费补签</font></td>
     <!-- <td ><button class="btn" onclick="location.href='codepay/index.php?username=">购买</button></td> -->
     <td>国内共享</td>
     <td>360元</td>
     <!--  <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=130  ">购买码支付</a></td>--> 
     <td><a class="btn btn-success" href="http://app.zidongfaka.cn">购买</a></td>                        
           
    </tr>
          <tr>
   

     <td>共享签名稳定（包年）</td>
     <td><font color="green">无限制安装次数</font></td>
     <td><font color="red">服务期内免费补签</font></td>
     <!-- <td ><button class="btn" onclick="location.href='codepay/index.php?username=">购买</button></td> -->
     <td>国内共享</td>
     <td>1050元</td>
     <!--  <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=130  ">购买码支付</a></td>-->
     <td><a class="btn btn-success" href="http://app.zidongfaka.cn">购买</a></td>
                             
           
    </tr>
          <tr>
   

     <td><font color="red">独立签名稳定（包月）</font></td>
     <td><font color="green">无限制安装次数</font></td>
     <td><font color="red">服务期内免费补签</font></td>
     <!-- <td ><button class="btn" onclick="location.href='codepay/index.php?username=">购买</button></td> -->
     <td>国外独立（超级稳定）</td>
     <td><font color="red">200元</font></td>
     <!--  <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=130  ">购买码支付</a></td>-->
     <td><a class="btn btn-success" href="http://app.zidongfaka.cn">购买</a></td>                     
           
    </tr>
          <tr>
   

     <td><font color="red">独立签名稳定（包季）</font></td>
     <td><font color="green">无限制安装次数</font></td>
     <td><font color="red">服务期内免费补签</font></td>
     <!-- <td ><button class="btn" onclick="location.href='codepay/index.php?username=">购买</button></td> -->
     <td>国外独立（超级稳定）</td>
      <td><font color="red">500元</font></td>
     <!--  <td><a class="btn btn-success" href="/codepay/?user=<?php echo $GLOBALS['erduo_in_username']; ?>&price=130  ">购买码支付</a></td>-->
     <td><a class="btn btn-success" href="http://app.zidongfaka.cn">购买</a></td>
    </tr>
      </table>
  </div>




<div class="container-fluid faq-section">
    <div class="container">
        <div class="col-md-12 text-center faq-content">
        </div>
  </script>
<a name="01"></a>
<p>
<h1>常见问题</h1>
<div class="help">
<dl>
<dt class="clearfix">
<span class="left">Q ：</span>
<span class="right">国内共享和国外独立有什么区别？</span>
</dt>
<dd class="clearfix">
<span class="left">A ：</span>
<span class="right">
国内证书很多人共享使用的证书，有掉证书的可能（可补签）国外独立证书相对稳定，只有个人使用，不掉签名。。
</span>
</dd>
</dl>
<dl>
<dt class="clearfix">
<span class="left">Q ：</span>
<span class="right">签名需要提供APP源码吗？</span>
</dt>
<dd class="clearfix">
<span class="left">A ：</span>
<span class="right">
不需要源码，只需要提供IPA安装包。
</span>
</dd>
</dl>
<dl>
<dt class="clearfix">
<span class="left">Q ：</span>
<span class="right"> 签名需要多长时间？</span>
</dt>
<dd class="clearfix">
<span class="left">A ：</span>
<span class="right">正常时间10分钟左右，如有特殊情况，客服将主动联系告知。</span>
</dd>
</dl>
<dl>
<dt class="clearfix">
<span class="left">Q ：</span>
<span class="right">企业签名的APP有下载数量限制吗？</span>
</dt>
<dd class="clearfix">
<span class="left">A ：</span>
<span class="right">无限制任意安装。可以使用极速分发免费测试，如果需要更多下载次数，请购买。</span>
</dd>
</dl>
<dl>
<dt class="clearfix">
<span class="left">Q ：</span>
<span class="right">会不会中途掉签？</span>
</dt>
<dd class="clearfix">
<span class="left">A ：</span>
<span class="right">可能存在，由于一张证书签名的APP过多、下载量过大或者一些不可控的原因，苹果公司将封掉该证书，导致该证书签名的APP全部闪退； 我们将通过给APP分类签名和独立证书签名等方式，尽量规避该风险。如果掉签，免费补签。</span>
</dd>
</dl>
<dl>
<dt class="clearfix">
<span class="left">Q ：</span>
<span class="right">签名后，可以在App Store中搜索到吗？</span>
</dt>
<dd class="clearfix">
<span class="left">A ：</span>
<span class="right">不能，企业签名是通过下载页去做下载和安装；而在App Store要能支持下载，必须使用99美金的个人账号或者公司账号，提交iOS APP包，通过App Store审核，才可以下载。</span>
</dd>
</dl>
<dl>
 <dt class="clearfix">
<span class="left">Q ：</span>
<span class="right">签好后，如何给自己的用户去安装APP？</span>
</dt>
<dd class="clearfix">
<span class="left">A ：</span>
<span class="right">签名好后，客服通过邮箱或QQ发送-或者客户指定接收方式。。</span>
</dd>
</dl>
</div>
</div>
</div>
<div class="price-common">
</tr>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="col-lg-1"></div>
</div>
</div>
  
  <div class="footery">
	<div class="footer-content">
		<ul class="list-inline list-unstyled navbar-footer">
			<li>Copyright &copy; 2018 分发 .All Rights Reserved.</li>
			<li><a href="/index.php/a"  target="_blank">应用规范</a></li>
			<li><a href="/index.php/a"  target="_blank">服务协议</a></li>
            <li><a href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes"  target="_blank">联系客服</a></li>
          	<li>声明：本平台仅供应用内测使用，请勿上传非法应用。如违规违法上传应用一切后果有上传者承担。</li>
			<li></li>
		</ul>
	</div>
</div></div>


<!-- Vendor scripts 

<script async="" src="static/js/meiqia.js"></script>
<script async="" src="static/js/analytics.js"></script>
-->


<script src="static/js/jquery.min.js"></script>
<script src="static/js/jquery-ui.min.js"></script>
<script src="static/js/jquery.slimscroll.min.js"></script>
<script src="static/js/bootstrap.min.js"></script>
<script src="static/js/metismenu.min.js"></script>
<script src="static/js/icheck.min.js"></script>
<script src="static/js/index.js"></script> 
<script src="static/js/jquery-1.10.1.min.js"></script>
<script src="static/js/idangerous.swiper2.7.6.min.js"></script>
<script src="static/js/swiper.animate1.0.2.min.js"></script>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-74260511-1', 'auto');
    ga('send', 'pageview');

    $(document).ready(function () {
    $('.navbar ul.nav li.father ').hover(function() {
        $(this).find('i.fa-angle-down').removeClass('fa-angle-down').addClass('fa-angle-up');
        $(this).find('.son').stop(true, true).fadeIn();
    }, function() {
        $(this).find('i.fa-angle-up').removeClass('fa-angle-up').addClass('fa-angle-down');
        $(this).find('.son').stop(true, true).fadeOut();
    });
 });
 
 var mySwiper = new Swiper ('.swiper-container', {
	pagination: '.pagination',
	paginationClickable :true,
	autoplay : 10000,
	speed:1,

	//autoplayDisableOnInteraction : false,
	
	onInit: function(swiper){ //Swiper2.x的初始化是onFirstInit
		swiperAnimateCache(swiper); //隐藏动画元素 
		swiperAnimate(swiper); //初始化完成开始动画
	}, 
	onSlideChangeEnd: function(swiper){ 
	swiperAnimate(swiper); //每个slide切换结束时也运行当前slide动画
	} 
})
  
$('.arrow-left').on('click', function(e){
	e.preventDefault()
	mySwiper.swipePrev()
})
$('.arrow-right').on('click', function(e){
	e.preventDefault()
	mySwiper.swipeNext()
})    

</script>
 
<div class="bar hidden-xs" style="z-index:9999;">
    <a class="bar3" href="http://wpa.qq.com/msgrd?v=3&uin=1787601777&site=qq&menu=yes">
         <span class="tel"></span>
    </a>
</div>

<script src="static/js/homer.js"></script>

<!-- Local script for menu handle -->
<!-- It can be also directive -->
<script>
    $(document).ready(function () {

    });
</script>
 
</body>  
  </html>
 </body>
</html></body>
</html>