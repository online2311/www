<?php
//decode by http://www.yunlu99.com/

namespace ApkParser;
abstract class Xml
{
}