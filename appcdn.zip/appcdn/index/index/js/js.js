$(function () {
    var windowWidth = $(window).width();
    function setRem () {
        var windowWidth = $(window).width();
        if (windowWidth <= 750) {
            var fs = windowWidth/750 * 6.25 * 100;
            $('html').css('font-size', fs + '%');   // 1rem = 100px;
        }
    };
    setRem();
    $(window).resize(setRem);

    $("[data-toggle='tooltip']").tooltip();

    $("[data-toggle='popover']").popover();

    //banner slide
    var mySwiper = new Swiper('.index-banner .swiper-container', {
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        pagination: {
            el: '.swiper-pagination',
            clickable :true,
        },
        loop : true,
        speed: 800,
        autoplay: {
            delay: 4000,
            stopOnLastSlide: false,
            disableOnInteraction: true,
        }
    });

    //本地上传显示缩略图
    function getObjectURL(file) {
        var url = null ;
        if (window.createObjectURL!=undefined) { // basic
            url = window.createObjectURL(file) ;
        } else if (window.URL!=undefined) { // mozilla(firefox)
            url = window.URL.createObjectURL(file) ;
        } else if (window.webkitURL!=undefined) { // webkit or chrome
            url = window.webkitURL.createObjectURL(file);
        }
        return url;
    };

    // 改版 图标上传
    $('.thumbnail').change(function() {
        var name = this.files[0].name;
        // 判断文件类型
        var type=(name.substr(name.lastIndexOf("."))).toLowerCase();
        var typeModal = '<div class="modal fade" id="typeModal" tabindex="-1" role="dialog">\
                         <div class="modal-dialog modal-sm" role="document">\
                            <div class="modal-content">\
                                <div class="modal-body">\
                                   <div class="text-center">\
                                        <div><span class="icon icon-modal-error2"></span></div>\
                                        <p class="color-333 mt5">您上传的图片格式不正确，请重新上传！</p>\
                                        <div class="mt15">\
                                           <button type="button" class="ms-btn ms-btn-default w90" data-dismiss="modal">确定</button>\
                                        </div>\
                                    </div>\
                               </div>\
                            </div>\
                        </div>\
                    </div>'

        if(type != ".jpg" && type !=".gif" && type != ".jpeg" && type != ".png"){
            $("#typeModal").remove();
            $("body").append(typeModal);
            $("#typeModal").modal("show");
            return false;
        }
        var eImg = $('<img />');
        eImg.attr('src', getObjectURL($(this)[0].files[0])); // 或 this.files[0] this->input
        $(this).next('img').remove();
        $(this).after(eImg);
        $(this).parents('.upload-img').addClass('uploaded');
        $(this).parents('.upload-icon').addClass('uploaded');
        $(this).parents('.upload-icon-common').addClass('uploaded');
    });

    // 价格支付选中
    $(".price-pay .common ul").on("click", "li:not('.disabled')", function () {
        $(this).addClass("active").siblings().removeClass("active");
        var i = $(this).index();
        if (i == 3) {
            $(this).parents(".common").find(".contrary-transfer").show();
        } else {
            $(this).parents(".common").find(".contrary-transfer").hide();
        }
    });

    // 我的应用 悬停显示二维码
    $(".release-app .icon-small-code").hover(function () {
        $(this).find(".qr-code").show();
    }, function () {
        $(this).find(".qr-code").hide();
    });

    // 我的应用 选择应用合并
    $('#myModal .app-list').on('click', 'li', function () {
        $(this).addClass('active').siblings().removeClass('active');
    });

    // 我的应用 编辑设置 选项卡
    $(".release-app .app-editor .tab li").click(function () {
        var index = $(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $(".release-app .app-editor .tab-con>div").eq(index).show().siblings().hide();
    });

    /*
    *改版完成后，将上方的删除
    *我的应用 编辑设置 选项卡
    **/
    $(".release-app2 .app-set .tab li").click(function () {
        var index = $(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $(".release-app2 .app-set .tab-con>div").eq(index).show().siblings().hide();
    });

    // 我的应用 编辑设置 基本设置 单选
    $(".release-app .app-editor .trust li").click(function () {
        $(".release-app .app-editor .trust li").removeClass("active").find(".icon-radio").removeClass("icon-radio-checked");
        $(this).addClass("active").find(".icon-radio").addClass("icon-radio-checked");
    });

    /*
    *改版完成后，将上方的删除
    *我的应用 编辑设置 基本设置 单选
    * */
    $(".release-app2 .app-set .trust li").click(function () {
        $(".release-app2 .app-set .trust li").removeClass("active").find(".icon-radio").removeClass("icon-radio-checked");
        $(this).addClass("active").find(".icon-radio").addClass("icon-radio-checked");
    });

    // 下载安装方式
    $(".release-app2 .app-set .download-way li").click(function () {
        var i = $(this).index();
        if (i == 1) {
            $(this).parents(".form-group").next(".form-group").show();
        } else {
            $(this).parents(".form-group").next(".form-group").hide();
        }

        $(".release-app2 .app-set .download-way li").removeClass("active").find(".icon-radio").removeClass("icon-radio-checked");
        $(this).addClass("active").find(".icon-radio").addClass("icon-radio-checked");
    });

    // 推广页 封装 选项卡
    $(".feature-plugin .f-list li").hover(function () {
        var i = $(this).index();
        $(".feature-plugin .f-list li").find(".icon-arrow-top2").hide();
        $(this).find(".icon-arrow-top2").show();
        $(".feature-tab").find("img").eq(i).css("display", "block").siblings().hide();
    }, function () {
    });

    // 推广页 封装 选项卡
    $('.good-case .g-con .tab-list li').hover(function () {
        var i = $(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $(".good-case .tab-con ul").eq(i).show().siblings().hide();
    }, function () {
    });

    // 个人中心 2版 选项卡
    $(".user-center1 .account-management>ul li").click(function () {
        var i = $(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $(".user-center1 .account-management .tab>div").eq(i).show().siblings().hide();
    });

    // 个人中心 2版 消息接收
    $(".user-center1 .msg ol li").click(function () {
        $(this).parents("ol").find("li").removeClass("active").find(".icon").removeClass("icon-radio-checked");
        $(this).addClass("active").find(".icon").addClass("icon-radio-checked");
    });

    // 个人中心 2版 发票地址 复选框选择
    $(".user-center1 .invoice-management .table .icon-checkbox1").click(function () {
        var that = $(".user-center1 .invoice-management .table .icon-checkbox1");
        that.removeClass("icon-checkbox-checked1");
        $(this).addClass("icon-checkbox-checked1");
    });

    /*
    * 个人中心 2版 发票地址 设为默认
    * 第一个为默认地址
    * */
    $(".user-center1 .invoice-management table tr").eq(1).find(".set-default").text("默认地址");
    $(".user-center1 .invoice-management table .set-default").click(function () {
        $(".user-center1 .invoice-management table .set-default").text("设为默认");
        var that = $(this).parents("table").find("tr").first();
        $(this).text("默认地址").parents("tr").insertAfter(that);
        $(".user-center1 .invoice-management .set-default")
    });

    // 复制弹窗
    function autoCopyHideModal (obj1,time) {
        $('#copyModal').remove();
        var html = '<div class="modal fade ms-modal auto-hide-modal" id="copyModal" tabindex="-1" role="dialog">\
                        <div class="modal-dialog modal-sm" role="document">\
                            <div class="modal-content">\
                                <div class="modal-body">\
                                    <div class="text-center">\
                                        <div class="auto-hide">\
                                            <div>复制成功</div>\
                                        </div>\
                                    </div>\
                                </div>\
                            </div>\
                        </div>\
                    </div>';

        $("body").append(html);
        var autoHide = null;
        clearTimeout(autoHide);
        $(obj1).modal('show');
        $(".modal-backdrop").hide();
        autoHide = setTimeout(function(){
            $(obj1).modal("hide");
        }, time);
    };

    // 复制功能
    var clipboard = new ClipboardJS('.copy');
    clipboard.on('success', function(e) {
        autoCopyHideModal("#copyModal", 2000);
        e.clearSelection();
    });
    clipboard.on('error', function(e) {
        console.log("复制失败!");
    });

    // 返回顶部
    $(".fixed-right .go-top").click(function () {
        $("html, body").stop().animate({'scrollTop': 0}, 500);
    });

    // 显示隐藏密码
    $(".account-management .pwd .pwd-toggle").click(function () {
        var inputPwd = $(this).siblings("input[name=pwd]");
        var pwdAttr = inputPwd.attr("type");
        if (pwdAttr == "password") {
            inputPwd.attr("type", "text");
            $(this).addClass("icon-eye").removeClass("icon-eye-no");
        } else {
            inputPwd.attr("type", "password");
            $(this).addClass("icon-eye-no").removeClass("icon-eye");
        }
    });

    // 价格页 tab选项卡
    $(".price-tab ul li").click(function () {
        var i = $(this).index();
        $(this).addClass("active").siblings().removeClass("active");
        $(".price-con>div").eq(i).show().siblings().hide();
    });

    // 大包入口 侧栏高度
    $(".big-bag-upload").prev(".aside-left").outerHeight("380px");

    // 表格列表 APP iOS 安卓版本下拉切换
    $(document).click(function () {
        $(".app-system-select").find("ul").hide();
    });

    $(".app-system-select").click(function (e) {
        var $ul = $(this).find("ul");
        var ulVisible = $ul.is(":visible");
        if (ulVisible) {
            $ul.hide();
        } else {
            $ul.show();
        }
        e.stopPropagation();
    });

    $(".app-system-select ul li").click(function () {
        var thisText = $(this).text();
        $(this).addClass("active").siblings().removeClass("active");
        $(this).parents(".app-system-select").find(".text").text(thisText);
    });

    $(".table-list-wrap .app-table .tr-disabled td").addClass("td-disabled").append('<div class="mask"></div>');


    /********************************************************************/

    // 去除文本里所有br换行
    String.prototype.replaceAll = function(s1,s2){
        return this.replace(new RegExp(s1,"gm"),s2);
    };
    function removeBr (obj) {
        $(obj).each(function () {
            var thisTexts = $(this).html();
            if (thisTexts != null) {
                thisTexts = thisTexts.replaceAll('<br>', '');
                $(this).html(thisTexts);
            }
        })
    };

    // 兼容平板
    if (windowWidth <= 768) {
        removeBr(".index-banner .banner-con h2");
        removeBr(".publicity li");
        removeBr(".toolkit li p");
        removeBr(".index-common .con p");
        removeBr(".promote-thumbnail p");
    }

    // 兼容手机
    function phoneFun () {
        var windowWidth = $(window).width();
        if (windowWidth <= 750) {
            $(".service_content li").attr("style", "");

            $(".login-in .login-user").click(function (e) {
                var visible = $(this).find("dl").is(":visible");
                if (visible) {
                    $(this).find("dl").hide();
                } else {
                    $(this).find("dl").show();
                }
                e.stopPropagation();
            });

            $("div").not(".login-in .login-user").click(function () {
                $(".login-in .login-user dl").hide();
            });
        }
    };
    phoneFun();
});

// 选项卡
var tab = {
    basis: function (obj) {
        $(obj.el).click(function () {
            var i = $(this).index();
            $(this).addClass("active").siblings().removeClass("active");

            $(obj.elTab).eq(i).show().siblings().hide();
        });
    },
    radioRound: function (obj) {
        $(obj.el).click(function () {
            $(obj.el).removeClass("active").find(".icon").removeClass(obj.checkedClass);
            $(this).addClass("active").find(".icon").addClass(obj.checkedClass);
        });
    },
    radioTick: function (obj) {
        $(obj.el).click(function () {
            var i = $(this).index();
            $(this).addClass("active").siblings().removeClass("active");

            if (i == 0) {
                $(obj.elHide).show();
            } else {
                $(obj.elHide).hide();
            }
        });
    }
};
tab.radioTick({
    el: ".radio-tick li"
});

// 输入框实时文字
var realTime = {
    inputText: function (obj) {
        $(obj.el).bind("input propertychange", function () {
            var thisVal = $(this).val();
            // console.log(thisVal.length);
            $(obj.elEdit).text(thisVal);
        });
    }
};

// 图片索引 地址赋值
var imgSrc = {
    edit: function (obj) {
        var src = $(obj.el).attr("src");
        src = src.substr(0, src.lastIndexOf("/") + 1);
        $(obj.el).attr("src", src + obj.index + "." + obj.format);
    }
};

