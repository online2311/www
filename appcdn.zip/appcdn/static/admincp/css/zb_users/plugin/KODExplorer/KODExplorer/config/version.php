<?php 
define('KOD_VERSION','3.21');