<div class="footer">
    <div class="zh">
        <?php if ($zbp->Config('txdida')->copyon=='1') { ?><p>Powered By <?php  echo $zblogphpabbrhtml;  ?>,Theme By <a href="http://www.txcstx.cn/"  target="_blank">zblog模板</a></p><?php } ?>
        <?php  echo $copyright;  ?>
    </div>
</div>

<script src="<?php  echo $host;  ?>zb_users/theme/<?php  echo $theme;  ?>/script/txdida.js" type="text/javascript"></script>
<?php  echo $footer;  ?>
</body>
</html>