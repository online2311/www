<?php  /* Template Name:侧栏模板 */  ?>
<?php  foreach ( $sidebar5 as $module) { ?>
<?php  include $this->GetTemplate('module');  ?>
<?php }   ?>