<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:68:"/www/wwwroot/web/luomei/application/admin/view/index/uloginedit.html";i:1526283760;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530821095;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	<ul class="nav navs nav-action nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统<i class="fa fa-gear m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gear">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="system" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="false">		
		        		           
		            <li class="hidden-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg icon-x"></i>网站设置</a></li>
		            <li class="visible-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg icon-x"></i>数据备份</a></li>
		            <li class="visible-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
		
		
		
		
		<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>应用(APP)<i class="fa fa-clone m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-clone">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="app" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg icon-x"></i>应用设置</a></li>
		            <li class="visible-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg icon-x"></i>卡密类型</a></li>
		            <li class="visible-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg icon-x"></i>卡密管理</a></li>
		            <li class="visible-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg"></i></a></li>
                    		           
		       
                                    </ul>
            </li>
        </ul>

									
			<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>用户<i class="fa fa-gears m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gears">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="auth" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg icon-x"></i>用户管理</a></li>
		            <li class="visible-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg icon-x"></i>用户组管</a></li>
		            <li class="visible-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
</div>


<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;<span id="">首页</span>
	</div>
		<div class="container">
			<div style="margin-top: 30px;">
				<form id="edituform" class="form-horizontal" action="" method="get">
					<input type="hidden" name="uid" value="<?php echo $uloginid; ?>">														
					<div class="form-group">
						<label for="inputloginname" class="col-sm-2 control-label">用户名:</label>
						<div class="col-sm-5">
							<input type="text" name="loginname" class="form-control" id="inputname" placeholder="" value="<?php echo $loginuserdb['name']; ?>" disabled/>
						</div>
					</div>
					<div class="form-group">
						<label for="inputloginname" class="col-sm-2 control-label">邮箱:</label>
						<div class="col-sm-5">
							<input type="email" name="email" class="form-control" id="inputname" placeholder="" value="<?php echo $loginuserdb['email']; ?>">
						</div>
					</div>
				    <div class="form-group input-append date form_datetime">
						<label for="inputpassword" class="col-sm-2 control-label">原密码:</label>
						<div class="col-sm-5">
                            <input name="password" class="form-control" id="inputpassword" size="16" placeholder="请输入原始密码" type="password" value="">                            
                        </div>
                    </div>
                    <div class="form-group input-append date form_datetime">
						<label for="inputnpassword" class="col-sm-2 control-label">新密码:</label>
						<div class="col-sm-5">
                            <input name="newpassword" class="form-control" id="inputnpassword" size="16" placeholder="请输入新始密码" type="password" value="">                            
                        </div>
                    </div>	
                    <div class="form-group input-append date form_datetime">
						<label for="inputnpassword" class="col-sm-2 control-label">再输一次:</label>
						<div class="col-sm-5">
                            <input name="newpassword2" class="form-control" id="inputnpassword2" size="16" placeholder="请再输入一次新密码" type="password" value="">                            
                        </div>
                    </div>	
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-5">
							
							<button id="uledit" type="submit" style="margin-right: 20px;" class="btn btn-primary">确&nbsp;定</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>	
	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

	<script type="text/javascript">
		$(document).ready(function() {
			$('#uledit').click(function() {
				var str_data = $("#edituform").serialize();			    
				$.ajax({
					type: "post",
					url: "<?php echo URL('/admin/index/addulogin'); ?>",
					data: str_data,
					success: function(msg) {
						layer.alert(msg);
					}
				});
				return false;
			});
			$('#ulexit').click(function() {
				var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
				parent.layer.close(index);
				return false;
			});
		});				
	</script>
</html>