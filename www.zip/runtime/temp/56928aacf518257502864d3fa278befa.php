<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:59:"/www/wwwroot/web/luomei/application/admin/view/app/add.html";i:1526283736;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530821095;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	<ul class="nav navs nav-action nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统<i class="fa fa-gear m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gear">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="system" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="false">		
		        		           
		            <li class="hidden-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg icon-x"></i>网站设置</a></li>
		            <li class="visible-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg icon-x"></i>数据备份</a></li>
		            <li class="visible-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
		
		
		
		
		<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>应用(APP)<i class="fa fa-clone m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-clone">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="app" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg icon-x"></i>应用设置</a></li>
		            <li class="visible-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg icon-x"></i>卡密类型</a></li>
		            <li class="visible-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg icon-x"></i>卡密管理</a></li>
		            <li class="visible-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg"></i></a></li>
                    		           
		       
                                    </ul>
            </li>
        </ul>

									
			<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>用户<i class="fa fa-gears m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gears">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="auth" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg icon-x"></i>用户管理</a></li>
		            <li class="visible-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg icon-x"></i>用户组管</a></li>
		            <li class="visible-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
</div>


<link rel="stylesheet" type="text/css" href="__PLUG__/aliico/iconfont.css"/>
<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;<span id="">添加用户</span>
	</div>
	<box class="box-b">
		<div class="divs" class="row">
			<div class="page-header page-s">
				<h3>添加应用<small></small></h3>
			</div>
			<form id="appadd" class="form-horizontal" action="" method="get">
				<input type="hidden" name="appset" value="add">
				<div class="form-group">
					<label for="inputpassword" class="col-sm-3 col-md-3 col-lg-2 control-label">软件名称</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<input type="text" name="app_name" class="form-control" id="inputname" placeholder="软件名" value="" />
					</div>
					<label style="color: red;" class="control-label">*</label>

				</div>
				<div class="form-group">
					<label for="inputusername" class="col-sm-3 col-md-3 col-lg-2 control-label">应用KEY</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<div class="input-group">
							<input type="text" name="app_key" class="form-control" id="keyid" placeholder="应用KEY" value="" />
							<span class="input-group-btn"><button id="skey" class="btn btn-warning" type="button">生成key</button></span>
						</div>
					</div>
					<label style="color: red;" class="control-label">*</label>
				</div>
				<div class="form-group">
					<label for="inputpassword" class="col-sm-3 col-md-3 col-lg-2 control-label">版本号</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<input type="text" name="version" class="form-control" id="inputname" placeholder="如：v2.0" value="" />
					</div>
				</div>
				<div class="form-group">
					<label for="inputpassword" class="col-sm-3 col-md-3 col-lg-2 control-label">下载地址</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<input type="text" name="downurl" class="form-control" id="inputname" placeholder="http://www.xxx.com/xxx.zip" value="" />
					</div>
				</div>
				<div class="form-group">
					<label for="inputdesc" class="col-sm-3 col-md-3 col-lg-2 control-label">软件类型</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<select class="form-control" name="free">
							<option value="1" selected="selected">收费软件</option>
							<option value="0">免费软件</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputpassword" class="col-sm-3 col-md-3 col-lg-2 control-label">用户试用时间</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<input type="text" name="test_time" class="form-control" id="inputname" placeholder="0为不试用" value="" />
					</div>
					<label style="color: red;" class="control-label">分钟</label>
				</div>
				<div class="form-group">
					<label for="inputacardday" class="col-sm-3 col-md-3 col-lg-2 control-label">授权码初始时间</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<input type="text" name="acard_time" class="form-control" id="inputname" placeholder="0" value="" />
					</div>
					<label style="color: red;" class="control-label">分钟</label>
				</div>
				<div class="form-group">
					<label for="inputdesc" class="col-sm-3 col-md-3 col-lg-2 control-label">绑定方式</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<select class="form-control" name="app_bind">
							<option value="0" selected="selected">不绑定</option>
							<option value="1">绑定IP</option>
							<option value="2">绑定机器码</option>
							<option value="3">绑定IP与机器码</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputdesc" class="col-sm-3 col-md-3 col-lg-2 control-label">自定义数据</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<textarea class="form-control textarea" rows="5" name="app_data" placeholder=""></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputdesc" class="col-sm-3 col-md-3 col-lg-2 control-label">应用公告</label>
					<div class="col-sm-8 col-md-6 col-lg-4">
						<textarea class="form-control textarea" rows="5" name="announcement" placeholder=""></textarea>
					</div>
				</div>
				<div class="form-group">
					<div class="col-sm-offset-3 col-md-offset-3 col-lg-offset-2 col-sm-5">
						<a href="<?php echo URL('/admin/app'); ?>" role="button" type="button" class="btn btn-warning">返&nbsp;回</a>
						<button id="subadd" type="submit" class="btn btn-primary">确&nbsp;定</button>
					</div>
				</div>
			</form>
		</div>
	</box>
</div>
	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

<script type="text/javascript">
	$(document).ready(function() {
		$('#skey').click(function() {
			var keys = randomWord(true, 32, 32);
			$("#keyid").val(keys);
		});
		$('#subadd').click(function() {
			var str_data = $("#appadd").serialize();
			$.ajax({
				type: "get",
				url: "",
				data: str_data,
				success: function(msg) {
					layer.alert(msg);
				}
			});
			return false;
		});
		
	});
	
	/*
	 ** randomWord 产生任意长度随机字母数字组合
	 ** randomFlag-是否任意长度 min-任意长度最小位[固定位数] max-任意长度最大位
	 ** xuanfeng 2014-08-28
	 */
	function randomWord(randomFlag, min, max) {
		var str = "",
			range = min,
			arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
		// 随机产生
		if(randomFlag) {
			range = Math.round(Math.random() * (max - min)) + min;
		}
		for(var i = 0; i < range; i++) {
			pos = Math.round(Math.random() * (arr.length - 1));
			str += arr[pos];
		}
		return str;
	}
</script>