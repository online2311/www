<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:63:"/www/wwwroot/web/luomei/application/admin/view/index/index.html";i:1530813682;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530821095;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	<ul class="nav navs nav-action nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统<i class="fa fa-gear m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gear">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="system" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="false">		
		        		           
		            <li class="hidden-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg icon-x"></i>网站设置</a></li>
		            <li class="visible-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg icon-x"></i>数据备份</a></li>
		            <li class="visible-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
		
		
		
		
		<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>应用(APP)<i class="fa fa-clone m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-clone">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="app" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg icon-x"></i>应用设置</a></li>
		            <li class="visible-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg icon-x"></i>卡密类型</a></li>
		            <li class="visible-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg icon-x"></i>卡密管理</a></li>
		            <li class="visible-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg"></i></a></li>
                    		           
		       
                                    </ul>
            </li>
        </ul>

									
			<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>用户<i class="fa fa-gears m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gears">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="auth" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg icon-x"></i>用户管理</a></li>
		            <li class="visible-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg icon-x"></i>用户组管</a></li>
		            <li class="visible-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
</div>



<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;<span id="">首页</span>
	</div>
	<box class="box-b">
		<div class="page-header page-a">
			<h2 style="margin-left: 50px;">欢迎使用<small>阿里聚合API验证系统&nbsp;!</small></h2>
			<div style="margin-left: 50px;">
				<span id="version">当前版本：<?php echo \think\Config::get('sysinfo.version'); ?></span>&nbsp;&nbsp;&nbsp;&nbsp;
				
			</div>
		</div>
		<div class="divs">
			<div class="row">
				<div class="col-md-3">
					<div class="bg-a metro">
						<div class="media">
							<div class="media-left">								
									<i style="color: #FFFFFF;font-size: 52px;" class="fa fa-user icon-top-15"></i>								
							</div>
							<div class="media-body">
								<h4 style="margin-top: 5px;" class="media-heading text-right">USER</h4><br />
								<h2 class="media-heading text-right"><?php echo $usernumber; ?></h2>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-b metro">
						<div class="media">
							<div class="media-left">
								<a href="#">
									<i style="color: #FFFFFF;font-size: 52px;" class="fa fa-clone icon-top-15"></i>
								</a>
							</div>
							<div class="media-body">
								<h4 style="margin-top: 5px;" class="media-heading text-right">APP</h4><br />
								<h2 class="media-heading text-right"><?php echo $appnumber; ?></h2>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-c metro">
						<div class="media">
							<div class="media-left">
								<a href="#">
									<i style="color: #FFFFFF;font-size: 52px;" class="fa fa-credit-card icon-top-15"></i>
								</a>
							</div>
							<div class="media-body">
								<h4 style="margin-top: 5px;" class="media-heading text-right">充值卡</h4><br />
								<h2 class="media-heading text-right"><?php echo $cardnumber; ?></h2>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="bg-d metro">
						<div class="media">
							<div class="media-left">
								<a href="#">
									<i style="color: #FFFFFF;font-size: 52px;" class="fa fa-address-card-o icon-top-15"></i>
								</a>
							</div>
							<div class="media-body">
								<h4 style="margin-top: 5px;" class="media-heading text-right">授权码</h4><br />
								<h2 class="media-heading text-right"><?php echo $acardnumber; ?></h2>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<style type="text/css">
			.table-bordered {
                border: 0px solid #dddddd;
            }
            .table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th, .table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {
                border: 0px solid #dddddd;
                border-bottom: 1px solid #dddddd;
            }
		</style>
		<div class="row">
			<div class="col-md-6">
					<div class="table-responsive container-fluid diva">
						<table class="table table-bordered table-hover">
							<thead>
								<tr>
									<th colspan="2">系统信息</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th scope="row">登录用户</th>
									<td><?php echo \think\Session::get('username'); ?></td>
								</tr>
								<tr>
									<td scope="row">登录次数</td>
									<td><?php echo $logincount; ?></td>
								</tr>
								<tr>
									<td scope="row">本次登录IP</td>
									<td><?php echo \think\Request::instance()->server('remote_addr'); ?></td>
								</tr>
								<tr>
									<td scope="row">上次登录IP</td>
									<td><?php echo $lastloginip; ?></td>
								</tr>
								<tr>
									<td scope="row">上次登录时间</td>
									<td><?php echo $lastlogintime; ?></td>
								</tr>

								<tr>
									<td scope="row">版本</td>
									<td><?php echo \think\Config::get('sysinfo.version'); ?></td>
								</tr>
								<tr>
									<td scope="row">内核版本</td>
									<td><?php echo THINK_VERSION; ?></td>
								</tr>
								<tr>
									<td scope="row">联系QQ</td>
									<td>2245521595</td>
								</tr>
								<tr>
									<td scope="row">官方网址</td>
									<td><a href="http://www.alijuhe.net">阿里聚合</a></td>
								</tr>
								<tr>
									<td scope="row">版权申明</td>
									<td>ALIJUHE·阿里聚合版权所有</td>
								</tr>
							</tbody>
						</table>
					</div>
				
			</div>
			<div class="col-md-6">
				<div class="table-responsive container-fluid divb">
					<table class="table table-bordered table-hover">
						<thead>
							<tr>
								<th colspan="2">服务器信息</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<th scope="row">网站域名</th>
								<td><?php echo \think\Request::instance()->server('server_name'); ?></td>
							</tr>
							<tr>
								<td scope="row">服务器IP地址</td>
								<td><?php echo \think\Request::instance()->server('server_addr'); ?></td>
							</tr>
							<tr>
								<td scope="row">服务器端口</td>
								<td><?php echo \think\Request::instance()->server('server_port'); ?></td>
							</tr>
							<tr>
								<td scope="row">服务器时间</td>
								<td id="time"><?php echo time2date(time()); ?></td>
							</tr>
							<tr>
								<td scope="row">网站服务器版本</td>
								<td><?php echo \think\Request::instance()->server('server_software'); ?></td>
							</tr>
							<tr>
								<td scope="row">网站所在路径</td>
								<td><?php echo \think\Request::instance()->server('document_root'); ?></td>
							</tr>

							<tr>
								<td scope="row">服务器系统信息</td>
								<td>
									<?php echo php_uname(); ?>
								</td>
							</tr>
							<tr>
								<td scope="row">服务器当前时间</td>
								<td>
									<?php echo date('Y-m-d H:i:s',time()); ?>
								</td>
							</tr>
							<tr>
								<td scope="row">PHP版本</td>
								<td>
									<?php echo phpversion(); ?>
								</td>
							</tr>
							<tr>
								<td scope="row">MYSQL版本</td>
								<td><?php echo $mysqlv; ?></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</box>
</div>

	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

<script type="text/javascript">
		$(document).ready(function() {
			$('#upsys').click(function() {
				$('#upsys').html('<i class="fa fa-refresh fa-spin"></i>更新中......');	    
				$.ajax({
					type: "get",
					url: "<?php echo URL('/admin/index/upsys'); ?>",
					success: function(msg) {
						layer.msg('更新完成,请刷新页面，更新大小：'+msg.file_size);
						$('#upsys').text('更新完成');
					}
				});
				return false;
			});
			$('#ulexit').click(function() {
				var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
				parent.layer.close(index);
				return false;
			});
		});				
	</script>