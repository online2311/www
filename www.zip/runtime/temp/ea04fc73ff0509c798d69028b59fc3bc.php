<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:32:"./theme/default/index/index.html";i:1532031546;}*/ ?>

<!DOCTYPE html>
<!--[if IE 7]> <html lang="en" class="ie7"> <![endif]-->  
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->  
<head>
    <title>友聚直播盒子[官网]-友聚直播邀请码,卡密激活,代理加盟</title>
    <meta charset="utf-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="友聚直播盒子">
    <meta name="description" content="友聚直播盒子官方网站">  
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no minimal-ui">
    <link rel="stylesheet" href="https://static.pgyer.com/static-20180705/assets/build/header_include.min.css">
    <link rel="stylesheet" href="https://static.pgyer.com/static-20180705/assets/css/viewFashion.css" />
    <link rel="stylesheet" href="https://static.pgyer.com/static-20180705/assets/css/appView.css">
</head>	

<body>

<div class="view-fashion-body" style="background-size: 30px 165px;" >
<div class="container view-fashion-content">
    <div class="row">
	
	    <!--app下载框-->
        <div class="col-md-4 col-sm-5 col-xs-12  " >
		

                        <div class="phone-small"> 
                <div class="install-btn" style='padding-top:90px;' >
                    <div id="" class="view row">
                         <div class="span12" style="text-align:center;">
             
					   <img src="../theme/default/index/images/logo.png" class="appicon" />
                        </div>
                     </div>

                    <div id="" class="view row" style="margin-top:30px;">    
                        
    <div class="span12 margin-bottom-20" style="text-align:center;">
        <div class="spinner">
            
            <div class="loading"></div>
            <a href="/youju.apk"  class="btn-u btn-u-lg " >
                    <i class="fa fa-android"></i> 安卓下载</a>
         </div>
    </div>
	
	


 
                        
                        <div class="span12 margin-bottom-20" style="text-align:center;margin-top: 15px;">
                        <span class="">老司机撸管神器</span>
                        </div>
                    </div>
                </div>
               
			   
                <div id="scan-qr" class="view row margin-bottom-30" style="padding-left:0px;padding-right:0px;">    
                    <div class="span12" style="text-align:center;">
                        <div class="row margin-bottom-10">
                                <img class="img-qr " src="../theme/default/index/images/qq.png" />
                        </div>
                        <div class="row margin-bottom-10">
                            <span>客服QQ：2038951549</span>
                        </div>
                    </div>
                </div>
             
                </div>

            

        </div>

		
		<div class="col-md-8 col-md-offset-0 col-sm-7 col-xs-12 app-info"  >
		
		
                <!--大标题和小标题-->
                <div class="row view-fashion-app-info content-right">
                    <div class="col-md-10 col-md-offset-1 ">
                        <h1 class="pull-left app-name">友聚直播盒子</h1>
                    </div>
                </div>
                <div class="row view-fashion-app-info ">
                    <div class="col-md-10 col-md-offset-1 ">
                        <ul class="pull-left breadcrumb" style="padding-left: 0px;padding-top:0px;">
                             <li>版本：2.0.1正式版 build-2018061300</li>
            <li>大小：12.2MB</li>
                    <li>2018-07-06</li>

                        </ul>
                    </div>
                </div>
				

            <!--正文列表-->
                                                
                                <div class="row ">
                    <div class="col-md-10 col-md-offset-1" style="word-break:break-all;">
                        <div class="margin-bottom-40">
                            <h2>友聚直播介绍</h2>
                        友聚聚合直播盒子APP [简称：友聚APP] 是一款集直播、云播、小说、影视为一体的聚合直播APP，破解了100多家直播平台VIP收费房间，可兼容安卓端和苹果端，新用户可免费试看30分钟...
						</div>
                    </div>
                </div>
				
				
            <!--应用截图-->    
                    <div class="row ">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="margin-bottom-40">
                            <h2>应用截图</h2>
                            <div class="table-responsive" style="border:none; overflow:auto;">
                                <table class="table" style="margin-bottom:0;">
                                    <tr>
                                     <td class="text-center" width="20%" style="border:none;">
                                     <div style="">
                                     <img src="../theme/default/index/images/3.png" style="width:230px;" />
                                     </div>
                                     </td>
									 
									  <td class="../theme/default/index/text-center" width="20%" style="border:none;">
                                     <div style="">
                                     <img src="../theme/default/index/images/2.png" style="width:230px;" />
                                     </div>
                                     </td>
									 
									  <td class="text-center" width="20%" style="border:none;">
                                     <div style="">
                                     <img src="../theme/default/index/images/1.png" style="width:230px;" />
                                     </div>
                                     </td>
									 
									  <td class="text-center" width="20%" style="border:none;">
                                     <div style="">
                                     <img src="../theme/default/index/images/4.png" style="width:230px;" />
                                     </div>
                                     </td>
									 
									  <td class="text-center" width="20%" style="border:none;">
                                     <div style="">
                                     <img src="../theme/default/index/images/5.png" style="width:230px;" />
                                     </div>
                                     </td>
									 
									  <td class="text-center" width="20%" style="border:none;">
                                     <div style="">
                                     <img src="../theme/default/index/images/6.png" style="width:230px;" />
                                     </div>
                                     </td>
                                                                              
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
				
				
				<!--版本列表-->
				
                     <div class="row   ">
                    <div class="col-md-10 col-md-offset-1">
                        <div class="margin-bottom-40 ">
                            <h2>历史版本</h2>
                            <div class="table-responsive" style="border:none; overflow:auto;">
                                <table class="table table-striped table-hover app_view_history" style="table-layout: fixed;">
                                    <tbody>
                                    <input type="hidden" id="pageNum" value="1">
                                     <tr appkey="471788d561ef968b9d3acc96f4cad22d" class="history_row">
                                      <td  style="position:relative" class="text-center " width="40%">1.1.4 (build 22)</td>

                                            <td class="text-left " width="40%"></td>

                                            <td class="text-center " width="20%">2017-10-20</td>
                                        </tr>
                                     
                                    
                                                                            <tr class="history_show_more" id="ajaxMore">
                                            <td class="text-center" style="background:#fff;" colspan="3">查看更多</td>
                                        </tr>
                                                                        </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
				
				
				
                </div>
				
				
				

    </div>

   </div>
</div>
</div>


<div style="padding-left:15px;padding-right:15px;"></div>
<!--底部版权-->

<div class="copyright" >
    <div class="container" style="z-index:-1;">
        <div class="row">
            <div class="col-lg-8  col-xs-12 col-md-6 col-sm-6 text-left" style="z-index:0;">
                                <a href="" target="_blank">免责声明</a>｜
                <a data-toggle="modal" id="reportClick" style="cursor: pointer;">举报</a>
            </div>
                        <div class="col-lg-4  col-xs-12 col-md-6 col-sm-6 text-right" style="z-index:0;">
                <a><img src="https://static.pgyer.com/static-20180705/assets/img/language_chinese.png"> 可信网站认证</a>
                &nbsp;&nbsp;&nbsp;<a><img src="https://static.pgyer.com/static-20180705/assets/img/language_english.png"> 安全联盟认证</a>
            </div>
                    </div>
					
    </div>
	
</div>

</body>
</html>
