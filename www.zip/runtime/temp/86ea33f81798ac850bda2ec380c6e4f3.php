<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:62:"/www/wwwroot/web/luomei/application/admin/view/card/index.html";i:1526283752;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530821095;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>

<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	<ul class="nav navs nav-action nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统<i class="fa fa-gear m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gear">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="system" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="false">		
		        		           
		            <li class="hidden-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg icon-x"></i>网站设置</a></li>
		            <li class="visible-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg icon-x"></i>数据备份</a></li>
		            <li class="visible-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
		
		
		
		
		<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>应用(APP)<i class="fa fa-clone m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-clone">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="app" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg icon-x"></i>应用设置</a></li>
		            <li class="visible-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg icon-x"></i>卡密类型</a></li>
		            <li class="visible-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg icon-x"></i>卡密管理</a></li>
		            <li class="visible-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg"></i></a></li>
                    		           
		       
                                    </ul>
            </li>
        </ul>

									
			<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>用户<i class="fa fa-gears m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gears">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="auth" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg icon-x"></i>用户管理</a></li>
		            <li class="visible-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg icon-x"></i>用户组管</a></li>
		            <li class="visible-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
</div>


<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap-table/bootstrap-table.css" />
<link rel="stylesheet" type="text/css" href="__PUBLIC__/static/css/table.css" />
<link rel="stylesheet" type="text/css" href="__PLUG__/radiocheckbox/css/jquery-labelauty.css" />
	<style type="text/css">
		.thumbnail {
			border: 0px solid #FFFFFF;
			margin-bottom: 0px;
		}
		.dowebok {
			list-style-type: none;
			margin-bottom: 0px;
		}
		
		.lis {
			display: inline-block;
			margin: 1px 0;
		}
		
		
		input.labelauty+ label {
			font: 12px "Microsoft Yahei";
		}
	</style>
<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;</span><span>充值卡管理</span>
	</div>
	<box class="box-b">
		<div class="divs">
			<form id="list" action="" method="post">
				<div class="row">
					<div class="col-sm-1">
						<h5 class="text-right">应用选项</h5>
					</div>
					<div style="padding-left: 0px;" class="col-sm-11">
						<ul class="dowebok">
							<?php if(is_array($appdb) || $appdb instanceof \think\Collection || $appdb instanceof \think\Paginator): $i = 0; $__LIST__ = $appdb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							<li class="lis"><input type="radio" name="appid" value="<?php echo $vo['appid']; ?>" data-labelauty="<?php echo $vo['app_name']; ?>"></li>
							<?php endforeach; endif; else: echo "" ;endif; ?>
							<!--<li class="lis"><input type="radio" name="radio" disabled data-labelauty="不可用"></li>-->
						</ul>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-1">
						<h5 class="text-right">可用状态</h5>
					</div>
					<div style="padding-left: 0px;" class="col-sm-11">
						<ul class="dowebok">
							<li class="lis"><input type="radio" name="status" value="1" data-labelauty="启用"></li>
							<li class="lis"><input type="radio" name="status" value="0" data-labelauty="停用"></li>
						</ul>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-1">
						<h5 class="text-right">销售状态</h5>
					</div>
					<div style="padding-left: 0px;" class="col-sm-11">
						<ul class="dowebok">
							<li class="lis"><input type="radio" name="sales_status" value="0" data-labelauty="未出售"></li>
							<li class="lis"><input type="radio" name="sales_status" value="1" data-labelauty="已出售"></li>
							<li class="lis"><input type="radio" name="sales_status" value="2" data-labelauty="已使用"></li>
						</ul>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-1">
						<h5 class="text-right">卡类选项</h5>
					</div>
					<div style="padding-left: 0px;" class="col-sm-10">
						<ul class="dowebok">
							<?php if(is_array($cardtypedb) || $cardtypedb instanceof \think\Collection || $cardtypedb instanceof \think\Paginator): $i = 0; $__LIST__ = $cardtypedb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							<li class="lis"><input type="radio" name="typeid" value="<?php echo $vo['id']; ?>" data-labelauty="<?php echo $vo['name']; ?>"></li>
							<?php endforeach; endif; else: echo "" ;endif; ?>
							<!--<li class="lis"><input type="radio" name="radio" disabled data-labelauty="不可用"></li>-->
						</ul>
					</div>
				</div>
			</form>
		</div>
		<div class="divs">
			<div id="toolbar">
				<button type="button" id="dellist" class="btn btn-warning"><span class="glyphicon glyphicon-trash"></span>删除</button>
				<a role="button" href="<?php echo URL('/admin/card/type'); ?>" type="button" class="btn btn-success">卡类管理</a>
				<a role="button" href="<?php echo URL('/admin/card/add'); ?>" type="button" class="btn btn-primary">生成充值卡</a>
			</div>
			<div class="table-responsive" data-show-refresh="true">
				<table id="cardtable">
				</table>
			</div>
		</div>
	</box>
</div>


	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

<script type="text/javascript" src="__PLUG__/bootstrap-table/bootstrap-table.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/locale/bootstrap-table-zh-CN.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/extensions/export/bootstrap-table-export.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/extensions/export/tableExport.js"></script>
<script src="__PLUG__/radiocheckbox/js/jquery-labelauty.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
	$(function(){
	   $(':input').labelauty();
	   
   });
</script>


<script type="text/javascript">
    var $table = $('#cardtable');
	$(document).ready(function() {		
		$table.bootstrapTable({
			classes: 'table table-hover',
			paginationPreText: '上一页',
			paginationNextText: '下一页',
			pagination: true,
			search: true,
			searchOnEnterKey: true,
			showColumns: true,
			showRefresh: true,
			showToggle: true,
			showPaginationSwitch: true,
			idField: 'uid',
			showexport: true,
			uniqueId: 'uid',
			toolbar: '#toolbar',
			showExport: true,						
			sidePagination: 'server',
			url: '__ROOT__/admin/card/cardlist',
			queryParamsType: '',
			queryParams: getdata,
			columns: [
			{
				checkbox:true,				
				align: 'center'
			},{
				field: 'id',
				title: 'ID',
				align: 'center'
			}, {
				field: 'card_number',
				title: '卡号',
				editable: true,
				align: 'center'
			},{
				field: 'user',
				title: '使用者',
				editable: true,
				align: 'center'
			},{
				field: 'app_name',
				title: '所属应用',
				editable: true,
				align: 'center'
			},{
				field: 'create_time',
				title: '创建时间',
				editable: true,
				align: 'center'
			},{
				field: 'sales_time',
				title: '销售时间',
				editable: true,
				align: 'center'
			},{
				field: 'type',
				title: '卡类型',
				editable: true,
				align: 'center'
			},{
				field: 'sales_status',
				title: '销售状态',
				editable: true,
				align: 'center'
			},{
				field: 'status',
				title: '状态',
				editable: true,
				align: 'center'
			},{
				field: 'op',
				title: '操作',				
				editable: true,
				formatter: oper,
				align: 'center'
			},],
			exportDataType:'selected'
		});
        function getdata(params){        	
        	var data = {};
            $("#list").serializeArray().map(function(x){
	            if (data[x.name] !== undefined) {
                    if (!data[x.name].push) {
                        data[x.name] = [data[x.name]];
                    }
                    data[x.name].push(x.value || '');
                } else {
                    data[x.name] = x.value || '';
                }
            });
            
        	var temp = {
        		limit: params.pageSize,
                offset: params.pageNumber,
                search: params.searchText,
                appid:data.appid,
                status:data.status,
                sales_status:data.sales_status,
                typeid:data.typeid,
        	};
        	return temp;
        }
        $('.lis').change(function() {
			var act=$table.bootstrapTable('getSelections');	
			$table.bootstrapTable('refresh', {silent: true});
		});
		function oper(value, row, index) {						
			var id = row.id;
			var status=row.status;
			var card=row.card_number;
			var opdata = '';
			    if (status=='<span style="color:#009900">启用</span>') {
			    	opdata += '<div style="margin-right: 5px" type="button" title="停用" class="btn btn-xs btn-on" onclick="cardset(\'stop\',\'' + id + '\')"><sapn class="fa fa-toggle-on"></sapn></div>';			    	
			    } 
			    if(status=='<span style="color:#666666">停用</span>') {
			    	opdata += '<div style="margin-right: 5px" type="button" title="启用" class="btn btn-xs btn-off" onclick="cardset(\'start\',\'' + id + '\')"><sapn class="fa fa-toggle-off"></sapn></div>';
			    }
			    
				opdata += '<div style="margin-right: 5px" type="button" title="del" class="btn btn-xs btn-del" onclick="cardset(\'del\',\'' + id + '\',\'' + card + '\')"><i class="fa fa-trash"></i></div>';			    	

			
			return opdata;
		}

		function vid(value, row, index) {
			//var row=index;
			return index;
		}
		
	});
	
    $("#dellist").click(function(){
        var act=$table.bootstrapTable('getSelections');
        if(act==false){
       	  layer.msg('请选择要删除的列表'); 
        }else{
        	layer.confirm('是否批量删除选中项？', {
                btn: ['确定','取消'] //按钮
            }, function(){
                dellist(act);
            }, function(){
                
            });       	
        }           
    });
    function dellist(act){
    	$.post("__ROOT__/admin/card/set", {
			cardset: 'dellist',
			data: act,
		}, function(response) {
				//$table.bootstrapTable('removeByUniqueId', uid);//
			$table.bootstrapTable('refresh', {silent: true});
			if (response) {					
				layer.msg(response);
			} else {
                layer.alert('操作失败！请重试！');					
			}
		});
    }
	function cardset(sets,id,card) {
		var $table = $('#cardtable');
		if(sets=='stop' || sets=='start'){						
			$.post("__ROOT__/admin/card/set", {
				cardset: sets,
				id: id,
			}, function(response) {
				//$table.bootstrapTable('removeByUniqueId', uid);//
				$table.bootstrapTable('refresh', {silent: true});
				if (response) {					
					layer.msg(response);
				} else {
                    layer.alert('操作失败！请重试！');					
				}
			});
			
		}
		if(sets=='del'){
			layer.confirm('<i style="color:#FF6633" class="icon-warning-sign icon-2x"></i> 是否删除卡号为 '+card+'充值卡?', {
                btn: ['确定','取消'] //按钮
            }, function(){
            	delcard(id,card);           
            }, function(){           	
            });
		}	
			
		
	}
    function delcard(id,card){
		var $table = $('#cardtable');
		$.post("__ROOT__/admin/card/set", {
			cardset:'del',
			card: card,
			id: id,
		}, function(response) {
			$table.bootstrapTable('refresh', {silent: true});
			if (response) {					
				layer.msg(response);
			} else {
                layer.alert('操作失败！请重试！');					
			}
		});
	}
    function retable(index, layero){
    	$table.bootstrapTable('refresh', {silent: true});
    }
</script>

