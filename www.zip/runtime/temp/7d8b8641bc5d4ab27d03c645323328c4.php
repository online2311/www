<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:63:"/www/wwwroot/web/luomei/application/admin/view/article/add.html";i:1526283738;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530820046;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	    <ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统管理<i class="<?php echo $vo['menu_icon']; ?> m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
			
			
			
		
        </ul>	    
	
</div>
<!--<div class="nav-left-2">
	<div class="menu-a-2">&nbsp;&nbsp;&nbsp;&nbsp;
		<span style="font-size:12px;margin-top:0px ;font-weight: bold;">标题</span>        
    </div>
    <ul class="nav nav-x nav-pills nav-pills-x nav-stacked meun-c">		
		<li class=""><a href="">&nbsp;&nbsp;&nbsp;&nbsp;添加文章</a></li>
		<li class="active"><a href="">&nbsp;&nbsp;&nbsp;&nbsp;编辑文章</a></li>
		<li class=""><a href="">&nbsp;&nbsp;&nbsp;&nbsp;添加分类</a></li>
    </ul>
</div>-->

<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrapvalidator/css/bootstrapValidator.min.css" />
<link rel="stylesheet" type="text/css" href="__PLUG__/webuploader/webuploader.css">
<style type="text/css">
	.webuploader-pick {
		border-radius: 0px;
	}
	
	#delexpimg {
		height: 40px;
		margin-left: 5px;
	}
	.edui-default .edui-editor-toolbarboxouter {
		background-image: linear-gradient(to bottom, #F1F1F1, #f1f1f1);
	}
	.edui-default .edui-editor {
		border-radius: 0px;
    }
	    
</style>
<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;<span id="">撰写文章</span>
	</div>
	<box class="box-b">
		<div class="divs">
			<div style="height: 100%;" class="row">
				<div class="page-header page-s">
					<h5>添加文章<small></small></h5>
				</div>
				<form id="articleform" role="form" action="" method="post">
					<div class="col-md-8 col-sm-8">
						<div class="form-group">
							<label for="inputtitle" class="control-label">文章标题</label>
							<input type="text" name="title" class="form-control" placeholder="文章标题" value="" />
						</div>
						<div class="form-group">
							<label for="inputstitle" class="control-label">摘要</label>
							<input type="text" name="keyword" class="form-control" placeholder="摘要" value="" />
						</div>
                        
						<div class="form-group">
							<label for="inputhelp" class="control-label">文章内容</label>
							<script id="aedit" name="content" type="text/plain" style="height: 380px;width: 100%;">
							</script>
						</div>
					</div>
					<!------------------------------right---------------------------------------------------------->
					<div class="col-md-4">
						<label>发布设置</label>
					</div>
					<div class="col-md-4">
						<?php echo hook('down_fee', ['pos'=>'add']); ?>
						<div class="panel panel-s panel-default">
							<div class="panel-body">
								<div class="page-header page-0">
									<h5 style="font-weight:800">所属分类</h5>
								</div>
								<div class="col-sm-12">									
									<?php if(is_array($tree) || $tree instanceof \think\Collection || $tree instanceof \think\Paginator): $i = 0; $__LIST__ = $tree;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
									<div class="checkbox">
										<label>
                                        <input name="sort[]" type="checkbox" value="<?php echo $vo['id']; ?>"> <strong style="color:#336699;"><?php echo $vo['sort_name']; ?></strong>
                                    </label>
									</div>
									<?php endforeach; endif; else: echo "" ;endif; ?>
									<a class="btn btn-default btn-sm" href="<?php echo URL('/admin/article/sorts'); ?>" role="button">添加分类</a>
								</div>
							</div>
						</div>
						<div class="panel panel-s panel-default">
							<div class="panel-body">
								<div class="page-header page-0">
									<h6 style="font-weight:800">特色图片&nbsp;320*180</h6>
								</div>
								<label for="inputcopyright" class="sr-only">特色图片</label>

								<!--dom结构部分-->
								<div id="uploader-demo">
									<!--用来存放item-->
									<div id="fileList" class="uploader-list"></div>

									<div class="pull-left" id="filePicker">选择图片</div>
									<button type="button" id="delimgs" class="btn btn-default pull-right">清除</button>

								</div>
							</div>
						</div>

						<input type="hidden" name="thumb_img" id="imgs" value="" />
						<div class="form-group">
							<div class="pull-right">
								<a class="btn btn-warning" href="<?php echo URL('/admin/article'); ?>" role="button">返回</a>
								<button type="submit" id="subadd" class="btn btn-primary">发布</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</box>
</div>
	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

<script type="text/javascript" src="__PLUG__/bootstrapvalidator/js/bootstrapValidator.min.js"></script>
<script type="text/javascript" charset="utf-8" src="__PUBLIC__/ueditor/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="__PUBLIC__/ueditor/ueditor.all.min.js"> </script>
<script type="text/javascript" src="__PLUG__/webuploader/webuploader.js"></script>
<script type="text/javascript">
	$(document).ready(function() {		
		$('#subadd').click(function() {
			var str_data = $("#articleform").serialize();
			
			$.ajax({
				type: "post",
				url: "",
				data: str_data,
				success: function(msg) {
					if(msg=='error'){
						layer.msg('添加失败,请填写完整！')
					}else{
						layer.msg('发布成功', {
                            time: 2000, //20s后自动关闭
                        },function(){
                            window.location.href='<?php echo URL("admin/article/edit"); ?>'+'?aid='+msg;
                        });
						
					}
					
				}
			});
			return false;
		});		
	});
</script>

<script type="text/javascript">
// 图片上传demo
jQuery(function() {
    var $ = jQuery,
        $list = $('#fileList'),
        // 优化retina, 在retina下这个值是2
        ratio = window.devicePixelRatio || 1,

        // 缩略图大小
        thumbnailWidth = 100 * ratio,
        thumbnailHeight = 100 * ratio,

        // Web Uploader实例
        uploader;

    // 初始化Web Uploader
    uploader = WebUploader.create({

        // 自动上传。
        auto: true,

        // swf文件路径
        swf: '__PLUG__/webuploader/Uploader.swf',
        // 文件接收服务端。
        server: 'upload',
        // 选择文件的按钮。可选。
        // 内部根据当前运行是创建，可能是input元素，也可能是flash.
        pick: '#filePicker',
        // 只允许选择文件，可选。
        accept: {
            title: 'Images',
            extensions: 'gif,jpg,jpeg,bmp,png',
            mimeTypes: 'image/*'
        }
    });

    // 当有文件添加进来的时候
    uploader.on( 'fileQueued', function( file ) {
    	$("#divimg").remove();
        var $li = $(
                '<div id="divimg" class="file-item thumbnail">' +
                    '<img id="imgid">' +
                    '<div class="info">' + file.name + '</div>' +
                '</div>'
                ),
            $img = $li.find('img');

        $list.append( $li );

        // 创建缩略图
        uploader.makeThumb( file, function( error, src ) {
            if ( error ) {
                $img.replaceWith('<span>不能预览</span>');
                return;
            }

            $img.attr( 'src', src );
        }, thumbnailWidth, thumbnailHeight );
    });

    // 文件上传过程中创建进度条实时显示。
    uploader.on( 'uploadProgress', function( file, percentage ) {
        var $li = $( '#'+file.id ),
            $percent = $li.find('.progress span');

        // 避免重复创建
        if ( !$percent.length ) {
            $percent = $('<p class="progress"><span></span></p>')
                    .appendTo( $li )
                    .find('span');
        }

        $percent.css( 'width', percentage * 100 + '%' );
    });

    // 文件上传成功，给item添加成功class, 用样式标记上传成功。
    uploader.on( 'uploadSuccess', function( file,response ) {
        $( '#'+file.id ).addClass('upload-state-done');
        var furl='/uploads/'+response._raw;
        $('#imgid').attr('src','__PUBLIC__'+furl);
        $('#imgs').val(furl);
         
    });

    // 文件上传失败，现实上传出错。
    uploader.on( 'uploadError', function( file ) {
        var $li = $( '#'+file.id ),
            $error = $li.find('div.error');

        // 避免重复创建
        if ( !$error.length ) {
            $error = $('<div class="error"></div>').appendTo( $li );
        }

        $error.text('上传失败');
    });

    // 完成上传完了，成功或者失败，先删除进度条。
    uploader.on( 'uploadComplete', function( file ) {
        $( '#'+file.id ).find('.progress').remove();
    });
});
</script>

<script type="text/javascript">
	$("#delimgs").click(function(){
       $('#divimg').remove();
       $('#imgs').val('');
   });
</script>

<script type="text/javascript">
//实例化编辑器
    var ue = UE.getEditor('aedit',{
    	//为编辑器实例添加一个路径，这个不能被注释
        UEDITOR_HOME_URL: "<?php echo get_root(); ?>/public/ueditor/" ,
        // 服务器统一请求接口路径
        serverUrl: "<?php echo url('/admin/ueditor/index'); ?>",
        //enableAutoSave: false,
        toolbars: [[
            'fullscreen', 'source', '|', 'undo', 'redo', '|',
            'bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'superscript', 'subscript', 'removeformat', 'formatmatch', 'autotypeset', 'blockquote', 'pasteplain', '|', 'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc', '|',
            'rowspacingtop', 'rowspacingbottom', 'lineheight', '|',
            'customstyle', 'paragraph', 'fontfamily', 'fontsize', '|',
            'directionalityltr', 'directionalityrtl', 'indent', '|',
            'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|', 'touppercase', 'tolowercase', '|',
            'link', 'unlink', 'anchor', '|', 'imagenone', 'imageleft', 'imageright', 'imagecenter', '|',
            'simpleupload', 'insertimage', 
            //'emotion',
            'scrawl', 'insertvideo',
            //'music',
            'attachment',
            //'map', 'gmap',
            //'insertframe',
            'insertcode',
            //'webapp',
            'pagebreak', 'template', 'background', '|',
            'horizontal',
            //'date','time',
            'spechars', 'snapscreen', 'wordimage', '|',
            'inserttable', 'deletetable', 'insertparagraphbeforetable', 'insertrow', 'deleterow', 'insertcol', 'deletecol', 'mergecells', 'mergeright', 'mergedown', 'splittocells', 'splittorows', 'splittocols', 'charts', '|',
            //'print',
            'preview', 'searchreplace', 
            //'drafts',
            //'help'
        ]]
    	
    });

</script>

