<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:60:"/www/wwwroot/web/luomei/application/admin/view/card/add.html";i:1526283750;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530821095;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	<ul class="nav navs nav-action nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统<i class="fa fa-gear m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#system" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gear">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="system" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="false">		
		        		           
		            <li class="hidden-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg icon-x"></i>网站设置</a></li>
		            <li class="visible-xs "><a href="/admin/netset/index.html"><i class="glyphicon glyphicon-cog fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg icon-x"></i>数据备份</a></li>
		            <li class="visible-xs "><a href="/admin/netset/bak.html"><i class="fa fa-database fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
		
		
		
		
		<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>应用(APP)<i class="fa fa-clone m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#app" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-clone">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="app" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg icon-x"></i>应用设置</a></li>
		            <li class="visible-xs "><a href="/admin/app/index.html"><i class="glyphicon glyphicon-tasks fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg icon-x"></i>卡密类型</a></li>
		            <li class="visible-xs "><a href="/admin/card/type.html"><i class="fa fa-cubes fa-lg"></i></a></li>
                    		           

                    		           
		            <li class="hidden-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg icon-x"></i>卡密管理</a></li>
		            <li class="visible-xs "><a href="/admin/card/index.html"><i class="fa fa-credit-card fa-lg"></i></a></li>
                    		           
		       
                                    </ul>
            </li>
        </ul>

									
			<ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>用户<i class="fa fa-gears m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
		    <li class="visible-xs">
			    <a href="#auth" class="nav-header in" aria-expanded="true" data-toggle="collapse">				
			        &nbsp;<i class="fa fa-gears">&nbsp;</i>
			    </a>
		    </li>
            <li class="">
	            <ul id="auth" class="nav nav-pills nav-stacked meun-c collapse in" aria-expanded="true" style="">		
		        		           
		            <li class="hidden-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg icon-x"></i>用户管理</a></li>
		            <li class="visible-xs "><a href="/admin/user/index.html"><i class="glyphicon glyphicon glyphicon-user fa-lg"></i></a></li>
                    		           
		            <li class="hidden-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg icon-x"></i>用户组管</a></li>
		            <li class="visible-xs "><a href="/admin/authgroup/index.html"><i class="fa fa-users fa-lg"></i></a></li>
                    		           

                                    </ul>
            </li>
        </ul>
</div>


<link rel="stylesheet" type="text/css" href="__PLUG__/aliico/iconfont.css"/>
<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;<span id="">充值卡</span>
	</div>
	<box class="box-b">
		<div class="divs" class="row">
			<div class="page-header page-s">
				<h1>生成充值卡<small></small></h1>
			</div>
			<form id="card" class="form-horizontal">
				<input type="hidden" name="set" value="create" />
				<div class="form-group">
					<label for="inputpwd" class="col-sm-3 col-md-3 col-lg-2 control-label">充值卡应用</label>
					<div class="col-sm-5 col-md-5 col-lg-3">
						<select class="form-control" name="appid">
							<?php if(is_array($resapp) || $resapp instanceof \think\Collection || $resapp instanceof \think\Paginator): $i = 0; $__LIST__ = $resapp;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							<option value="<?php echo $vo['appid']; ?>"><?php echo $vo['app_name']; ?></option>                           
                            <?php endforeach; endif; else: echo "" ;endif; ?>							
						</select>
					</div>
					
						<a class="btn btn-link" href="<?php echo URL('/admin/app/add'); ?>" role="button">添加应用</a>
					
				</div>
				<div class="form-group">
					<label for="inputpwd" class="col-sm-3 col-md-3 col-lg-2 control-label">充值卡类型</label>
					<div class="col-sm-5 col-md-5 col-lg-3">
						<select class="form-control" name="type">
							<?php if(is_array($restype) || $restype instanceof \think\Collection || $restype instanceof \think\Paginator): $i = 0; $__LIST__ = $restype;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							<option value="<?php echo $vo['id']; ?>"><?php echo $vo['name']; ?></option>                           
                            <?php endforeach; endif; else: echo "" ;endif; ?>							
						</select>
					</div>
					<a class="btn btn-link" href="<?php echo URL('/admin/card/type'); ?>" role="button">添加卡类</a>
					
				</div>
				<div class="form-group">
					<label for="inputnumber" class="col-sm-3 col-md-3 col-lg-2 control-label">数量</label>
					<div class="col-sm-5 col-md-5 col-lg-3">
						<input type="text" name="number" class="form-control" placeholder="生成数量" value="" />
					</div>
					<label style="color: red;" for="inputnetonoff" class="control-label">*一次最大100张</label>
				</div>				
				<div class="form-group">
					<div class="col-sm-offset-3 col-md-offset-3 col-lg-offset-2 col-sm-5 col-md-5 col-lg-3">						
						<a class="btn btn-warning" href="<?php echo URL('/admin/card'); ?>" role="button">返回</a>
						<button id="subadd" class="btn btn-primary">确认生成</button>
					</div>
				</div>
			</form>
		</div>
	</box>
</div>
	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

<script type="text/javascript">
	$(document).ready(function() {		
		$('#subadd').click(function() {
			var str_data = $("#card").serialize();	
			$.ajax({
				type: "get",
				url: "",
				data: str_data,
				success: function(msg) {
					layer.alert(msg);					
				}
			});
			return false;
		});
		
	});
</script>

