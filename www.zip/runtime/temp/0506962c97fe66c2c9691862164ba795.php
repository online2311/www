<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:65:"/www/wwwroot/web/luomei/application/admin/view/article/sorts.html";i:1526283742;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530820046;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	    <ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统管理<i class="<?php echo $vo['menu_icon']; ?> m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
			
			
			
		
        </ul>	    
	
</div>
<!--<div class="nav-left-2">
	<div class="menu-a-2">&nbsp;&nbsp;&nbsp;&nbsp;
		<span style="font-size:12px;margin-top:0px ;font-weight: bold;">标题</span>        
    </div>
    <ul class="nav nav-x nav-pills nav-pills-x nav-stacked meun-c">		
		<li class=""><a href="">&nbsp;&nbsp;&nbsp;&nbsp;添加文章</a></li>
		<li class="active"><a href="">&nbsp;&nbsp;&nbsp;&nbsp;编辑文章</a></li>
		<li class=""><a href="">&nbsp;&nbsp;&nbsp;&nbsp;添加分类</a></li>
    </ul>
</div>-->

<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap-table/bootstrap-table.css" />
<link rel="stylesheet" type="text/css" href="__PUBLIC__/static/css/table.css" />
<style type="text/css">
	.fixed-table-container {   
    border: 0px solid #dddddd  !important; 
    border-bottom: 1px solid #dddddd  !important;  
}
</style>
<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;</span><span>分类管理</span>
	</div>

	<box class="box-b">
		<div class="divs col-lg-4">
			<div class="page-header page-s">
				<h5>添加分类目录<small></small></h5>
			</div>
			<form class="formsort" role="form">
				<div class="form-group">
					<label for="sort_name">分类名称</label>
					<input type="text" name="sort_name" class="form-control" placeholder="分类名称">
				</div>
				<div class="form-group">
					<label for="sname">别名</label>
					<input type="text" name="description" class="form-control" placeholder="做为关键词到分类页面">
				</div>
				<div class="form-group">
					<label for="sname">上级分类</label>
					<select style="color: #336699;" name="parent_id" class="form-control">
						<option value="0">无</option>
						<?php if(is_array($sortdb) || $sortdb instanceof \think\Collection || $sortdb instanceof \think\Paginator): $i = 0; $__LIST__ = $sortdb;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <option value="<?php echo $vo['id']; ?>"><?php echo $vo['sort_name']; ?></option>
                        <?php endforeach; endif; else: echo "" ;endif; ?>						
					</select>
				</div>
				<div class="form-group">
					<button type="submit" id="addsort" class="btn btn-primary">添加新分类</button>
				</div>
			</form>
		</div>
		<div class="divs col-lg-7">
			<div id="toolbar">
				<a role="button" href="<?php echo URL('/admin/article/add'); ?>" type="button" class="btn btn-primary">撰写文章</a>
			</div>
			<div class="table-responsive" data-show-refresh="true">
				<table id="table">
				</table>
			</div>
		</div>
	</box>
</div>
<!--<a class="btn btn-xs btn-success" href="/index.php/admin/netset/bak/tp/dowonload/name/20160517154306.sql.html">下载</a>-->


	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

<script type="text/javascript" src="__PLUG__/bootstrap-table/bootstrap-table.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/locale/bootstrap-table-zh-CN.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/extensions/export/bootstrap-table-export.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/extensions/export/tableExport.js"></script>



<script type="text/javascript">
    var $table = $('#table');
    $(document).ready(function() {    	
		$('#addsort').click(function() {
			var str_data = $(".formsort").serialize();
			$.ajax({
				type: "get",
				url: "addsort",
				data: str_data,
				success: function(msg) {					
					layer.alert(msg);
					retable();
				}
			});
			return false;
		});		
	});
    
    
	$(document).ready(function() {		
		$table.bootstrapTable({
			classes: 'table',
			paginationPreText: '上一页',
			paginationNextText: '下一页',
			pageSize:20,
			pagination: true,			
			searchOnEnterKey: true,
			showColumns: true,
			showRefresh: true,
			showToggle: true,
			showPaginationSwitch: true,
			idField: 'uid',
			showexport: true,
			uniqueId: 'uid',
			toolbar: '#toolbar',			
			sidePagination: 'client',
			url: '__ROOT__/admin/article/sortlist',
			columns: [{
				field: 'id',
				title: '分类ID',
				visible:false,
				align: 'center'
			}, {
				field: 'sort_name',
				title: '名称',
				editable: true,
				formatter: sortname,
				align: 'left'
			},{
				field: 'description',
				title: '别名',
				editable: true,
				align: 'center'
			},{
				field: 'count',
				title: '文章数',
				editable: true,
				align: 'center'
			},{
				field: 'status',
				title: '状态',
				editable: true,
				formatter: statu,
				align: 'center'
			},{
				field: 'op',
				title: '操作',				
				editable: true,
				formatter: oper,
				align: 'center'
			},],
		});

		function oper(value, row, index) {			
			
			var sid = row.id;
			var status=row.status;			
			var opdata = '<a href="__ROOT__/admin/article/editsort?sort_id=' + sid +'" role="button" style="margin-right: 5px" type="button" class="btn btn-xs btn-icon"><i class="fa fa-edit"></i></a>';
			    if (status!=0) {
			    	opdata += '<div style="margin-right: 5px" type="button" title="停用" class="btn btn-xs btn-on" onclick="sortset(\'stop\',\'' + sid + '\')"><i class="fa fa-toggle-on"></i></div>';			    	
			    } else{
			    	opdata += '<div style="margin-right: 5px" type="button" title="启用" class="btn btn-xs btn-off" onclick="sortset(\'start\',\'' + sid + '\')"><i class="fa fa-toggle-off"></i></div>';			    	
			    }
				opdata += '<div style="margin-right: 5px" type="button" class="btn btn-xs btn-del" onclick="sortset(\'del\',\'' + sid + '\')"><i class="fa fa-trash"></i></div>';			    	

			
			return opdata;
		}
        function sortname(value, row, index) {
			var res = '<strong style="color:#336699;font-size:14px">'+value+'</strong>';			
			return res;
		}
		function statu(value, row, index) {
			var index = '<span>已启用</span>';
			if(value < 1){
				index = '<span style="color:#CC0000">已停用</span>';
			}
			return index;
		}
	});

	function sortset(sets,srtid_id) {
		var $table = $('#table');
		if(sets=='stop' || sets=='start'){						
			$.get("__ROOT__/admin/article/sortset", {
				sortset: sets,
				sort_id: srtid_id,
			}, function(response) {
				//$table.bootstrapTable('removeByUniqueId', uid);//
				$table.bootstrapTable('refresh', {silent: true});
				if (response) {					
					layer.alert(response);
				} else {
                    layer.alert('操作失败！请重试！');					
				}
			});			
		}
		if(sets=='del'){
			layer.confirm('<i style="color:#FF6633" class="icon-warning-sign icon-2x"></i> 是否删除?', {
                btn: ['确定','取消'] //按钮
            }, function(){
            	delsort(srtid_id);           
            }, function(){           	
            });
		}	
	}
    function delsort(srtid_id){
		var $table = $('#table');
		$.get("__ROOT__/admin/article/sortset", {
			sortset: 'del',
			sort_id: srtid_id,
		}, function(response) {
			$table.bootstrapTable('refresh', {silent: true});
			if (response) {					
				layer.alert(response);
			} else {
                layer.alert('操作失败！请重试！');					
			}
		});
	}
    function retable(index, layero){
    	$table.bootstrapTable('refresh', {silent: true});
    }
</script>

