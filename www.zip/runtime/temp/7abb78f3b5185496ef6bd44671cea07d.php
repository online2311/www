<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:66:"/www/wwwroot/web/luomei/application/admin/view/authrule/index.html";i:1526283748;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/header.html";i:1530818904;s:65:"/www/wwwroot/web/luomei/application/admin/view/public/lefter.html";i:1530820046;s:66:"/www/wwwroot/web/luomei/application/admin/view/public/flooter.html";i:1526283776;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="renderer" content="webkit">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
		<title>后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap/css/bootstrap.css"/>
        <link rel="stylesheet" type="text/css" href="__PLUG__/font-awesome-4.7.0/css/font-awesome.min.css"/>
	    <link rel="stylesheet" type="text/css" href="__CSS__/style.css"/>
	    
       
        
   

		<!-- Bootstrap -->

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
        <script src="//cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="//cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	</head>

	<body>
		<nav class="navbar navbar-default" style="background-color: #373D41;">
			<div class="container-fluid" style="background-color: #373D41;">
				<div class="navbar-header">
					<a style="color: #FFFFFF;" href="<?php echo URL('/admin/login/index'); ?>" type="button" class="navbar-toggle collapsed">
						<i class="fa fa-sign-out"></i>
                    </a>
					<a class="navbar-brand" style="background: #373D41;font-size: 24px;width: 50px;" href=""><i class="fa fa-codepen"></i></a>
				</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li class="border-left nav-li"><a href="<?php echo URL('/admin/index'); ?>" style="font-size: 14px;">管理控制台</a></li>
					</ul>
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown nav-li">
                        <a href="#" class="dropdown-toggle useredit" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="icon-user"></i>&nbsp;<?php echo $loginuser; ?><span class="caret"></span>&nbsp;</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo URL('/admin/index/uloginedit'); ?>">编辑资料</a></li>                            
                        </ul>
                       </li>							                    
                            
                            <li class="nav-li"><a href="<?php echo URL('/admin/login/index'); ?>">&nbsp;&nbsp;<span class="glyphicon glyphicon-log-out"></span>&nbsp;退出</a></li>
					</ul>
				</div>
			</div>
		</nav>	
		
 
<div class="nav-left">
	<div class="menu-a">
		<ul class="nav nav-pills nava nav-stacked">
        <li><a id="lefttop"><span style="font-size: 12px;" class="fa fa-reorder"></span></a></li>        
        </ul>
	</div>
	
	    <ul class="nav navs  nav-pills nav-stacked meun-b">				
		    <li class="hidden-xs">
			    <a href="#" class="nav-header collapsed in" aria-expanded="true" data-toggle="collapse">				
			        <i class="fa fa-caret-down icon-w">&nbsp;</i>系统管理<i class="<?php echo $vo['menu_icon']; ?> m-ico pull-right">&nbsp;</i>
			    </a>
		    </li>
			
			
			
		
        </ul>	    
	
</div>
<!--<div class="nav-left-2">
	<div class="menu-a-2">&nbsp;&nbsp;&nbsp;&nbsp;
		<span style="font-size:12px;margin-top:0px ;font-weight: bold;">标题</span>        
    </div>
    <ul class="nav nav-x nav-pills nav-pills-x nav-stacked meun-c">		
		<li class=""><a href="">&nbsp;&nbsp;&nbsp;&nbsp;添加文章</a></li>
		<li class="active"><a href="">&nbsp;&nbsp;&nbsp;&nbsp;编辑文章</a></li>
		<li class=""><a href="">&nbsp;&nbsp;&nbsp;&nbsp;添加分类</a></li>
    </ul>
</div>-->

<link rel="stylesheet" type="text/css" href="__PLUG__/bootstrap-table/bootstrap-table.css" />
<link rel="stylesheet" type="text/css" href="__PUBLIC__/static/css/table.css" />
<style type="text/css">
	.fixed-table-container {   
    border: 0px solid #dddddd  !important; 
    border-bottom: 1px solid #dddddd  !important;  
}
</style>
<div class="container-fluid box-a">
	<div class="nav-c">
		<span class="glyphicon glyphicon-tag">&nbsp;</span><span>节点管理</span>
	</div>

	<box class="box-b">		
		<div class="divs">
			<div id="toolbar">
				<a role="button" href="<?php echo URL('/admin/authrule/add'); ?>" type="button" class="btn btn-primary">添加节点</a>
			</div>
			<div class="table-responsive" data-show-refresh="true">
				<table id="table">
				</table>
			</div>
		</div>
	</box>
</div>



	</body>
	<script src="__PLUG__/jquery/jquery.min.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/bootstrap/js/bootstrap.js" type="text/javascript" charset="utf-8"></script>
    <script src="__PLUG__/layer/layer.js" type="text/javascript" charset="utf-8"></script>
</html>		

<script type="text/javascript" src="__PLUG__/bootstrap-table/bootstrap-table.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/locale/bootstrap-table-zh-CN.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/extensions/export/bootstrap-table-export.js"></script>
<script type="text/javascript" src="__PLUG__/bootstrap-table/extensions/export/tableExport.js"></script>



<script type="text/javascript">
    var $table = $('#table');
   
	$(document).ready(function() {		
		$table.bootstrapTable({
			classes: 'table',
			paginationPreText: '上一页',
			paginationNextText: '下一页',
			pageSize:10,
			pagination: true,			
			searchOnEnterKey: true,
			showColumns: true,
			showRefresh: true,
			showToggle: true,
			showPaginationSwitch: true,
			idField: 'uid',
			showexport: true,
			uniqueId: 'uid',
			toolbar: '#toolbar',			
			sidePagination: 'server',
			url: '__ROOT__/admin/authrule/rulelist',
			columns: [{
				field: 'id',
				title: 'ID',
				visible:true,
				align: 'left'
			}, {
				field: 'title',
				title: '名称',
				editable: true,				
				align: 'left'
			},{
				field: 'name',
				title: '地址',
				editable: true,
				align: 'center'
			},{
				field: 'group',
				title: '节点分类',
				editable: true,
				align: 'center'
			},{
				field: 'status',
				title: '状态',
				editable: true,
				formatter: statu,
				align: 'center'
			},{
				field: 'op',
				title: '操作',				
				editable: true,
				formatter: oper,
				align: 'center'
			},],
		});

		function oper(value, row, index) {			
			
			var rid = row.id;
			var status=row.status;			
			var opdata = '<a href="__ROOT__/admin/authrule/edit?rid=' + rid +'" title="设置" role="button" style="margin-right: 5px" type="button" class="btn btn-xs btn-icon"><i class="fa fa-cog"></i></a>';
			    if (status!=0) {
			    	opdata += '<div style="margin-right: 5px" type="button" title="停用" class="btn btn-xs btn-on" onclick="ruleset(\'stop\',\'' + rid + '\')"><i class="fa fa-toggle-on"></i></div>';			    	
			    } else{
			    	opdata += '<div style="margin-right: 5px" type="button" title="启用" class="btn btn-xs btn-off" onclick="ruleset(\'start\',\'' + rid + '\')"><i class="fa fa-toggle-off"></i></div>';			    	
			    }
				opdata += '<div style="margin-right: 5px" type="button" class="btn btn-xs btn-del" onclick="ruleset(\'del\',\'' + rid + '\')"><i class="fa fa-trash"></i></div>';			    	

			
			return opdata;
		}
        
		function statu(value, row, index) {
			var index = '<span>已启用</span>';
			if(value < 1){
				index = '<span style="color:#CC0000">已停用</span>';
			}
			return index;
		}
	});

	function ruleset(sets,rid) {
		var $table = $('#table');
		if(sets=='stop' || sets=='start'){						
			$.get("__ROOT__/admin/authrule/set", {
				ruleset: sets,
				rid: rid,
			}, function(response) {
				//$table.bootstrapTable('removeByUniqueId', uid);//
				$table.bootstrapTable('refresh', {silent: true});
				if (response) {					
					layer.msg(response);
				} else {
                    layer.alert('操作失败！请重试！');					
				}
			});			
		}
		if(sets=='del'){
			layer.confirm('<i style="color:#FF6633" class="icon-warning-sign icon-2x"></i> 是否删除?', {
                btn: ['确定','取消'] //按钮
            }, function(){
            	del(rid);           
            }, function(){           	
            });
		}	
	}
    function del(rid){
		var $table = $('#table');
		$.get("__ROOT__/admin/authrule/set", {
			ruleset: 'del',
			rid: rid,
		}, function(response) {
			$table.bootstrapTable('refresh', {silent: true});
			if (response) {					
				layer.msg(response);
			} else {
                layer.alert('操作失败！请重试！');					
			}
		});
	}
    function retable(index, layero){
    	$table.bootstrapTable('refresh', {silent: true});
    }
</script>

