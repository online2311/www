<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
// $Id$

return [
    //注册控制
        'register_time'=>130,//多少秒
        'register_num'=>3,//注册次数
        'register_black_count'=>60,//多少次后拉黑
    //邮件找回密码限制
        'email_repwb_time'=>60,//多少秒
        'email_repwb_num'=>2,//注册次数
        'email_repwb_black_count'=>5,//多少次后拉黑
        
        
	
];
