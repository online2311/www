<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
// $Id$

return [
		// SMTP 服务器
        'host'=>'smtp.163.com',
        // SMTP服务器的端口号
        'port'=>465,
        // SMTP服务器用户名
        'username'=>'xxx@163.com',
        // SMTP服务器密码
        'password'=>'',
        //发件人EMAIL
        'replyemali'=>'xxx@163.com',
        //发件人名称
        'replyuser'=>'xxx',	
];
