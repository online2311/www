<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
// $Id$
//网站信息设置
return [
    //版本号
     'version'=>'V2.1.3',
     //官方网址
     'website'=>'http://www.rain68.com',
     //系统版权
     'copyright'=>'RainSoft版权所有',
     //联系qq
     'qq'=>'80692285',
     //网站版本更新地址
     'app_id'  => 1,
     'app_key' => 'raincms',
     'app_url' =>'http://www.rs.com/appapi/get_app',
     
     
];