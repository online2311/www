<div class="section packages-faq">
	<div class="packages-faq-wrap text-left">
		<div class="packages-faq-header">FAQ</div>
		<div class="packages-faq-content">
			<ol class="packages-faq-list">
				<li>
				<div class="faq-title">如何去除应用安装页的底部广告？</div>
				<ol class="faq-list-items">
					<li>1、应用管理 -> 管理 -> 基本信息 -> 去除广告 -> 去除</li>
					<li>2、每个应用需单独去除广告并扣除 <?php echo IN_ADPOINTS; ?> 下载点数</li>
				</ol>
				</li>
			</ol>
		</div>
	</div>
</div>